# FootVibes v76 — reprendre la base Appwrite et la messagerie existantes

Cette version conserve le code de la v75 et ajoute un plan de raccordement sans recréer la base ni demander de secret dans le chat.

## Ce qui est déjà connu
- Endpoint public : `https://fra.cloud.appwrite.io/v1`
- Project ID public : `6ad4e92a0021cc34d98c`
- L'utilisateur indique que la base Appwrite et la messagerie existent déjà.
- Hébergement : pas encore choisi.

## Étape 1 — vérifier l'instance existante
Dans la console Appwrite, ouvrir le projet correspondant au Project ID ci-dessus et vérifier sans modifier les données :
1. Database ID existant.
2. IDs exacts des collections utilisées pour utilisateurs, publications, commentaires, messages et appels.
3. ID du bucket de médias.
4. Attributs/index et permissions de lecture/écriture.
5. Méthode d'authentification et règles d'accès par utilisateur.

Ne pas créer de doublons si ces éléments existent déjà. Les noms d'affichage ne sont pas nécessairement les IDs attendus par l'application.

## Étape 2 — configurer les IDs dans l'environnement privé
Copier `.env.example` vers `.env` sur la machine ou dans les variables d'environnement de l'hébergeur, puis compléter les valeurs déjà présentes dans Appwrite :
- `APPWRITE_DATABASE_ID`
- `APPWRITE_USERS_COLLECTION_ID`
- `APPWRITE_POSTS_COLLECTION_ID`
- `APPWRITE_COMMENTS_COLLECTION_ID`
- `APPWRITE_MESSAGES_COLLECTION_ID`
- `APPWRITE_CALLS_COLLECTION_ID`
- `APPWRITE_MEDIA_BUCKET_ID`

Conserver les IDs existants. Ne jamais ajouter `.env` à l'archive, à Git ou à un message. `APPWRITE_API_KEY` reste uniquement côté serveur et doit avoir les permissions minimales nécessaires.

## Étape 3 — vérifier la messagerie existante
Avant toute migration, effectuer un test avec deux comptes de test :
1. Le compte A envoie un message texte au compte B.
2. B voit le message sans recharger la page si le realtime est activé.
3. Un utilisateur non membre de la conversation ne peut pas lire les messages.
4. Les pièces jointes respectent les limites de taille et de type.
5. Blocage/signalement empêchent les interactions attendues.
6. Les appels audio/vidéo ne sont pas déclarés opérationnels tant que LiveKit et l'émission de jetons serveur n'ont pas été configurés et testés.

Cette archive ne migre ni ne supprime les messages existants.

## Étape 4 — hébergement à choisir plus tard
Le serveur est Node.js. Choisir un hébergeur qui prend en charge Node.js, les variables d'environnement, HTTPS et les journaux serveur. Pour une application avec fonctions persistantes, vérifier que le plan choisi autorise le processus serveur nécessaire. Ne pas publier avant d'avoir configuré les variables et passé le préflight.

Commandes locales (Node.js 20 ou plus récent) :
```bash
npm run check
npm test
npm run preflight
```
`npm run preflight` peut échouer tant que les IDs et intégrations obligatoires ne sont pas renseignés ; cela indique une configuration incomplète, pas que la base Appwrite existante est absente.

## État honnête de cette version
- Modifications apportées : version v76, guide de réutilisation de l'instance Appwrite et procédure de vérification de messagerie.
- Non effectué : aucune connexion réelle à ton projet Appwrite, aucun test avec tes comptes, aucun déploiement, aucune migration de données.
- Aucune clé privée ni aucun mot de passe ne sont nécessaires dans cette conversation.
