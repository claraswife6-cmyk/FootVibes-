# FootVibes v71 — Gestion des comptes

- Ajout de la section « Gestion des comptes » au tableau administrateur.
- Recherche par identifiant utilisateur.
- Boutons Suspendre / Réactiver avec motif obligatoire (5 à 500 caractères).
- Appels aux routes admin protégées et actualisation après décision.

## Limites connues
L’annuaire est partiel : il est construit à partir des demandes de certification, signalements et liste partenaire. La suspension s’applique aux API FootVibes qui vérifient l’identité côté serveur, mais ne désactive pas directement le compte ni ne révoque les sessions Appwrite.
