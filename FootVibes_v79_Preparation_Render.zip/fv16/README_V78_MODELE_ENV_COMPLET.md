# FootVibes v78 — modèle ENV complet

Ce dossier est un modèle de configuration, pas un jeu de clés opérationnelles. Aucune clé secrète n'est incluse.

## Mise en place
1. Copier `.env.example` vers `.env` sur une machine privée, ou créer ces variables dans la section Environment Variables / Secrets de l'hébergeur.
2. Garder `.env` hors du dépôt Git et ne jamais le joindre à un ZIP public. Vérifier que `.env` est listé dans `.gitignore`.
3. Renseigner les identifiants réels des bases, collections et buckets existants Appwrite; ne pas créer de doublons si les collections existent déjà.
4. Créer une clé API Appwrite serveur avec les scopes minimaux requis par les opérations réellement utilisées. Ne jamais utiliser cette clé dans le navigateur.
5. Mettre les clés API-Football, LiveKit, OneSignal et les secrets de paiement uniquement dans l'environnement serveur.
6. Ajouter l'URL publique de l'application dans `PUBLIC_APP_URL` après choix de l'hébergeur et du domaine.
7. Redémarrer le service après modification des variables, puis lancer les tests et vérifier les journaux sans afficher les secrets.

## Variables par service
- **Appwrite** : `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID`, `APPWRITE_API_KEY`, `APPWRITE_DATABASE_ID`, IDs des collections et bucket.
- **Messagerie / appels** : IDs Appwrite pour messages/appels et variables LiveKit. Les jetons LiveKit doivent être créés côté serveur après vérification de l'identité.
- **Football en direct** : `FOOTBALL_API_KEY` côté serveur. Vérifier les limites du forfait et les droits d'utilisation des données.
- **Notifications** : `PUBLIC_ONESIGNAL_APP_ID` peut être public; `ONESIGNAL_REST_API_KEY` reste strictement serveur.
- **Paiements** : URL de paiement provenant du compte marchand et secrets/webhooks fournis par le prestataire. Le modèle ne vérifie pas un paiement et ne doit pas activer automatiquement un compte sans confirmation serveur fiable.
- **Hébergement / administration** : URL publique, port, environnement et identifiants d'administration. Ne pas garder le mot de passe administrateur en clair dans un dépôt ou un ZIP.

## Sécurité et limites
- Les valeurs publiques déjà connues dans ce modèle sont l'endpoint Appwrite et le project ID fournis précédemment; confirmez-les dans la console avant déploiement.
- Les champs vides sont des emplacements à configurer, pas des clés générées.
- Les variables ne sont pas toutes forcément consommées par chaque module du code; vérifier le code du service concerné avant de considérer une intégration comme active.
- Ne jamais coller de clé privée, mot de passe, JWT ou secret de webhook dans ChatGPT. Si une clé a été exposée, la révoquer et en créer une nouvelle.
- Tester dans un environnement de préproduction avant la mise en production. Sauvegarder la base avant toute migration.
