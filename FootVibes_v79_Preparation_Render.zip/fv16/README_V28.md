# FootVibes v28 — Sécurisation du catalogue de diffusion

Cette version corrige un point important du catalogue : les URL de flux Premium ne sont plus envoyées au navigateur public. Une entrée Premium peut s'afficher comme disponibilité future, mais elle ne fournit aucun lien vidéo tant que le contrat de diffusion et le contrôle serveur des droits ne sont pas implémentés.

## Sources gratuites intégrées
- Seules les entrées `rightsConfirmed: true` avec URL HTTPS sur la liste de domaines autorisés sont proposées.
- Le lecteur intégré accepte uniquement les URL `youtube-nocookie.com/embed/VIDEO_ID` avec un identifiant vidéo de 11 caractères, et seulement pour les entrées gratuites.
- Les plateformes et les flux peuvent rester indisponibles selon les territoires, l'état du direct, les réglages d'intégration ou les règles du diffuseur.

## Limites
- Le champ `rightsConfirmed` est une déclaration de configuration de l'équipe, pas une vérification juridique automatique. Il faut conserver une preuve écrite des droits pour chaque événement.
- Aucun match n'est préchargé : aucun match n'est affirmé comme disponible sans configuration.
- Le contrôle d'accès Premium complet reste à implémenter avant tout contrat fournisseur ou activation payante.
- Les liens et le lecteur doivent être testés sur un domaine HTTPS de production. Les politiques du fournisseur s'appliquent toujours.

Documentation YouTube : https://developers.google.com/youtube/player_parameters/ et https://support.google.com/youtube/answer/171780
