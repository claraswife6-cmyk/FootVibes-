# FootVibes v52 — identité visuelle

La palette officielle comporte six couleurs :
- Noir `#101114` : structure et fonds.
- Blanc `#FFFFFF` : texte et contraste.
- Vert néon `#39FF14` : actions principales.
- Jaune `#FFD60A` : badge Partenaire.
- Rouge `#FF3030` : erreurs, alertes et refus.
- Bleu `#1877F2` : badge Certifié.

Les styles `.badge-partner` et `.badge-verified` sont disponibles pour les badges. Leur ajout visuel ne certifie pas automatiquement un utilisateur : l’attribution du badge bleu doit dépendre d’un contrôle administratif/serveur avant la mise en production.

## Contrôles
Exécuter `npm run check`, `npm test` et `npm run release:audit`. Ces contrôles structurels ne remplacent pas les essais sur appareils réels ni la configuration des services externes.
