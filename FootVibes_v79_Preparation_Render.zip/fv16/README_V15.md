# FootVibes v15 — favoris persistants

Cette version poursuit l’intégration Appwrite : le bouton « Enregistrer » des publications du flux utilise désormais une API serveur et une collection Appwrite de favoris. Les favoris sont associés à l’identifiant authentifié obtenu depuis le JWT, et non à un identifiant transmis librement par le navigateur.

## Configuration supplémentaire
1. Dans Appwrite, crée une collection pour les favoris avec `userId`, `itemId`, `itemType`, `itemName`, `itemUrl` (détails dans `docs/APPWRITE_SCHEMA_V13.md`).
2. Ajoute `APPWRITE_FAVORITES_COLLECTION_ID` dans les variables d’environnement du serveur.
3. Redémarre puis teste avec un compte connecté.

Les clés secrètes restent côté serveur. Les tests locaux ne peuvent pas valider Appwrite sans les identifiants de ton projet.
