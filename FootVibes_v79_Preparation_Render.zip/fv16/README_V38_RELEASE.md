# FootVibes v38 — Validation continue et préparation de publication

Cette version ajoute un workflow GitHub Actions qui vérifie la syntaxe, exécute les tests et construit l'image Docker à chaque push ou pull request. Elle ajoute aussi une commande `npm run release:check`.

## Commandes locales

```bash
npm run check
npm test
npm run preflight
npm run smoke:deploy
npm run release:check
```

`preflight` peut signaler des variables manquantes selon les services activés. Les tests locaux ne remplacent pas les tests de bout en bout avec des comptes fournisseurs réels.

## Avant une mise en production

- [ ] Configurer les secrets uniquement dans le gestionnaire de secrets de l'hébergeur / GitHub Actions, jamais dans le dépôt.
- [ ] Configurer Appwrite et vérifier les permissions des collections et des fichiers avec deux comptes distincts.
- [ ] Tester API-Football avec une clé valide et confirmer les quotas.
- [ ] Tester OneSignal sur les appareils cibles, y compris permissions et notifications en arrière-plan.
- [ ] Tester LiveKit avec deux utilisateurs, microphone/caméra, refus, raccrochage et réseau instable.
- [ ] Ne pas activer Premium sur une redirection client : exiger une confirmation serveur vérifiée du prestataire de paiement.
- [ ] N'afficher un flux vidéo que si la licence permet le territoire, l'intégration et le modèle gratuit/Premium choisis.
- [ ] Déployer en HTTPS, configurer sauvegardes, journaux, alertes et procédure de retour arrière.
- [ ] Tester sur iOS et Android réels avant de déclarer les applications mobiles prêtes.

## Limites

Le workflow CI valide le code et l'image, mais ne déploie pas automatiquement l'application. Les intégrations tierces doivent encore être configurées et testées dans leurs environnements respectifs. Aucun résultat de CI distant n'est affirmé tant que le workflow n'a pas été exécuté par GitHub.
