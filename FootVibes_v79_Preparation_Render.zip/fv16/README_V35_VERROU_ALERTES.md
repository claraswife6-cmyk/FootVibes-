# FootVibes v35 — verrou de traitement des alertes

Cette version ajoute un bail distribué (lease) pour éviter que plusieurs instances Node interrogent simultanément API-Football et envoient les mêmes alertes de buts.

## Configuration

- `APPWRITE_DATABASE_ID` doit désigner la base Appwrite.
- `APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID` doit désigner une collection privée utilisable par la clé API serveur pour lire/créer/supprimer des documents.
- Le serveur utilise les documents `goal-alert-state` et `goal-alert-worker-lock` dans cette collection. Les attributs nécessaires comprennent `scores`, `sent`, `updatedAt`, `ownerId` et `expiresAt` (les attributs inutilisés par un document peuvent rester absents si la configuration Appwrite le permet).
- Gardez `APPWRITE_API_KEY`, `FOOTBALL_API_KEY` et `ONESIGNAL_REST_API_KEY` uniquement dans les variables privées de l'hébergeur.

Le bail expire après 150 secondes et est supprimé à la fin du traitement si l'instance est toujours propriétaire. Si Appwrite n'est pas configuré, le serveur retombe sur le stockage fichier : ce mode convient uniquement à une instance unique.

## Limites

Ce verrou est une protection best-effort fondée sur un document Appwrite, pas une garantie transactionnelle absolue. Le traitement doit être testé avec plusieurs instances et des erreurs réseau avant la production. Les appels API, la disponibilité des appareils OneSignal et les droits d'accès Appwrite doivent être validés avec les vrais identifiants. Les notifications n'ont pas été testées sur des appareils réels dans cet environnement.
