# FootVibes v47 — Sécurité des transitions d’appel

Cette version durcit la signalisation des appels côté serveur :

- Seul le destinataire peut accepter ou refuser une invitation.
- Une invitation expirée ne peut plus être acceptée.
- Le client ne peut pas forcer le statut `missed` ; celui-ci est calculé côté serveur lors de la consultation.
- Un appel ne peut être terminé qu’après son acceptation (hors invitation encore en attente, qui peut être annulée).

## Vérifications locales

```bash
npm run check
npm test
npm run release:audit
```

Les tests sont structurels et locaux. Ils ne remplacent pas un test avec Appwrite et LiveKit configurés ni un essai sur deux appareils. Les notifications push et la sonnerie en arrière-plan ne sont pas garanties par cette version.
