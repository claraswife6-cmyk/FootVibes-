# FootVibes v43 — compteur de messages non lus

Cette version affiche dans la page Messagerie un compteur obtenu depuis `GET /api/social/messages/unread-count`. Le compteur se rafraîchit à l'ouverture de la page, à la demande et avec l'actualisation périodique de la conversation.

## Configuration
- Configurer Appwrite et `APPWRITE_MESSAGES_COLLECTION_ID` ainsi que `APPWRITE_DATABASE_ID` dans l'environnement serveur.
- La collection des messages doit contenir les attributs `recipientId` et `read` utilisés par le serveur.
- Se connecter avec un compte valide. Sans authentification, l'interface affiche `—`.

## Limites connues
- Le compteur est plafonné à 100 éléments par la requête; `100+` signifie « au moins 100 ».
- Il s'affiche dans la page Messagerie, pas encore comme badge global sur tous les éléments de navigation.
- Le test local vérifie le code et les contrôles automatisés, pas une instance Appwrite réelle ni deux appareils.
