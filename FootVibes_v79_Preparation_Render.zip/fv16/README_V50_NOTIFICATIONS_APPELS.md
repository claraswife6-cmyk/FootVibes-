# FootVibes v50 — notifications d'appels entrantes

## Nouveauté
Lorsqu'un utilisateur connecté crée une invitation d'appel audio/vidéo via `POST /api/social/calls`, le serveur enregistre d'abord l'invitation dans Appwrite puis tente d'envoyer une notification push OneSignal au destinataire enregistré. Le destinataire est déterminé côté serveur à partir de l'invitation persistée, et non d'une requête de notification libre envoyée par le client. La clé REST OneSignal reste exclusivement côté serveur.

Si OneSignal échoue ou n'est pas configuré, l'invitation d'appel est quand même créée. La réponse indique `pushNotification.sent` et, si besoin, une raison générique. Cela évite de confondre création de l'appel et livraison d'une notification.

## Configuration nécessaire
- `APPWRITE_CALLS_COLLECTION_ID` et `APPWRITE_DATABASE_ID`, avec les attributs de collection décrits dans les guides de versions précédentes.
- `PUBLIC_ONESIGNAL_APP_ID` et `ONESIGNAL_REST_API_KEY` configurés uniquement dans l'environnement privé du serveur.
- Les utilisateurs doivent s'être connectés à OneSignal avec leur identifiant Appwrite (`OneSignal.login(user.$id)`) et avoir autorisé les notifications sur leur appareil.

## Limites importantes
- Les contrôles automatiques vérifient la structure du code et les règles attendues ; ils ne prouvent pas la livraison d'une notification réelle.
- Les notifications push sur iOS exigent une configuration compatible avec l'application installée et les autorisations Apple. Une page web ouverte n'est pas équivalente à une application native iOS configurée.
- L'appel reste un système de signalisation ; la connexion audio/vidéo nécessite une configuration et des essais LiveKit réels.
- Le point d'envoi générique `/api/notifications/send` continue de limiter la cible à l'utilisateur authentifié. Ne pas supprimer cette restriction pour autoriser un client à notifier n'importe quel compte.

## Validation exécutée
`npm run check`, `npm test` (37 contrôles fumée), `npm run release:audit` réussis. L'audit ne teste pas les services externes, les identifiants ni le déploiement distant.
