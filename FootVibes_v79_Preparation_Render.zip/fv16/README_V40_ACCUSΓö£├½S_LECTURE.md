# FootVibes v40 — accusés de lecture

Cette version ajoute la mise à jour des messages entrants comme lus dans la messagerie Appwrite.

## Fonctionnement
- Lorsqu'une conversation est actualisée, le client repère les messages reçus qui ne sont pas encore marqués comme lus.
- Il envoie une requête authentifiée à `POST /api/social/messages/read` avec `{ "with": "ID_APPWRITE_DU_CONTACT" }`.
- Le serveur vérifie l'identité Appwrite, ne cible que les messages dont le contact est l'expéditeur et l'utilisateur connecté le destinataire, puis tente de mettre `read` à `true`.
- Les permissions Appwrite doivent autoriser le destinataire à mettre à jour le document. Les documents qui refusent cette mise à jour ne sont pas comptés comme mis à jour.

## Configuration Appwrite requise
La collection de messages doit contenir les attributs `senderId` (string), `recipientId` (string), `text` (string), `mediaUrl` (string) et `read` (boolean). Les documents doivent avoir des permissions de lecture pour les deux participants et de mise à jour pour le destinataire.

## Vérification locale
```bash
npm run check
npm test
npm run release:audit
```

Ces tests valident la syntaxe, les contrôles structurels et le démarrage local. Ils ne remplacent pas un test avec un vrai projet Appwrite et deux comptes réels. Les accusés de lecture ne constituent pas des confirmations de livraison push et la messagerie utilise toujours l'actualisation périodique existante.
