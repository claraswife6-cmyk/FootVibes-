# FootVibes v33 — persistance des alertes de buts

Cette version permet d'enregistrer les abonnements aux alertes dans une collection Appwrite afin qu'ils soient partagés entre plusieurs instances du serveur. Si `APPWRITE_GOAL_ALERTS_COLLECTION_ID` n'est pas défini, le prototype conserve le fichier local et le serveur indique explicitement ce mode.

## Configuration Appwrite

Dans la base définie par `APPWRITE_DATABASE_ID`, créer une collection et renseigner son ID dans `APPWRITE_GOAL_ALERTS_COLLECTION_ID`. Ajouter les attributs :

- `userId`: string, requis, indexé
- `fixtureId`: integer, requis, indexé
- `createdAt`: string, requis

Le serveur doit avoir `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID`, `APPWRITE_API_KEY` et `APPWRITE_DATABASE_ID`. La clé API Appwrite reste privée sur le serveur.

## Limites importantes

- Le suivi des abonnements utilise Appwrite lorsqu'il est configuré, mais l'état des scores déjà observés et des notifications envoyées est encore stocké dans un fichier local. Pour un déploiement multi-instance, il faudra également déplacer cet état dans une base partagée et ajouter un verrou distribué pour éviter les doublons.
- Le processus Node doit rester actif pour interroger API-Football. Il n'existe pas de garantie de livraison si le serveur ou les fournisseurs sont indisponibles.
- Les alertes réelles nécessitent API-Football et OneSignal configurés, ainsi que des appareils associés aux utilisateurs via `external_id`.
- Cette version n'a pas été testée avec un projet Appwrite ou des appareils OneSignal réels dans cet environnement.
