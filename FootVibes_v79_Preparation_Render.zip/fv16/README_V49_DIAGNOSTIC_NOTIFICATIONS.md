# FootVibes v49 — Vérification des notifications push

Cette version consolide les contrôles de configuration autour de OneSignal.

## Configuration requise
- `PUBLIC_ONESIGNAL_APP_ID` côté serveur et exposé uniquement comme identifiant public.
- `ONESIGNAL_REST_API_KEY` exclusivement côté serveur. Ne jamais la placer dans `app.js`, le navigateur ou Git.
- HTTPS en production, domaine autorisé dans OneSignal, service worker configuré selon le mode Web Push choisi.
- Pour iPhone, vérifier les conditions de Web Push (application ajoutée à l’écran d’accueil sur versions compatibles) ou préparer une application native avec APNs.

## Vérifications locales
```bash
npm run check
npm test
npm run release:audit
```

Les tests automatisés contrôlent la présence des protections et du parcours d’activation. Ils ne prouvent pas la livraison d’une notification réelle : il faut tester avec un projet OneSignal configuré et au moins deux appareils/comptes. Les notifications d’appel ne sont pas garanties si l’application est fermée ou suspendue.
