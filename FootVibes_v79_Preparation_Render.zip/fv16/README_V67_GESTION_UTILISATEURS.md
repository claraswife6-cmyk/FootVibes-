# FootVibes v67 — Index administratif des comptes

Ajout de `GET /api/admin/users`, protégé par la session administrateur. Il construit un index partiel des identifiants déjà présents dans les demandes de certification, les signalements et la liste serveur des partenaires, puis affiche les sources connues, le statut certifié/partenaire et un compteur de signalements.

**Limite importante :** ce n'est pas un annuaire complet Appwrite et les données locales ne permettent pas de rechercher tous les utilisateurs de la plateforme. L'endpoint l'indique explicitement (`completeDirectory: false`). Aucun compte n'est suspendu par cette version. Pour un annuaire complet, il faudra intégrer l'API Users Appwrite avec une clé serveur à privilèges minimaux et définir une procédure de suspension réellement appliquée par le backend.

Validation effectuée : `npm run check` et `npm test`.
