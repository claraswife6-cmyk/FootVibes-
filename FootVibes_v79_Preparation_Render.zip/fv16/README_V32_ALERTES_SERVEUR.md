# FootVibes v32 — Alertes de buts côté serveur

## Nouveautés
- Un utilisateur connecté à Appwrite peut s’abonner/désabonner aux alertes d’un match via `/api/football/alerts/subscribe` et `/unsubscribe`.
- Les abonnements sont conservés dans `data/goal-alert-subscriptions.json` avec permissions de fichier privées.
- Le serveur vérifie les matchs en direct toutes les 60 secondes via API-Football et envoie une notification OneSignal aux comptes abonnés quand le score augmente.
- L’état des scores est conservé dans `data/goal-alert-state.json` pour limiter les doublons après redémarrage.

## Configuration requise
Renseigner côté serveur : `FOOTBALL_API_KEY`, `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID`, `PUBLIC_ONESIGNAL_APP_ID`, `ONESIGNAL_REST_API_KEY`. Les clés privées restent dans l’environnement serveur. Chaque utilisateur doit être connecté à Appwrite et son identifiant doit être associé à un appareil OneSignal avec `external_id` correspondant à l’ID Appwrite.

## Limites et exploitation
- Le service doit rester démarré pour surveiller les matchs. Sur une plateforme qui suspend les processus ou sur plusieurs instances, utiliser un worker planifié unique et un stockage partagé/transactionnel.
- Le stockage actuel des abonnements est un fichier JSON local ; il convient pour le prototype mais doit être remplacé par une base persistante partagée avant la production.
- Les alertes dépendent de la couverture/quota API-Football, de la configuration OneSignal et des permissions push de l’appareil. Le délai théorique de détection est d’environ 60 secondes, sans garantie de livraison instantanée.
- Les contrôles locaux ne remplacent pas les tests sur de vrais comptes Appwrite et appareils.
