# FootVibes v70 — Gestion des comptes

## API administrateur
`POST /api/admin/users/:userId/status` avec session administrateur valide.

Corps JSON pour suspendre : `{"status":"suspended","reason":"Motif documenté de la suspension"}`

Corps JSON pour réactiver : `{"status":"active","reason":"Motif de la réactivation"}`

Le motif est obligatoire (5 à 500 caractères). La décision est persistée dans `data/account-status.json` et inscrite dans `data/admin-audit.json`. Le statut est inclus dans l’index partiel `GET /api/admin/users`. Les requêtes utilisant `appwriteIdentity` sont refusées avec HTTP 403 lorsque le compte est suspendu.

## Limites importantes
Cette version bloque les API FootVibes qui passent par le contrôle d’identité du serveur. Elle ne désactive pas le compte ni ne révoque les sessions dans Appwrite : l’utilisateur peut encore avoir une session Appwrite active et les opérations Appwrite directes depuis le client ne sont pas automatiquement bloquées. L’annuaire des utilisateurs reste partiel, il n’est pas récupéré depuis l’annuaire complet Appwrite.
