# FootVibes v59 — droits du compte côté serveur

## Ajout
- `GET /api/account/entitlements` retourne les droits du compte connecté après validation de la session Appwrite.
- Le rôle `partner` dépend exclusivement de `FOOTVIBES_PARTNER_USER_IDS` côté serveur ; sinon le compte est `classic`.
- La certification reste distincte du rôle Partenaire.
- Les capacités publier, messagerie et appels sont retournées comme informations de référence pour l'interface.
- La capacité de diffusion professionnelle exige à la fois l'accès Partenaire et la certification.

## Réponse indicative
`{ userId, displayName, role, verified, capabilities, source, note }`

## Limites à traiter avant production
Cet endpoint informe l'interface mais ne remplace pas les contrôles d'autorisation présents sur chaque route d'action. La liste Partenaire reste une configuration manuelle côté serveur ; la validation de preuve YelenPay ne crédite pas automatiquement un compte.

## Vérification
Exécuter `npm run release:check` avec Node.js 20 ou plus récent. Les tests sont des contrôles structurels et locaux, pas des essais d'intégration Appwrite/YelenPay sur un compte réel.
