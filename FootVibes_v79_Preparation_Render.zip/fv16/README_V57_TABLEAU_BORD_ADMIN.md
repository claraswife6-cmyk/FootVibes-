# FootVibes v57 — Tableau de bord administrateur

## Nouveauté
Après connexion administrateur, la page affiche une synthèse visuelle des demandes de certification en attente, approuvées et refusées, du nombre de comptes certifiés et des comptes Partenaire autorisés par configuration serveur. Le bouton « Actualiser » recharge les chiffres depuis `GET /api/admin/overview`.

## Limites importantes
- L’endpoint reste protégé par la session administrateur.
- Les comptes Partenaire sont comptés depuis `FOOTVIBES_PARTNER_USER_IDS`; ce chiffre ne prouve pas qu’un paiement YelenPay a été reçu.
- Les chiffres de certification viennent des demandes stockées localement sur le serveur.
- Cette mise à jour n’effectue pas de test réel de YelenPay, Appwrite, OneSignal, LiveKit ni du déploiement.

## Vérifications locales
Exécuter `npm run check`, `npm test` et `npm run release:audit`. L’audit est structurel et ne remplace pas des tests d’intégration ou sur appareils.
