# FootVibes v21 — Appels LiveKit

Cette version ajoute dans la page Messagerie des commandes d'appel audio et vidéo. Le navigateur récupère un jeton LiveKit signé par le serveur (`POST /api/livekit/token`) après vérification de la session Appwrite, puis charge le client LiveKit depuis un CDN HTTPS.

## Configuration requise

Renseigner dans l'environnement privé du serveur :
- `PUBLIC_APPWRITE_ENDPOINT`
- `PUBLIC_APPWRITE_PROJECT_ID`
- `PUBLIC_LIVEKIT_URL` (URL WebSocket `wss://...` du serveur LiveKit)
- `LIVEKIT_API_KEY`
- `LIVEKIT_API_SECRET`

Ne jamais placer la clé secrète dans le navigateur ou le dépôt Git.

## Utilisation

1. Déployer le serveur et configurer Appwrite + LiveKit.
2. Les deux utilisateurs doivent être connectés et ouvrir la conversation l'un avec l'autre.
3. Saisir l'identifiant Appwrite du destinataire puis cliquer sur Appel audio ou Appel vidéo.
4. Le destinataire doit démarrer l'appel dans la même conversation pour rejoindre le même salon.
5. Autoriser le navigateur à utiliser le microphone et, pour la vidéo, la caméra.
6. Cliquer sur Terminer l'appel pour couper la connexion.

## Limites connues

- Cette intégration est une première version de l'interface d'appel LiveKit, pas un service de téléphonie complet. Les appels entrants ne sonnent pas automatiquement : les deux participants doivent rejoindre le salon depuis la conversation.
- Les appels nécessitent un serveur LiveKit accessible, HTTPS en production et des permissions microphone/caméra accordées.
- Le client LiveKit est chargé depuis un CDN ; une connexion internet est nécessaire.
- Il faut encore ajouter une signalisation d'appel entrant et des notifications push pour une expérience complète.
- Les tests locaux ne remplacent pas un test d'appel entre deux appareils réels.
