# FootVibes v33

Nouvelle évolution : persistance des abonnements aux alertes de buts dans Appwrite, avec mode fichier local explicite en secours pour le développement.

Consultez `README_V33_ALERTES_PERSISTANTES.md` pour le schéma Appwrite et les limites de déploiement.

Commandes : `npm run check` puis `npm test`.
