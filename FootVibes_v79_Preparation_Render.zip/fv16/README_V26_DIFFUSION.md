# FootVibes v26 — catalogue de diffusion autorisée

## Ajouts
- Endpoint serveur `GET /api/streams` qui lit `FOOTVIBES_STREAM_CATALOG_JSON`.
- Le serveur n’expose que les entrées avec `rightsConfirmed: true`, un accès `free` ou `premium`, une URL HTTPS et un domaine autorisé (FIFA/FIFA+, YouTube, DAZN).
- La page Football présente les diffusions configurées et un état honnête lorsque le catalogue est vide.
- Aucun flux n’est inventé ou préchargé : le catalogue est vide par défaut.

## Configuration
Renseigner `FOOTVIBES_STREAM_CATALOG_JSON` dans les variables privées de l’hébergeur. Exemple de structure JSON (à remplacer par un événement réellement autorisé) :

```json
[{
  "id": "event-1",
  "title": "Nom du match autorisé",
  "competition": "Compétition",
  "access": "free",
  "url": "https://www.fifa.com/fifaplus",
  "provider": "Diffuseur officiel",
  "territory": "BF",
  "rightsConfirmed": true
}]
```

`rightsConfirmed` est une déclaration de configuration, pas une vérification automatique du contrat. Un responsable FootVibes doit vérifier les droits, les territoires, les dates et les conditions du diffuseur avant d’ajouter une entrée.

## Limites importantes
- Cette version ouvre les URL officielles du diffuseur; elle ne fournit pas un flux vidéo intégré universel.
- L’intégration d’un lecteur intégré exige une URL d’intégration explicitement autorisée par le diffuseur et une validation des domaines/CSP.
- Les événements Premium restent informatifs tant que l’entitlement Premium n’est pas vérifié côté serveur et que le contrat de diffusion n’est pas signé. Ne pas utiliser un simple lien de paiement pour accorder l’accès vidéo.
- FIFA+, DAZN et les autres plateformes peuvent imposer géoblocage, abonnement ou conditions particulières. La disponibilité au Burkina Faso doit être vérifiée match par match.

## Vérifications
`npm run check` et `npm test` exécutés localement. Les services externes et les droits de diffusion n’ont pas été testés ou validés.
