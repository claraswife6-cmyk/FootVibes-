# FootVibes v11 — base serveur intégrée

Cette archive est une base de déploiement web Node.js. Elle ne constitue pas à elle seule une application mobile App Store/Google Play entièrement terminée.

## Déploiement Render
- Root directory : racine du dépôt (le fichier `package.json` doit être ici)
- Build command : `npm install`
- Start command : `npm start`
- Health check : `/api/health`
- Node.js : 20+

## Variables d'environnement
Copiez les variables de `.env.example` dans Render → service → Environment. Ne téléversez jamais `.env` et ne placez aucune clé secrète dans GitHub ou dans le navigateur.

## Routes serveur ajoutées
- `GET /api/integrations/status` : état des variables configurées; ne révèle pas leurs valeurs.
- `GET /api/football/fixtures?...` : proxy API-Football pour les rencontres.
- `GET /api/football/standings?...`, `/teams`, `/leagues`, `/players`, `/fixture`, `/events`, `/statistics`, `/lineups` : proxy avec liste blanche des routes et paramètres.
- `POST /api/livekit/token` : exige `Authorization: Bearer <JWT Appwrite>`; vérifie la session via Appwrite avant de signer un jeton LiveKit limité à un salon et valable une heure.

## Limites importantes
- Le webhook YelenPay reste volontairement désactivé tant que le protocole officiel de signature/validation n'est pas implémenté et testé. Une redirection ou une preuve de paiement ne suffit jamais à activer un abonnement.
- Les routes serveur ne rendent pas automatiquement toutes les pages sociales opérationnelles. La persistance des publications, likes, commentaires, médias, messages, notifications, modération et abonnements doit être reliée aux collections Appwrite et testée.
- OneSignal est déclaré/configurable mais l'envoi de notifications nécessite encore l'implémentation du flux applicatif et la configuration mobile APNs/FCM.
- Une URL web Render n'est pas une application iOS/Android native. Les builds mobiles, tests appareils, signatures et soumissions aux stores restent des étapes séparées.

## Tests
Exécuter `npm run check` et `npm test` avec Node.js 20+. Les tests locaux ne vérifient pas des identifiants de services propriétaires ni ne garantissent leur disponibilité.
