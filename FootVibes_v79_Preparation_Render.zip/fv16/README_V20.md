# FootVibes v20 — pièces jointes dans la messagerie

Cette version ajoute la sélection et l'envoi d'une photo ou d'une vidéo dans une conversation existante.

## Fonctionnement
- Le formulaire de messagerie accepte un texte, un média, ou les deux.
- Les fichiers acceptés sont JPEG, PNG, WebP, GIF, MP4 et MOV/QuickTime, jusqu'à 10 Mo.
- Le client crée un JWT Appwrite, envoie le média à `POST /api/social/media`, puis enregistre le message avec `mediaUrl` via `POST /api/social/messages`.
- La conversation continue de se rafraîchir toutes les cinq secondes pendant que la page reste ouverte.

## Configuration nécessaire
Configurez côté serveur les variables Appwrite déjà documentées dans `.env.example`, en particulier `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID`, `APPWRITE_API_KEY`, `APPWRITE_DATABASE_ID`, `APPWRITE_MESSAGES_COLLECTION_ID` et `APPWRITE_MEDIA_BUCKET_ID`. La clé API secrète doit rester côté serveur. Configurez le bucket Storage et les permissions de lecture nécessaires pour que le destinataire puisse ouvrir les médias.

## Limites connues
- La synchronisation est du polling toutes les cinq secondes, pas Appwrite Realtime natif.
- Les pièces jointes apparaissent comme liens de média dans la conversation; l'aperçu intégré n'est pas encore implémenté.
- Les appels audio/vidéo LiveKit, les notifications OneSignal et les webhooks de paiement vérifiés restent à intégrer.
- Les tests du dépôt sont des contrôles locaux; ils ne prouvent pas une connexion réussie au projet Appwrite de production.
