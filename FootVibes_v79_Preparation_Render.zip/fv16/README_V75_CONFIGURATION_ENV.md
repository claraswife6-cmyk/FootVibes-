# FootVibes v75 — Configuration de l’environnement

Cette version conserve le code de base v74 et prépare la configuration sans enregistrer de secret.

## Configuration locale / serveur

1. Copier `.env.example` vers `.env` sur la machine qui héberge le serveur.
2. Les seules valeurs déjà préremplies sont les informations publiques Appwrite communiquées par le propriétaire :
   - `PUBLIC_APPWRITE_ENDPOINT=https://fra.cloud.appwrite.io/v1`
   - `PUBLIC_APPWRITE_PROJECT_ID=6ad4e92a0021cc34d98c`
3. Ajouter les clés secrètes uniquement dans le gestionnaire de variables d’environnement de l’hébergeur ou dans le fichier `.env` local non partagé.
4. Ne jamais envoyer les secrets dans le chat, les captures d’écran, le dépôt Git ou `config/env.js`.
5. `PUBLIC_APP_URL` reste vide jusqu’à ce qu’un domaine/URL de déploiement soit choisi.

## Variables facultatives par service

- Appwrite serveur : `APPWRITE_API_KEY`, `APPWRITE_DATABASE_ID`, `APPWRITE_USERS_COLLECTION_ID`, `APPWRITE_POSTS_COLLECTION_ID`, `APPWRITE_COMMENTS_COLLECTION_ID`, `APPWRITE_CALLS_COLLECTION_ID`, `APPWRITE_MESSAGES_COLLECTION_ID`, `APPWRITE_MEDIA_BUCKET_ID`. Créer une clé API serveur avec les permissions minimales nécessaires; ne pas utiliser de clé administrateur globale inutilement.
- Scores : `FOOTBALL_API_KEY`.
- Appels : `PUBLIC_LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`.
- Notifications : `PUBLIC_ONESIGNAL_APP_ID`, `ONESIGNAL_REST_API_KEY`.
- Paiements : `YELENPAY_PREMIUM_URL`, `YELENPAY_PARTNER_URL`, `PAYMENT_PROVIDER_SECRET`, `PAYMENT_WEBHOOK_SECRET`.
- Admin : `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_SESSION_SECRET`. Utiliser un mot de passe unique et fort.

## Important

L’ajout des variables ne prouve pas que les intégrations externes fonctionnent. Après configuration, exécuter `npm run check`, `npm test` et `npm run preflight`, puis tester avec des comptes de test. Les clés privées ne sont pas incluses dans cette archive.
