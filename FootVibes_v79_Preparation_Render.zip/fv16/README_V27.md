# FootVibes v27 — Lecteur des diffusions gratuites autorisées

Cette version complète le catalogue de diffusions légales : si une entrée gratuite possède un `embedUrl` YouTube-nocookie valide et que ses droits ont été confirmés (`rightsConfirmed: true`), l'interface affiche un lecteur intégré. Sinon, elle ne propose que le lien officiel du diffuseur.

## Configuration

La variable serveur `FOOTVIBES_STREAM_CATALOG_JSON` accepte une liste d'entrées. Exemple de structure (à utiliser uniquement pour un contenu réellement autorisé) :

```json
[{"id":"exemple-live","title":"Événement autorisé","competition":"Compétition","access":"free","url":"https://www.fifa.com/fifaplus","provider":"Diffuseur officiel","territory":"BF","rightsConfirmed":true,"embedUrl":"https://www.youtube-nocookie.com/embed/VIDEO_ID"}]
```

Ne remplacez `VIDEO_ID` que par l'identifiant d'une vidéo officielle dont le diffuseur autorise l'intégration. Le serveur filtre les URL et n'accepte l'intégration que pour les contenus gratuits sur `youtube-nocookie.com`. Les vidéos peuvent rester indisponibles selon le territoire ou les paramètres du diffuseur.

## Limites importantes

- Aucun flux de match n'est préchargé ou inventé dans le catalogue.
- Aucun contrat de diffusion n'est fourni avec le projet.
- Les entrées Premium ne doivent pas être utilisées avant contrat écrit et contrôle des droits/abonnements côté serveur.
- Cette intégration ne permet pas de contourner les restrictions géographiques, publicités ou protections du diffuseur.
- Tests automatisés et syntaxe ne remplacent pas un essai réel avec une source vidéo autorisée.
