# FootVibes v72 — Annuaire Appwrite et statut réel des comptes

## Changements
- Lorsque `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID` et `APPWRITE_API_KEY` sont configurés côté serveur, la route `GET /api/admin/users` charge les utilisateurs via l’API Users d’Appwrite, avec pagination serveur et filtres locaux.
- La route protégée `POST /api/admin/users/:userId/status` appelle l’API de statut Appwrite (`PUT /users/:userId/status`) avant d’enregistrer l’état local et l’événement d’audit.
- Si Appwrite refuse la modification ou si les identifiants serveur manquent, l’API ne prétend pas que l’action a réussi.
- Le statut local reste vérifié par `appwriteIdentity` pour bloquer les routes FootVibes qui passent par cette vérification.

## Configuration obligatoire
Définir dans `.env` côté serveur :
- `PUBLIC_APPWRITE_ENDPOINT`
- `PUBLIC_APPWRITE_PROJECT_ID`
- `APPWRITE_API_KEY` (clé serveur secrète avec les permissions Appwrite nécessaires pour lire et modifier les utilisateurs)
- `ADMIN_EMAIL` et `ADMIN_PASSWORD`

Ne jamais placer `APPWRITE_API_KEY` dans `app.js`, dans un fichier public ou dans une variable `PUBLIC_*`.

## Limites
- La liste est plafonnée à 5 000 utilisateurs par requête afin d’éviter un chargement sans limite; `completeDirectory` indique si ce plafond a été atteint.
- Le statut Appwrite est désactivé/activé via son API. Cela ne signifie pas que toutes les sessions ou tous les jetons déjà émis sont instantanément révoqués dans tous les services externes.
- Les routes FootVibes qui n’appellent pas `appwriteIdentity` doivent encore être auditées pour vérifier qu’elles refusent un compte suspendu.
- L’intégration n’a pas été testée contre un projet Appwrite réel, car aucune clé privée de projet n’est disponible dans cet environnement.

## Vérifications
`npm run check` et `npm test` valident la syntaxe et les contrôles locaux; ils ne remplacent pas un test d’intégration avec Appwrite.
