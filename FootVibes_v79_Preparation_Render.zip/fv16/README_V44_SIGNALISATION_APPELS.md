# FootVibes v44 — Signalisation des appels entrants

Cette version ajoute une base de signalisation côté serveur pour créer une invitation audio/vidéo, consulter les invitations entrantes en attente et accepter/refuser/terminer une invitation.

## Configuration Appwrite

1. Créer une collection dédiée et renseigner `APPWRITE_CALLS_COLLECTION_ID` dans `.env`.
2. Attributs requis : `callerId` (string), `recipientId` (string), `roomName` (string), `callType` (string), `status` (string), `expiresAt` (datetime/string selon le schéma Appwrite choisi).
3. Le serveur doit disposer de `APPWRITE_API_KEY` et des identifiants Appwrite déjà documentés.
4. Créer les index nécessaires pour `recipientId` et `status` si Appwrite les exige pour les requêtes combinées.

## Routes ajoutées

- `POST /api/social/calls` avec `{ "recipientId": "...", "callType": "audio" | "video" }` : crée une invitation expirant après 90 secondes.
- `GET /api/social/calls` : retourne les invitations `ringing` non expirées destinées à l’utilisateur connecté.
- `PATCH /api/social/calls/:id` avec `{ "status": "accepted" | "rejected" | "ended" | "missed" }` : met à jour le statut après vérification que l’utilisateur est appelant ou destinataire.

## Limites importantes

Cette signalisation ne fait pas sonner le téléphone à elle seule. Il reste à intégrer la consultation périodique ou Appwrite Realtime dans l’interface, les notifications push (notamment iOS), l’expiration/cleanup côté serveur, et l’émission des jetons LiveKit côté serveur. L’endpoint ne constitue pas une preuve que les appels fonctionnent en production ; tester avec deux comptes réels avant toute publication. Les notifications et les appels natifs iOS nécessitent une configuration supplémentaire.
