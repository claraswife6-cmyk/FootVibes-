# FootVibes v45 — Interface des appels entrants

Cette version relie l’écran de messagerie aux routes de signalisation Appwrite déjà présentes : création d’une invitation avant l’appel, interrogation des appels entrants, boutons Accepter/Refuser et utilisation du salon fourni par l’invitation pour rejoindre LiveKit.

## Configuration nécessaire
- `APPWRITE_DATABASE_ID` et `APPWRITE_CALLS_COLLECTION_ID` configurés côté serveur.
- Collection Appwrite avec `callerId`, `recipientId`, `roomName`, `callType`, `status`, `expiresAt` et permissions permettant au serveur d’écrire les documents.
- `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET` configurés côté serveur.
- Deux comptes utilisateurs, autorisation microphone/caméra, HTTPS et test avec deux appareils/navigateurs.

## Limites connues
- La liste des appels entrants est interrogée toutes les 5 secondes ; ce n’est pas une notification push ni une sonnerie système.
- La réception, les permissions Appwrite, l’audio/vidéo et les changements d’état doivent être validés sur une instance réelle.
- Le navigateur charge `livekit-client` depuis un CDN.
- Le code ne prouve pas qu’un appel fonctionne sans configurer et tester les services externes.
