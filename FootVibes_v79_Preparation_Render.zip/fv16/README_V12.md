# FootVibes v12 — intégrations serveur en progression

Cette version ajoute les premières routes sociales Appwrite réellement reliées au backend: lecture des publications, création de publication avec JWT Appwrite vérifié côté serveur, et compteur de likes. Les scores API-Football et le jeton LiveKit restent derrière des routes serveur. Les secrets doivent être définis dans Render, Replit, Railway ou un autre serveur via les variables d'environnement.

## Déploiement
- Runtime: Node.js 20+
- Build: `npm install`
- Start: `npm start`
- `package.json` doit être à la racine du dépôt.
- Ajouter les variables de `.env.example` dans le tableau de bord de l'hébergeur. Ne jamais committer `.env`.

## Appwrite
Lire `docs/APPWRITE_SCHEMA_V12.md` avant de configurer `APPWRITE_DATABASE_ID` et `APPWRITE_POSTS_COLLECTION_ID`. Les attributs de collection doivent correspondre exactement au schéma documenté.

## Statut honnête
Cette archive n'est pas encore un produit mobile prêt pour l'App Store/Google Play et n'affirme pas que toutes les fonctions sont terminées. Les publications et le compteur de likes sont connectables à Appwrite; le média, commentaires, messages, favoris, profils persistants, appels réels de bout en bout, notifications, modération complète et webhook YelenPay signé nécessitent encore des implémentations et des tests. Le webhook de paiement répond volontairement 503 pour éviter une activation non vérifiée. Les clés et URLs restent à configurer par le propriétaire.
