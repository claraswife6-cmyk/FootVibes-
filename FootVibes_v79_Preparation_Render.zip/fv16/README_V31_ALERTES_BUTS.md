# FootVibes v31 — Alertes de buts

Cette version ajoute un suivi local d'un match sélectionné et des notifications du navigateur lors d'une augmentation du score.

## Fonctionnement et limites
- L'utilisateur doit ouvrir la page Football, sélectionner un match et cliquer sur « Suivre ce match ».
- Le navigateur doit autoriser les notifications. L'alerte repose sur le score renvoyé par API-Football et vérifie les matchs en direct environ toutes les 30 secondes.
- Le suivi nécessite `FOOTBALL_API_KEY` valide et des quotas suffisants.
- Les alertes ne sont garanties que tant que la page reste ouverte et que le navigateur permet l'exécution. Ce n'est pas une notification push serveur fiable en arrière-plan.
- Le suivi est stocké localement sur l'appareil. Pour une version de production, préférer des préférences utilisateur persistées côté serveur et un worker de surveillance des matchs avec OneSignal.


Voir aussi `README_V32_ALERTES_SERVEUR.md` pour le suivi des buts côté serveur et les prérequis OneSignal.
