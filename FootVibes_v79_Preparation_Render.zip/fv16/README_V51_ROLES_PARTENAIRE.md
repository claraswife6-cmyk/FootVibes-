# FootVibes v51 — accès réservé aux Partenaires

## Règles appliquées côté serveur

- Les utilisateurs classiques peuvent consulter le fil et interagir avec les contenus publics selon les fonctions disponibles.
- La création de publications (`POST /api/social/posts`) et l’envoi de médias (`POST /api/social/media`) sont réservés aux comptes Partenaire.
- Les endpoints de messagerie (lecture, envoi, accusés de lecture, compteur non lus) et d’appels (création, liste, suivi et mise à jour) sont réservés aux comptes Partenaire.
- Une requête d’un compte non autorisé reçoit HTTP 403 avec le code `PARTNER_REQUIRED`.
- La vérification est faite sur le serveur. Le client ne peut pas s’accorder le rôle en modifiant ses préférences Appwrite.

## Configurer les Partenaires

Définir dans l’environnement serveur `FOOTVIBES_PARTNER_USER_IDS` avec les identifiants Appwrite des comptes Partenaire validés, séparés par des virgules :

```env
FOOTVIBES_PARTNER_USER_IDS=appwriteUserIdA,appwriteUserIdB
```

Ne pas exposer cette variable dans l’interface ou dans le dépôt public. Une preuve de paiement ou un lien de paiement ne suffit pas à donner automatiquement le statut Partenaire. Ajouter un identifiant seulement après confirmation du paiement par un processus d’administration fiable. Les webhooks YelenPay vérifiés ne sont pas encore intégrés.

## Limites

- Ce contrôle serveur ne remplace pas les permissions Appwrite : vérifier également les permissions de base de données et de stockage.
- Les restrictions sont testées par contrôles structurels et tests fumée, pas par un test avec de vrais comptes Appwrite en production.
- Les appels dépendent toujours de la configuration LiveKit, Appwrite et OneSignal; la livraison des push n’est pas garantie quand un appareil est hors ligne.
