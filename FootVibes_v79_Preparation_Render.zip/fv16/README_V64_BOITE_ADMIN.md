# FootVibes v64 — Boîte administrative

- Arrière-plans fournis par l’utilisateur ajoutés dans `assets/admin/`.
- Écran d’administration organisé avec bannière, carte de connexion et icônes SVG intégrées.
- Adresse autorisée fixée à `claraswife6@gmail.com` côté serveur.
- Le mot de passe reste exclusivement dans la variable `ADMIN_PASSWORD` du fichier `.env` sur le serveur; aucun mot de passe n’est intégré au ZIP.

## Configuration
1. Copier `.env.example` vers `.env` sur le serveur.
2. Définir un mot de passe long et unique dans `ADMIN_PASSWORD`.
3. Garder `ADMIN_EMAIL=claraswife6@gmail.com`.
4. Redémarrer le serveur et tester la connexion.

Le code limite l’adresse, mais la connexion réelle reste impossible tant qu’un mot de passe n’a pas été défini côté serveur. Utiliser HTTPS en production.
