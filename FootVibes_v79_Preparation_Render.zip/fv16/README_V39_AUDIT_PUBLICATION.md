# FootVibes v39 — Audit de préparation à la publication

Cette version ajoute `npm run release:audit`, un contrôle structurel des fichiers et de quelques protections de l'image Docker.

## Vérifications locales

```bash
npm install
npm run check
npm test
npm run release:audit
npm run preflight
npm run smoke:deploy
```

`preflight` peut terminer avec un code non nul si des variables ne sont pas configurées. C'est attendu tant que les services ne sont pas renseignés.

## Avant d'ouvrir au public

1. Déployer dans un environnement de test HTTPS avec des secrets fournis par l'hébergeur.
2. Vérifier inscription, connexion, autorisations Appwrite et stockage de médias avec deux comptes distincts.
3. Tester les scores avec une clé API-Football valide et contrôler les limites de requêtes.
4. Tester les alertes OneSignal sur des appareils réels, y compris permissions et arrière-plan.
5. Tester les appels LiveKit entre deux appareils réels.
6. Ne pas activer les droits payants avant une confirmation de paiement authentifiée par webhook serveur.
7. Vérifier les autorisations de chaque diffusion vidéo et la disponibilité territoriale au Burkina Faso.
8. Tester sauvegarde/restauration et procédure de retour arrière.
9. Faire une revue de sécurité et vérifier la politique de confidentialité avant publication mobile.

## Limites

Un audit structurel ou des tests unitaires réussis ne prouvent pas que les intégrations externes fonctionnent. Aucun flux vidéo, paiement, appel ou push n'est réputé validé sans test réel et configuration correspondante.
