/* Service worker requis par OneSignal Web Push. Déployer à la racine du domaine. */
importScripts('https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js');
