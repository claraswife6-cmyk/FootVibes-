# FootVibes v61 — Sécurité des jetons LiveKit

## Changement
La route `POST /api/livekit/token` vérifie désormais l’accès Partenaire côté serveur après validation de la session Appwrite et avant de créer un jeton média. Un compte absent de `FOOTVIBES_PARTNER_USER_IDS` reçoit une réponse `403 PARTNER_REQUIRED`.

## Vérification
Lancer `npm test` et `npm run check`. Le test fumée vérifie la présence de la barrière côté serveur ; il ne simule pas un service Appwrite/LiveKit en production.

## Limites
Configurer les variables d’environnement, tester avec des comptes Classic et Partenaire distincts, puis vérifier les appels réels sur les environnements de test. La validation d’un compte Partenaire demeure une action serveur contrôlée, indépendante des preuves de paiement en attente.
