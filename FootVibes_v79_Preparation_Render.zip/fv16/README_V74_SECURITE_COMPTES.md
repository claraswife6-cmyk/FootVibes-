# FootVibes v74 — Sécurité des comptes

Cette version renforce les tests de non-régression des opérations de suspension et de réactivation.

## Vérifications automatisées

- Une requête sans session administrateur est refusée.
- Un motif trop court est refusé.
- Sans identifiants serveur Appwrite, l’API ne prétend pas modifier le compte et répond avec une erreur explicite.
- Le contrôle d’identité commun refuse les utilisateurs présents dans le registre local avec le statut `suspended`.
- Les décisions de statut sont enregistrées dans le journal administratif après une réponse réussie d’Appwrite.

## Limites

Les tests sont locaux et n’utilisent aucun projet Appwrite réel. Avant le déploiement, configurer les variables Appwrite côté serveur et vérifier avec des comptes de test que les sessions déjà émises et tous les services intégrés réagissent comme attendu. Les tests ne prouvent pas la disponibilité ni la sécurité d’un déploiement public.
