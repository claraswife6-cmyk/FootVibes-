# FootVibes v29 — Actualisation des scores

## Ajout
- La liste des rencontres se recharge automatiquement toutes les 30 secondes lorsque l'écran de football est ouvert.
- L'actualisation est suspendue quand l'onglet/app Web est masqué, puis reprise au retour.
- Le bouton d'actualisation manuelle reste disponible.
- Les scores sont toujours fournis par l'API-Football configurée côté serveur : aucun score fictif n'est généré.

## Configuration nécessaire
Configurer `FOOTBALL_API_KEY` dans les variables privées du serveur. Vérifier les quotas et conditions de l'abonnement API-Football. L'actualisation de 30 secondes peut consommer le quota rapidement si de nombreux utilisateurs ouvrent la page; pour une production à grande échelle, utiliser un cache partagé côté serveur et adapter la fréquence au forfait API.

## Limites
Cette version actualise les scores/états des rencontres via l'endpoint existant. Elle n'ajoute pas de vidéo en direct ni de droits de retransmission. Le catalogue vidéo légal reste séparé.
