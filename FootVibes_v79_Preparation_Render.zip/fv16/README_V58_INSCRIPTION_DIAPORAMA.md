# FootVibes v58 — Inscription et diaporama

- Utilise les trois photos fournies dans l’écran de bienvenue.
- Ajoute une bannière photo animée au formulaire de création de compte, avec transition et indication du joueur.
- Rotation automatique toutes les 4,2 secondes.
- Aucun fichier vidéo n’a été inventé : le diaporama utilise les trois images disponibles.
- Les fonctions Appwrite et les intégrations externes restent soumises à leur configuration réelle.
