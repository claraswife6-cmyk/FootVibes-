# FootVibes v18 — Page Favoris

Cette version ajoute une page Favoris dans la navigation, avec chargement authentifié depuis `GET /api/social/favorites` et suppression via `DELETE /api/social/favorites`.

## Configuration requise
- Définir `APPWRITE_DATABASE_ID` et `APPWRITE_FAVORITES_COLLECTION_ID` côté serveur.
- Créer la collection Appwrite avec les attributs `userId` (string), `itemId` (string), `itemType` (string), `itemName` (string) et `itemUrl` (string). Prévoir les index sur `userId` et `itemId`.
- Se connecter à un compte Appwrite pour utiliser les favoris. Ne jamais placer la clé API serveur dans le navigateur.

## Limites
Les tests locaux sont des tests fumée, pas un test d'intégration contre un projet Appwrite réel. La page affiche les éléments enregistrés, mais ne reconstitue pas encore le contenu complet de la publication à partir de son ID.
