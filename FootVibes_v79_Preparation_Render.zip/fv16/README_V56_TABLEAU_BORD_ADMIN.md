# FootVibes v56 — Synthèse administrative

Cette version ajoute `GET /api/admin/overview`, protégé par la session administrateur (`fv_admin`).

La réponse donne :
- le nombre de demandes de certification en attente, approuvées et refusées ;
- le nombre d’identifiants certifiés connus du serveur ;
- le nombre de comptes Partenaire présents dans `FOOTVIBES_PARTNER_USER_IDS`.

## Configuration

`FOOTVIBES_PARTNER_USER_IDS` est une liste d’identifiants Appwrite séparés par des virgules, définie uniquement dans l’environnement privé du serveur. Ne jamais la placer dans le code client. La certification est enregistrée dans les données serveur et doit être approuvée par un administrateur authentifié.

## Limites

Cet endpoint fournit une synthèse JSON ; il n’ajoute pas de tableau visuel complet à l’interface d’administration. Le nombre de partenaires provient de la liste serveur, pas d’une confirmation automatique YelenPay. Les tests de fumée vérifient la présence et la structure du code, pas un déploiement externe.
