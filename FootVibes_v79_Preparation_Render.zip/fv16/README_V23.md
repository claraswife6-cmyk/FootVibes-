# FootVibes v23 — Profil connecté à Appwrite

## Ajout
- Formulaire de profil connecté à Appwrite Account.
- Le nom complet est enregistré avec `account.updateName`.
- Le nom d’utilisateur et la bio sont enregistrés dans les préférences du compte avec `account.updatePrefs`.
- Le profil charge les informations du compte connecté et affiche un message explicite si Appwrite n’est pas configuré ou si l’utilisateur n’est pas connecté.
- Validation du nom d’utilisateur et limites de longueur côté interface.

## Configuration requise
Configure `PUBLIC_APPWRITE_ENDPOINT` et `PUBLIC_APPWRITE_PROJECT_ID`, crée un projet Appwrite et configure les plateformes Web autorisées. Aucun secret Appwrite n’est envoyé au navigateur.

## Limites restantes
La galerie et les compteurs de profil restent à connecter aux données sociales; l’avatar personnalisable n’est pas encore implémenté. Les intégrations externes doivent être testées dans un environnement réel avant de considérer l’application prête pour la production.
