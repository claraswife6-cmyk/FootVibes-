# FootVibes v42 — compteur de messages non lus

## Nouveauté

Nouvel endpoint authentifié `GET /api/social/messages/unread-count`. Il compte les messages Appwrite dont `recipientId` correspond à l’utilisateur authentifié et `read` vaut `false`. La réponse comprend `unreadCount` et `possiblyTruncated`.

## Configuration requise

- `APPWRITE_MESSAGES_COLLECTION_ID`
- `APPWRITE_DATABASE_ID`
- Authentification Appwrite valide sur la requête.
- Attributs `recipientId` et `read` dans la collection Messages et un index Appwrite adapté aux requêtes.

## Limites

Le comptage est plafonné à 100 documents pour limiter le coût de la requête. Si `possiblyTruncated` vaut `true`, il faut utiliser une pagination Appwrite pour un total exact. Cette version ajoute l’API ; elle ne promet pas qu’un badge de non-lus soit déjà affiché partout dans l’interface. Aucun service Appwrite externe n’a été testé avec des identifiants réels.
