# FootVibes v30 — Détails des rencontres

## Ajout
- Quand un utilisateur sélectionne une rencontre, l'interface demande en parallèle les événements, statistiques et compositions à l'API-Football via le serveur FootVibes.
- Les événements affichent minute, équipe, joueur, type, détail et passe décisive si fournis par l'API.
- Les statistiques sont regroupées par équipe; les compositions indiquent formation, entraîneur et onze de départ lorsque disponibles.
- Les réponses vides sont présentées comme indisponibles, sans inventer de données.

## Configuration
- Ajouter `FOOTBALL_API_KEY` dans les variables privées du serveur.
- Les endpoints `/api/football/events`, `/api/football/statistics` et `/api/football/lineups` attendent un paramètre `fixture` numérique.
- La disponibilité des statistiques et compositions varie selon la compétition, la rencontre et le forfait API-Football.

## Limites
Les contrôles locaux valident la syntaxe et les tests du projet, mais aucun appel API réel n'a été effectué ici. Il faut tester avec une clé valide et un identifiant de rencontre réel. Les quotas du fournisseur s'appliquent.
