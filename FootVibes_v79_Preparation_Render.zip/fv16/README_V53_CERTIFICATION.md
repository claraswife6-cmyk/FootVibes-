# FootVibes v53 — demandes de certification

## Ajout
- Un utilisateur connecté peut soumettre une demande de certification via `POST /api/certification/request` avec un JWT Appwrite et `{ "reason": "..." }` (20 à 1000 caractères).
- `GET /api/certification/status` retourne l'état de vérification et le statut de la demande pour l'utilisateur connecté.
- Les administrateurs connectés peuvent consulter les demandes via `GET /api/admin/certification-requests` et examiner une demande avec `POST /api/admin/certification-requests/:id`, corps `{ "status": "approved" | "rejected" | "pending", "note": "..." }`.
- L'approbation ajoute l'identifiant à `data/verified-users.json` côté serveur. La liste optionnelle `FOOTVIBES_VERIFIED_USER_IDS` reste disponible pour les comptes prévalidés.
- Les fichiers JSON de demandes et de comptes vérifiés sont écrits avec permissions de fichier restreintes (0600). Ils doivent être sauvegardés et conservés sur un disque persistant en production.

## Limites importantes
- Cette livraison fournit les routes serveur; elle n'ajoute pas encore un formulaire visible dans l'interface ni l'affichage dynamique du badge bleu sur tous les profils.
- L'examen administratif est une étape manuelle. Aucun contrôle automatique d'identité ni intégration à un prestataire de vérification n'est fourni.
- Configurer `ADMIN_EMAIL`, `ADMIN_PASSWORD`, Appwrite, puis tester avec des comptes de test avant toute mise en production.
