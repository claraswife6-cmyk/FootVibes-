import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import process from 'node:process';

const port = Number(process.env.FOOTVIBES_SMOKE_PORT || (20000 + Math.floor(Math.random() * 20000)));
const child = spawn(process.execPath, ['server/server.js'], {
  env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', APP_ENV: 'test' },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let logs = '';
child.stdout.on('data', (chunk) => { logs += chunk.toString(); });
child.stderr.on('data', (chunk) => { logs += chunk.toString(); });
let response;
try {
  for (let attempt = 0; attempt < 40; attempt++) {
    if (child.exitCode !== null) throw new Error(`Serveur arrêté prématurément (code ${child.exitCode}).`);
    try {
      response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(1000) });
      break;
    } catch { await delay(250); }
  }
  if (!response) throw new Error('Le serveur n’a pas répondu dans le délai prévu.');
  if (!response.ok) throw new Error(`Healthcheck HTTP ${response.status}.`);
  const body = await response.json();
  if (body.status !== 'ok' || body.app !== 'FootVibes') throw new Error('Réponse healthcheck inattendue.');
  const configResponse = await fetch(`http://127.0.0.1:${port}/api/config`, { signal: AbortSignal.timeout(2000) });
  if (!configResponse.ok) throw new Error(`/api/config répond HTTP ${configResponse.status}.`);
  const config = await configResponse.json();
  for (const secret of ['APPWRITE_API_KEY', 'ONESIGNAL_REST_API_KEY', 'LIVEKIT_API_SECRET', 'PAYMENT_WEBHOOK_SECRET']) {
    if (JSON.stringify(config).includes(process.env[secret] || `__NEVER_MATCH_${secret}__`)) throw new Error('Une valeur secrète semble exposée dans la configuration publique.');
  }
  console.log('OK — serveur lancé et /api/health répond HTTP', response.status);
  console.log('OK — /api/config répond et les clés privées ne sont pas exposées');
  console.log('Note : ce test ne valide pas les identifiants des fournisseurs externes.');
} catch (error) {
  console.error('ÉCHEC —', error.message);
  if (logs.trim()) console.error(logs.trim().slice(-2000));
  process.exitCode = 1;
} finally {
  child.kill('SIGTERM');
  await Promise.race([new Promise((resolve) => child.once('exit', resolve)), delay(2000)]);
  if (child.exitCode === null) child.kill('SIGKILL');
}
