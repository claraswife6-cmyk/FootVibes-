const groups = [
  { name: 'Serveur', vars: ['APP_ENV', 'PUBLIC_APP_URL'] },
  { name: 'Appwrite', vars: ['PUBLIC_APPWRITE_ENDPOINT', 'PUBLIC_APPWRITE_PROJECT_ID', 'APPWRITE_API_KEY', 'APPWRITE_DATABASE_ID', 'APPWRITE_USERS_COLLECTION_ID', 'APPWRITE_POSTS_COLLECTION_ID', 'APPWRITE_MESSAGES_COLLECTION_ID'] },
  { name: 'Football et alertes', vars: ['FOOTBALL_API_KEY', 'PUBLIC_ONESIGNAL_APP_ID', 'ONESIGNAL_REST_API_KEY', 'APPWRITE_GOAL_ALERTS_COLLECTION_ID', 'APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID'] },
  { name: 'Appels audio/vidéo', vars: ['PUBLIC_LIVEKIT_URL', 'LIVEKIT_API_KEY', 'LIVEKIT_API_SECRET'] },
  { name: 'Paiements', vars: ['YELENPAY_PREMIUM_URL', 'YELENPAY_PARTNER_URL', 'PAYMENT_WEBHOOK_SECRET'] },
];
let missingTotal = 0;
console.log('FootVibes — contrôle préalable au déploiement\n');
for (const group of groups) {
  const missing = group.vars.filter((key) => !process.env[key]?.trim());
  const ready = missing.length === 0;
  console.log(`${ready ? '[OK]' : '[À CONFIGURER]'} ${group.name}`);
  if (missing.length) {
    missingTotal += missing.length;
    for (const key of missing) console.log(`  - ${key}`);
  }
}
console.log('\nSécurité : aucune valeur secrète n’est affichée.');
if (missingTotal) {
  console.log(`\n${missingTotal} variable(s) manquante(s). Le résultat ne teste pas la validité des clés, les droits de diffusion ou les webhooks.`);
  process.exitCode = 1;
} else {
  console.log('\nToutes les variables listées sont présentes. Effectuez encore les tests d’intégration réels avant publication.');
}
