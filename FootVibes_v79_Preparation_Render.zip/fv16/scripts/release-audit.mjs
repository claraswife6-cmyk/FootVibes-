import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = process.cwd();
const checks = [
  ['Dockerfile présent', 'Dockerfile'],
  ['Workflow CI présent', '.github/workflows/ci.yml'],
  ['Exemple de variables présent', '.env.example'],
  ['Guide de déploiement présent', 'DEPLOYMENT.md'],
  ['Préflight présent', 'scripts/preflight.mjs'],
  ['Smoke test de déploiement présent', 'scripts/deploy-smoke.mjs'],
  ['Tests du projet présents', 'tests/smoke-test.mjs'],
];
let failures = 0;
console.log('FootVibes — audit de préparation à la publication\n');
for (const [label, file] of checks) {
  const ok = existsSync(resolve(root, file));
  console.log(`${ok ? '[OK]' : '[MANQUANT]'} ${label}`);
  if (!ok) failures++;
}
const dockerfile = readFileSync(resolve(root, 'Dockerfile'), 'utf8');
for (const [label, ok] of [
  ['Image Node 20+ utilisée', /node:(20|22|23|24)-/.test(dockerfile)],
  ['Conteneur exécuté sans root', /USER node/.test(dockerfile)],
  ['Healthcheck configuré', /HEALTHCHECK/.test(dockerfile)],
]) {
  console.log(`${ok ? '[OK]' : '[À CORRIGER]'} ${label}`);
  if (!ok) failures++;
}
console.log('\nCet audit vérifie les fichiers et réglages locaux uniquement. Il ne teste pas les identifiants, services externes, droits vidéo, paiements, ni le déploiement distant.');
if (failures) process.exitCode = 1;
else console.log('\nAudit structurel réussi. Effectuer le preflight et les tests d’intégration réels avant ouverture au public.');
