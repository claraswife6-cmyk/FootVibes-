# FootVibes v16 — médias Appwrite Storage

Cette version ajoute l'envoi des images et vidéos aux publications via le serveur et Appwrite Storage.

## Configuration requise
- `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID`, `APPWRITE_API_KEY`
- `APPWRITE_MEDIA_BUCKET_ID` : identifiant d'un bucket Storage Appwrite
- `APPWRITE_DATABASE_ID` et `APPWRITE_POSTS_COLLECTION_ID`
- Dans Appwrite, configure le bucket pour accepter les formats image/jpeg, image/png, image/webp, image/gif, video/mp4 et video/quicktime. Limite conseillée : 10 Mo.

L'envoi passe par `/api/social/media`, vérifie une session Appwrite JWT et utilise la clé API uniquement côté serveur. Le client n'envoie ensuite que l'URL du média avec le texte de la publication. Le lien de lecture est une URL Appwrite Storage; vérifie les permissions de lecture du bucket pour que les médias des publications soient accessibles comme prévu.

## Limites connues
- Maximum actuel : 10 Mo par fichier; pas de transcodage vidéo ni miniatures.
- La lecture de média dépend des permissions du bucket Appwrite.
- Ces tests locaux ne remplacent pas un essai avec ton projet Appwrite réel.
