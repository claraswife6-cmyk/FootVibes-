# FootVibes v10 — préparation et déploiement

## Structure
Le contenu du projet est à la racine de cette archive. Dans le dépôt GitHub privé, `package.json` doit rester à la racine.

## Déploiement Render
- Type: Web Service / Node.js
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/api/health`
- Runtime: Node.js 20 ou supérieur
- Blueprint: `render.yaml`

## Vérifications avant déploiement
1. Exécuter `npm run check`.
2. Exécuter `npm test`.
3. Confirmer que `/api/health` répond sur le service Render.
4. Vérifier les journaux Render après chaque déploiement.
5. Tester les intégrations externes séparément avec des comptes/identifiants valides.

Les tests fumée vérifient les contrôles de base et ne prouvent pas que chaque intégration externe fonctionne en production.

## Secrets et services
Ne jamais téléverser `.env` ni publier des clés privées. Ajouter les variables requises depuis `.env.example` dans Render > Environment. Ne pas placer les secrets dans le navigateur ni dans les commits Git. Limiter les permissions des clés aux besoins de l'application et les renouveler si elles sont exposées.

## Liste de contrôle avant publication
- [ ] Dépôt GitHub privé; aucun `.env`, jeton ou secret dans l'historique Git.
- [ ] `npm run check` et `npm test` réussis.
- [ ] `PUBLIC_APP_URL` correspond à l'URL HTTPS réelle du service.
- [ ] Domaine autorisé dans Appwrite; permissions et règles de données vérifiées.
- [ ] API-Football testée avec la clé du propriétaire et les limites de quota respectées.
- [ ] Paiements YelenPay validés côté serveur avec la méthode officielle de vérification; aucun abonnement activé sur simple retour navigateur.
- [ ] LiveKit: génération de jetons signés côté serveur; clés secrètes jamais envoyées au client.
- [ ] OneSignal: configuration mobile/web vérifiée pour les plateformes ciblées.
- [ ] Politique de confidentialité, conditions, support et suppression de compte vérifiés.
- [ ] Tests sur iOS, Android et navigateurs réels.

## État fonctionnel
Ce paquet est une base web préparée au déploiement, pas une version entièrement finalisée de toutes les fonctions promises. Les paiements vérifiés, appels, notifications, messagerie temps réel, médias persistants et outils d'administration avancés exigent encore du développement et des tests. Ne pas vendre d'abonnements tant que le flux de paiement n'est pas vérifié côté serveur. Le déploiement web ne publie pas automatiquement une application dans l'App Store ou Google Play.
