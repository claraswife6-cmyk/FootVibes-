# FootVibes v62 — contrôles de sécurité des appels

Cette version ajoute des assertions de non-régression autour de la route de jeton LiveKit :

- aucune émission si les services/clefs nécessaires ne sont pas configurés ;
- session Appwrite obligatoire et vérifiée côté serveur ;
- refus des comptes sans accès Partenaire ;
- validation du nom de salon ;
- secret de signature conservé côté serveur.

## Vérifier

Avec Node.js 20 ou plus récent :

```bash
npm run check
npm test
```

Ces tests vérifient la présence des garde-fous dans le code et les tests fumée ; ils ne remplacent pas un test d'intégration avec un projet Appwrite et un serveur LiveKit réels. Avant la production, il faut aussi vérifier que l'autorisation de rejoindre un salon correspond à une invitation d'appel valide et que le salon ne peut pas être choisi arbitrairement par un client.
