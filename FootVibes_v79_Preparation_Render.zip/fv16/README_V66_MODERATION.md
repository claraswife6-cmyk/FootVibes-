# FootVibes v66 — Signalements et modération

## Fonctionnalités
- `POST /api/reports` : reçoit un signalement depuis une session Appwrite valide. Champs : `targetId`, `reason` (`spam`, `harassment`, `violence`, `copyright`, `scam`, `other`), `details` facultatif.
- Limite les signalements identiques ouverts du même utilisateur vers la même cible.
- `GET /api/admin/reports` : liste les signalements, session administrateur requise.
- `POST /api/admin/reports/:id` : met le statut à `open`, `reviewing`, `resolved` ou `dismissed`; la décision est ajoutée au journal administratif.
- L’interface d’administration permet de consulter et traiter les signalements.

## Sécurité et limites
- Les textes sont échappés dans l’interface avant affichage.
- Le signalement ne masque ni ne supprime automatiquement le contenu ou le compte : une intégration Appwrite dédiée et une procédure de recours doivent être définies avant une modération de production.
- Les signalements sont conservés localement dans `data/content-reports.json`; prévoir sauvegardes, permissions serveur et stockage durable en production.

## Vérifications exécutées
- `node --check server/server.js`
- `node --check app.js`
- `npm test`
