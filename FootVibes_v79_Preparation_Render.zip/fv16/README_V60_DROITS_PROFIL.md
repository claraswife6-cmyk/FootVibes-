# FootVibes v60 — Droits du compte dans le profil

## Changements
- Le profil affiche désormais le rôle renvoyé par le serveur (Classic ou Partenaire).
- Les capacités de consultation, interaction, publication, messagerie, appels audio/vidéo et diffusion professionnelle sont affichées à partir de `/api/account/entitlements`.
- La requête est authentifiée avec un JWT Appwrite créé par le compte connecté.
- En cas d’erreur ou de session absente, l’interface affiche un message et ne déduit pas les droits localement.

## Vérifications
- `node --check app.js`
- `node --check server/server.js`
- `npm test`

Ces tests sont des contrôles structurels. Les droits réels doivent encore être vérifiés avec Appwrite et les variables serveur configurées.
