# FootVibes v54 — Interface de certification

- Ajout dans le profil d’un formulaire de demande de certification.
- Le statut de certification est chargé depuis le serveur avec un JWT Appwrite.
- Le badge bleu apparaît uniquement lorsque le serveur indique `verified: true`.
- Une demande en attente masque le formulaire pour éviter les demandes répétées depuis l’interface.
- L’administration reste responsable de la revue manuelle.

## Limites
Le test automatisé vérifie la présence des branchements et la structure, pas une vraie session Appwrite ni l’expérience sur iOS/Android. Les données de demande actuelles sont conservées par le mécanisme serveur existant; configure une persistance adaptée à l’hébergement avant un lancement à grande échelle.
