# FootVibes v55 — Administration des demandes de certification

Cette version ajoute à l'espace d'administration une liste des demandes de certification, avec le nom affiché, l'identifiant du compte, la date, le motif et le statut. Un administrateur connecté peut approuver, refuser ou remettre une demande en attente et ajouter une note administrative.

## Règles
- Le badge bleu correspond à une certification administrative, distincte du statut Partenaire.
- Approuver une demande active le statut certifié côté serveur selon le mécanisme actuel.
- Vérifier l'identité du demandeur hors application avant d'approuver.
- L'accès aux endpoints admin dépend de la session administrateur côté serveur.

## Validation locale
Lancer `npm run check`, `npm test` et `npm run release:audit`. Ces contrôles vérifient le code et des invariants structurels; ils ne remplacent pas un test de bout en bout avec Appwrite et une session administrateur réelle.
