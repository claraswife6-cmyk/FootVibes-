# FootVibes v25 — Visionnage légal des matchs

## Ajout
- Rubrique « Regarder un match » dans Football.
- Liens directs vers les plateformes officielles FIFA+ et DAZN.
- Explication explicite de la différence entre scores en direct et vidéo du match.
- Politique gratuite + Premium prévue, sans inventer de flux vidéo ni débloquer un match sans droits confirmés.

## Important
Cette version ne contient pas de flux vidéo intégré. Les liens ouvrent les plateformes officielles dans un nouvel onglet. Le catalogue FIFA+ et les restrictions territoriales changent selon les compétitions et les droits. L’utilisateur doit vérifier la disponibilité au Burkina Faso.

## Pour intégrer des matchs Premium dans FootVibes
Il faut un contrat ou une licence de diffusion qui autorise explicitement :
- la diffusion au Burkina Faso et dans les territoires ciblés ;
- la retransmission dans une application tierce, et non seulement sur le site du diffuseur ;
- la monétisation par abonnement ou publicité ;
- le lecteur/SDK, les DRM éventuels, les limites d’appareils et les règles d’usage des extraits ;
- la disponibilité mobile iOS/Android et les conditions de géoblocage.

Aucun contrat fournisseur n’est configuré dans cette version et aucun match ne doit être présenté comme visionnable directement dans FootVibes tant que les droits ne sont pas vérifiés.
