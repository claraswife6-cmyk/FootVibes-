# FootVibes v48 — Notifications d’appels entrants

Cette version ajoute une demande explicite d’autorisation de notifications navigateur et affiche une notification lorsque la page FootVibes ouverte détecte une nouvelle invitation d’appel.

## Limites importantes
- Fonctionne uniquement si le navigateur prend en charge `Notification` et si l’utilisateur autorise les notifications.
- La détection repose sur l’actualisation de la messagerie toutes les 5 secondes.
- Ce n’est pas une notification push native fiable lorsque l’application est fermée ou suspendue sur iOS. Pour cela, il faut terminer l’intégration OneSignal avec configuration, service worker, HTTPS et tests sur appareils réels.
- Les tests locaux ne valident pas les services externes Appwrite, LiveKit ou OneSignal.

## Vérification locale
```sh
npm run check
npm test
npm run release:audit
```
