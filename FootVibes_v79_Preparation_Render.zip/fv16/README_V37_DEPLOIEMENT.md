# FootVibes v37 — validation du déploiement

Cette version ajoute un test de démarrage HTTP pour vérifier que le serveur se lance, que `/api/health` répond et que `/api/config` n'expose pas les clés privées principales.

## Commandes

```bash
npm install
npm run check
npm test
npm run preflight
npm run smoke:deploy
```

`npm run preflight` peut échouer tant que les variables réelles ne sont pas configurées : c'est attendu et ne doit pas être contourné en mettant de fausses clés.

## Docker

Le conteneur écoute sur le port 8080. Pour une validation locale, créer `.env` à partir de `.env.example`, remplir uniquement les variables disponibles, puis lancer `docker compose up --build`. Ne commitez jamais `.env`.

## Limites

Le smoke test valide uniquement le démarrage et deux routes HTTP. Il ne prouve pas que Appwrite, API-Football, OneSignal, LiveKit, YelenPay, les droits de diffusion vidéo ou les notifications fonctionnent. Il faut effectuer des tests d'intégration avec des comptes et appareils réels avant la publication.
