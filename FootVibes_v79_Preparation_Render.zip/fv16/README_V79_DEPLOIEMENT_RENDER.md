# FootVibes v79 — Préparer le déploiement sur Render

Ce ZIP prépare les fichiers du projet pour Render. Il ne crée pas de compte, ne publie pas le code et ne configure pas les secrets à ta place.

## Méthode recommandée
1. Décompresser ce ZIP sur un ordinateur.
2. Créer un dépôt Git privé et y envoyer le contenu du dossier `fv16` (ne jamais ajouter `.env`).
3. Ouvrir https://render.com/ et créer un compte.
4. Dans Render, choisir **New + → Blueprint** et connecter le dépôt privé. Render lira `render.yaml` et proposera le service `footvibes`.
5. Confirmer la création du service. Attendre le build puis ouvrir l'URL `onrender.com` fournie par Render.
6. Vérifier `https://TON-SERVICE.onrender.com/api/health`. Une réponse JSON contenant `"status":"ok"` confirme seulement que le serveur répond.
7. Dans le service Render → **Environment**, ajouter les variables privées nécessaires. Ne pas mettre de secrets dans `render.yaml`, Git ou un ZIP.
8. Enregistrer et redéployer. Consulter les logs sans copier ni publier de valeurs secrètes.

## Variables à renseigner dans Render
- Obligatoires pour le serveur de base : `APP_ENV=production`, `HOST=0.0.0.0` (le port est fourni par Render via `PORT`).
- Appwrite : `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID`, puis les identifiants de base/collections réels. `APPWRITE_API_KEY` reste côté serveur.
- `PUBLIC_APP_URL` : remplacer par l'URL Render fournie après le premier déploiement.
- Ajouter les variables LiveKit, API-Football, OneSignal, paiement et administration uniquement si le module correspondant est utilisé et configuré.

## Sécurité
- Ne jamais envoyer de clés privées, mots de passe, jetons ou secrets dans cette conversation.
- `.env` est ignoré par Git. Garder le dépôt privé pendant la configuration.
- Créer une clé Appwrite serveur avec le minimum de permissions nécessaires.
- Ne pas activer les paiements ni les rôles Premium automatiquement sans validation serveur du prestataire.

## Limites importantes
- Aucun déploiement Render n'a été déclenché depuis ce ZIP.
- Le service gratuit peut s'endormir après une période d'inactivité et présenter un délai au premier accès; vérifier les conditions et limites actuelles de Render.
- Le serveur doit être testé avec les variables réelles dans Render. La route `/api/health` ne prouve pas que Appwrite, les appels, les notifications ou les paiements fonctionnent.
- La persistance locale sur un hébergeur web ne doit pas servir au stockage durable des médias ou données; utiliser Appwrite Storage/Database ou un stockage adapté.
