# Espace administrateur FootVibes — état et exigences

Le fichier `.env.example` prévoit `ADMIN_EMAIL`, `ADMIN_PASSWORD_HASH` et `ADMIN_SESSION_SECRET`, mais ces variables seules ne créent pas un système de connexion. Ne pas les renseigner en production tant que le flux d'authentification n'a pas été implémenté et testé.

## Fonctions attendues du tableau de bord
- Vue d'ensemble : utilisateurs, publications, signalements, revenus/paiements confirmés et état des services.
- Utilisateurs : recherche, profil, statut, suspension/réactivation, demandes de suppression et historique d'action.
- Modération : examiner signalements, masquer/supprimer contenu, traiter les recours et enregistrer la raison.
- Paiements : consulter les événements du prestataire et valider Premium/Partenaire uniquement après preuve serveur vérifiée; journaliser chaque action.
- Certification : demandes, pièces nécessaires, statut et motif de décision; protéger les documents sensibles.
- Contenu : gérer catégories de wallpapers, contenus mis en avant et classement tendance.
- Notifications : composer et envoyer des annonces via OneSignal après configuration réelle.
- Paramètres : liens officiels, conditions, contacts, intégrations et journaux d'audit.

## Sécurité obligatoire avant activation
1. Utiliser Appwrite Auth et une équipe/rôle admin côté serveur, ou un mécanisme serveur équivalent vérifié; ne jamais se fier à un bouton caché dans le navigateur.
2. Stocker un hash de mot de passe (Argon2id ou scrypt), jamais un mot de passe en clair. Activer HTTPS, cookies de session `HttpOnly`, `Secure`, `SameSite`, expiration et rotation.
3. Ajouter limitation de tentatives, protection CSRF, validation des entrées, journal d'audit et MFA si disponible.
4. Chaque endpoint d'administration doit vérifier l'autorisation côté serveur. Ne jamais renvoyer les clés secrètes à `/api/config`.
5. Les statistiques réelles ne peuvent apparaître qu'après connexion à la base Appwrite et après définition des collections/permissions.

**Important :** le projet actuel est un kit de démarrage et une démonstration. Ce document décrit le périmètre requis, pas une déclaration que le panneau d'administration sécurisé est déjà opérationnel.
