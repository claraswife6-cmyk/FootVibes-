# Registre de configuration FootVibes

Remplir les valeurs uniquement dans l’espace de configuration approprié. Ne pas partager de clés secrètes dans une conversation, un dépôt public ou un fichier frontend.

| Service | Valeur publique possible côté client | Secret côté serveur | Statut |
|---|---|---|---|
| URL publique | Domaine de l’application | — | À configurer |
| API backend | URL publique de l’API | Jeton d’administration | À connecter |
| Appwrite | Endpoint et ID de projet | Clé API Appwrite | À connecter |
| API football | URL du proxy backend | Clé API football | À connecter |
| OneSignal | App ID public | REST API key | À connecter |
| LiveKit | URL du serveur | API secret et génération de jetons | À connecter |
| Paiements | URL de redirection/API publique | Clé privée et vérification webhook | À connecter |
| Réseaux sociaux | Liens de profils/canaux | Aucun mot de passe utilisateur | À renseigner |

Le prototype actuel fonctionne sans ces valeurs, en mode démonstration. Laisser les champs vides jusqu’à la mise en place des services.
