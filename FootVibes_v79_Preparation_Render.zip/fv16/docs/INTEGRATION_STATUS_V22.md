# FootVibes v22 — OneSignal Web Push

## Ajouté
- Chargement du SDK Web OneSignal v16 à partir de la configuration publique `/api/config`.
- Écran Notifications avec bouton de demande d’autorisation et messages d’état.
- Association de l’identifiant Appwrite du compte à OneSignal après connexion/création de compte, si le SDK est configuré.
- Déconnexion de l’alias OneSignal à la déconnexion du compte.
- Service worker `OneSignalSDKWorker.js` prévu pour être déployé à la racine du domaine.
- La clé REST OneSignal reste exclusivement dans `ONESIGNAL_REST_API_KEY` côté serveur.

## Configuration et limites
1. Définir `PUBLIC_ONESIGNAL_APP_ID` et `ONESIGNAL_REST_API_KEY` dans les variables privées de l’hébergeur.
2. Déployer `OneSignalSDKWorker.js` à la racine du même domaine que l’application et vérifier qu’il répond sans redirection.
3. Servir l’application en HTTPS et configurer les plateformes de push dans OneSignal. Pour une application iOS/Android native, configurer aussi APNs/FCM et intégrer le SDK natif approprié.
4. Tester sur appareils réels et vérifier les abonnements dans le tableau OneSignal.

Cette version prépare l’abonnement Web Push; elle ne constitue pas une intégration native iOS/Android et ne fournit pas encore de notifications entrantes d’appel, de messages ou d’interactions sociales automatiquement déclenchées. L’envoi serveur existant est limité au compte connecté lui-même. Les navigateurs et les permissions peuvent empêcher l’abonnement.
