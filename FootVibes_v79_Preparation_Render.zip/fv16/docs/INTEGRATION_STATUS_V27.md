# État d'intégration v27

Ajout : le catalogue affiche un lecteur intégré uniquement quand l'API serveur fournit un `embedUrl` validé pour une entrée gratuite dont les droits ont été confirmés. Les entrées sans lecteur intégré gardent un lien vers le diffuseur officiel.

À faire avant production : ajouter uniquement des sources réellement autorisées, vérifier leur disponibilité au Burkina Faso, documenter la preuve de droits, configurer la clé API-Football, puis tester sur navigateur mobile et ordinateur. Le flux Premium reste indisponible jusqu'à contrat fournisseur, contrôle d'abonnement serveur et tests de sécurité.
