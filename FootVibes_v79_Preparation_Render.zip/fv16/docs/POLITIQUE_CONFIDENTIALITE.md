# FootVibes — modèle de politique de confidentialité

**Statut : modèle incomplet. Ne pas publier sans adaptation aux traitements réels et vérification juridique.**

## Responsable du traitement
Nom légal : [À COMPLÉTER] · Adresse : [À COMPLÉTER] · Contact : [À COMPLÉTER].

## Données à documenter
Décrire précisément les données réellement collectées : informations de compte, contenus publiés, messages, médias, journaux techniques, données de diagnostic, préférences, données de paiement transmises par le prestataire et données de notification. Ne conserver aucune catégorie qui n’est pas nécessaire.

## Finalités et bases légales
Pour chaque catégorie, préciser la finalité, la base légale, le caractère obligatoire/facultatif et les conséquences d’un refus. Distinguer notamment création de compte, affichage des contenus, sécurité, assistance, notifications et facturation.

## Destinataires et transferts
Lister les hébergeurs, services de stockage, fournisseurs d’API football, notification, messagerie/appel, paiement et outils de mesure réellement utilisés. Décrire les transferts internationaux et les garanties applicables, le cas échéant.

## Conservation
Indiquer une durée ou un critère concret pour chaque catégorie de données. Décrire la suppression de compte, les sauvegardes, les obligations de conservation et les exceptions.

## Droits des personnes
Décrire comment demander l’accès, la rectification, l’effacement, l’opposition, la limitation, la portabilité lorsque applicable, ou déposer une plainte auprès de l’autorité compétente. Ajouter une adresse de contact réellement surveillée.

## Sécurité et mineurs
Décrire les mesures techniques et organisationnelles réelles. Définir les règles d’âge et les protections des mineurs avant d’autoriser les inscriptions.

## Cookies et stockage local
Lister les cookies/stockages réellement utilisés, leurs finalités et les moyens de gérer les préférences. Le prototype actuel n’intègre pas de plateforme de consentement publicitaire.

Date d’entrée en vigueur : [À COMPLÉTER]. Version : [À COMPLÉTER].

Powered by Trehza Mendoza
