# Statut d'intégration FootVibes v14

| Fonction | État |
|---|---|
| Création de compte / connexion | SDK Appwrite côté client, dépend du projet et des plateformes configurés |
| Flux social | UI chargée depuis la route Appwrite |
| Publication texte | Route serveur Appwrite existante |
| Like | Route serveur compteur, pas encore un like unique par utilisateur |
| Commentaires | UI et route serveur raccordées |
| Messagerie texte | UI pour choisir un ID destinataire, charger et envoyer via serveur |
| Scores football | Proxy API-Football, clé serveur requise |
| LiveKit | Route de jeton serveur existante, interface d'appel à finir |
| OneSignal | Route d'envoi serveur, liaison appareil/alias à finir |
| Média / reels / wallpapers | Upload Storage et liaison aux publications à finir |
| Paiements | Liens de paiement configurables; webhook vérifié et droits Premium à finir |
| Application native iOS / Android | Non livrée dans ce paquet web |

Aucune clé ou valeur de test ne doit être utilisée pour faire croire qu'une intégration est active.
