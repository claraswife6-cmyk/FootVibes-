# Appwrite schema for FootVibes v13

All private values belong in Render/Replit/your server's environment settings, never in GitHub or the client bundle. Create a Database and enable document-level security. The server API key must have only the required database document scopes.

## Required collection IDs
- `APPWRITE_POSTS_COLLECTION_ID`: `userId` string, `name` string, `text` string, `mediaUrl` string, `kind` string, `likes` integer, `comments` integer.
- `APPWRITE_COMMENTS_COLLECTION_ID`: `postId` string, `userId` string, `name` string, `text` string.
- `APPWRITE_MESSAGES_COLLECTION_ID`: `senderId` string, `recipientId` string, `text` string, `mediaUrl` string, `read` boolean. Configure document permissions so only sender and recipient can read each message.
- `APPWRITE_FOLLOWS_COLLECTION_ID`: `followerId` string, `followedId` string. Add a unique index across followerId + followedId where supported.

Use IDs that fit Appwrite's attribute length and index constraints. Ensure the API key has document list/read/create/update/delete scopes for the collections used. The server uses Appwrite REST API; the browser must send the current Appwrite user JWT in `Authorization: Bearer <JWT>` for protected routes.

## Implemented server routes
- `GET /api/social/posts?limit=20` and `POST /api/social/posts`.
- `POST /api/social/posts/like` (basic counter; not an idempotent per-user like system yet).
- `GET /api/social/comments?postId=...` and `POST /api/social/comments`.
- `GET /api/social/messages?with=<userId>` and `POST /api/social/messages` (persisted messages; client polling/realtime subscription still needs wiring).
- `POST /api/social/follow` (toggle follow relationship).
- `POST /api/notifications/send` for the signed-in user's own external_id in OneSignal; delivery requires the device to have registered that external_id with OneSignal.
- `GET /api/football/fixtures`, `/api/football/standings`, `/api/football/teams`, `/api/football/leagues`, `/api/football/players`, `/api/football/events`, `/api/football/statistics`, `/api/football/lineups`.
- `POST /api/livekit/token` validates the Appwrite session before issuing a room token.

## Not complete / don't fake as operational
The API routes alone do not automatically connect every visible UI control. Uploading media to Appwrite Storage, realtime chat UI, robust per-user likes/favorites, profile editing, moderation workflows, verified YelenPay webhooks, subscription entitlement activation, push-device registration, and native iOS/Android packaging require further implementation and end-to-end tests. The YelenPay webhook intentionally stays disabled until a verifiable provider signature contract is implemented. Never grant paid access based only on a browser redirect or an uploaded payment receipt.


## Favoris persistants (v15)
- `APPWRITE_FAVORITES_COLLECTION_ID`: créer une collection avec attributs obligatoires `userId` (string, 36), `itemId` (string, 100), `itemType` (string, 30), `itemName` (string, 160), `itemUrl` (string, 1500).
- Autoriser la création via clé API serveur; l’API filtre toujours sur `userId` provenant du JWT Appwrite. Les documents sont créés avec permissions de lecture/suppression réservées à leur propriétaire.
- Index recommandé: `userId` + `itemId` (unique si disponible).
- Route: `GET /api/social/favorites`, `POST /api/social/favorites` (ajoute/retire par bascule), `DELETE /api/social/favorites` (retire). Chaque appel utilisateur exige `Authorization: Bearer <JWT Appwrite>`.
