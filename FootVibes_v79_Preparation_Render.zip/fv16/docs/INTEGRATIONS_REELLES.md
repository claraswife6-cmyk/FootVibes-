# Intégrations réelles — registre et étapes obligatoires

Ce projet est indépendant de Lovable. Il fournit un serveur Node.js sans dépendances, un Dockerfile et une configuration par variables d'environnement. Les intégrations ne sont pas toutes activées tant que les comptes et contrats n'ont pas fourni les identifiants et URLs réels.

## API-Football
- Définir `FOOTBALL_API_KEY` dans `.env` sur le serveur uniquement.
- Tester `GET /api/football/status`, puis `GET /api/football/fixtures?live=all`.
- Le serveur appelle `https://v3.football.api-sports.io/fixtures` et garde la clé hors du navigateur.
- Vérifier les limites de quota et droits d'affichage du forfait souscrit avant publication.

## Appwrite
- Renseigner `PUBLIC_APPWRITE_ENDPOINT`, `PUBLIC_APPWRITE_PROJECT_ID`, `APPWRITE_DATABASE_ID`, les IDs de collections et bucket.
- Le endpoint et le project ID sont des identifiants publics. `APPWRITE_API_KEY` est une clé serveur sensible.
- Créer les collections, attributs, index et permissions dans Appwrite Console. N'autoriser les accès que selon l'utilisateur courant; ne pas donner un accès admin au client.
- L'authentification et les permissions de production doivent être implémentées/testées avant d'activer comptes et publications.

## OneSignal
- Renseigner `PUBLIC_ONESIGNAL_APP_ID` côté client.
- `ONESIGNAL_REST_API_KEY` reste côté serveur. Pour l'envoi push, configurer les credentials de plateforme exigés par OneSignal (APNs pour iOS, FCM pour Android) et les permissions système. Ne jamais copier une REST API key dans le JavaScript client.

## LiveKit
- Renseigner `PUBLIC_LIVEKIT_URL`.
- `LIVEKIT_API_KEY` et `LIVEKIT_API_SECRET` restent côté serveur. Les jetons de salle doivent être émis par un endpoint authentifié côté serveur; aucun jeton LiveKit ne doit être fabriqué dans le navigateur.
- Les appels ne sont pas activés par ce kit seul; intégrer le SDK LiveKit côté client et un endpoint de génération de jeton après authentification.

## YelenPay
- Définir `YELENPAY_PREMIUM_URL` et `YELENPAY_PARTNER_URL` avec les deux liens de paiement réels fournis dans le tableau de bord marchand.
- Premium est configuré comme 10 000 FCFA par mois; Partenaire comme 5 000 FCFA une seule fois, selon le cahier des charges provisoire.
- Les URL réelles ne figuraient pas dans les fichiers fournis à la construction de ce kit, elles ne sont donc pas inventées ici.
- Avant l'activation automatique, obtenir la documentation officielle du prestataire pour les webhooks, la signature, les identifiants de transaction, les remboursements et les états de paiement. Le webhook du kit renvoie volontairement 501 jusqu'à cette configuration. L'activation doit se faire seulement après vérification serveur du paiement.
- Avant publication sur iOS/Android, confirmer si les règles de facturation des boutiques autorisent ce mode de paiement pour les avantages numériques concernés.

## Variables d'environnement
1. Copier `.env.example` vers `.env`.
2. Remplir les URLs et identifiants non secrets depuis les tableaux de bord officiels.
3. Définir les secrets seulement dans les variables du serveur/hébergeur. Ne jamais committer `.env`.
4. Utiliser `GET /api/config` pour voir uniquement les paramètres publics et l'état de configuration, jamais les secrets.

## À faire avant lancement public
- Authentification réelle et autorisation par rôle (utilisateur/modérateur/admin).
- Base de données, stockage média, contrôle de taille/type des fichiers et URLs signées.
- Signalement, blocage, modération, recours et suppression de compte.
- Preuve de consentement aux conditions stockée côté serveur avec version/date; la case actuelle est uniquement une démo.
- Politique de confidentialité finale, identité légale de l'éditeur, contact, durées de conservation et vérification juridique.
- Tests de sécurité, sauvegardes, logs, alertes, limites de débit distribuées et HTTPS.
