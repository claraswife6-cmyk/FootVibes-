# État d’intégration v17

- Ajouté : likes uniques par utilisateur Appwrite, endpoint GET d’état, bascule ajout/retrait, compteur recalculé, configuration et schéma documentés.
- Conservé : upload média serveur Appwrite, posts, commentaires, messagerie, favoris et autres intégrations v16.
- Validation locale : syntaxe et tests fumée du dépôt.
- À configurer : APPWRITE_LIKES_COLLECTION_ID et attributs de collection.
- Non confirmé sans identifiants de déploiement : connexion au projet Appwrite réel et tests multi-utilisateurs.
- Limite : le recalcul du compteur peut subir des courses concurrentes sous fort trafic ; une Appwrite Function transactionnelle est recommandée avant montée en charge.
