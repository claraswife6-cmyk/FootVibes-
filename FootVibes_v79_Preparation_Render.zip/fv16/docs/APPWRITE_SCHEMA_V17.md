# Configuration Appwrite — FootVibes v17

## Collection `likes`
Créer une collection Appwrite puis renseigner son ID dans `APPWRITE_LIKES_COLLECTION_ID`. Attributs obligatoires :
- `postId`: string, 36 caractères maximum (index recommandé).
- `userId`: string, 36 caractères maximum (index recommandé).

Permissions : la création est faite par le serveur avec la clé API privée. Les documents sont créés avec lecture publique et suppression autorisée au propriétaire Appwrite. Le serveur vérifie toujours l’identité via le JWT Appwrite.

## Fonctionnement
- `POST /api/social/posts/like` avec `{ "postId": "..." }` bascule le like de l’utilisateur connecté (ajout/retrait).
- `GET /api/social/posts/like?postId=...` retourne l’état de like de l’utilisateur connecté.
- Le compteur de la publication est recalculé à partir des documents de likes.

Important : configurer `APPWRITE_DATABASE_ID`, `APPWRITE_POSTS_COLLECTION_ID`, `APPWRITE_LIKES_COLLECTION_ID`, et créer les attributs avant utilisation. Pour un très grand trafic, remplacer le recalcul complet par un compteur transactionnel/Function afin d’éviter les courses concurrentes.
