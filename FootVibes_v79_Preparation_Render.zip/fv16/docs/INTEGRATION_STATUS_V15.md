# État d’intégration v15

- Favoris de publications : API persistante Appwrite GET/POST/DELETE, authentification JWT et filtre par propriétaire.
- Flux, commentaires, likes compteur, messagerie texte : hérités de v14.
- Configuration réelle requise : `APPWRITE_FAVORITES_COLLECTION_ID` + collection/attributs Appwrite.
- Non terminé : upload des médias dans Appwrite Storage, likes uniques/idempotents, interface d’affichage complète des favoris, LiveKit UI/appels, OneSignal device registration, confirmation de paiement YelenPay par webhook signé, packaging iOS/Android.
- Les tests smoke ne remplacent pas un test d’intégration avec un projet Appwrite réel.
