# État d'intégration v16

- Ajout de `/api/social/media` pour l'envoi authentifié vers Appwrite Storage.
- Publication avec texte et/ou média; l'URL média est stockée dans le document de publication.
- Limite de fichier 10 Mo et liste de types autorisés côté serveur.
- La clé API Appwrite reste côté serveur.

À tester sur le projet Appwrite réel : bucket, permissions de lecture, attribut `mediaUrl` dans la collection des publications et limites de taille configurées.

Toujours à intégrer : likes idempotents par utilisateur, synchronisation temps réel, appels LiveKit dans l'interface, inscription OneSignal, webhook YelenPay signé et activation d'abonnement vérifiée.
