# Statut d’intégration — FootVibes v23

- Profil : édition du nom via Appwrite Account; username et bio dans les préférences Appwrite.
- Vérifications locales : syntaxe JavaScript et tests fumée automatisés.
- Non vérifié ici : connexion à un vrai projet Appwrite, autorisations de plateforme, sauvegarde sur appareil réel.
- Toujours en attente : galerie/statistiques profil, catalogue Reels/wallpapers, appels entrants, notifications d’événements, webhook de paiement YelenPay, packaging natif iOS/Android et tests de production.
- Ne pas accorder Premium/Partenaire sans confirmation serveur signée par le prestataire.
