# Schéma Appwrite requis pour FootVibes v12

Ces routes utilisent l'API REST Appwrite côté serveur. Les clés privées restent uniquement dans les variables d'environnement de l'hébergeur.

## Variables serveur
- `PUBLIC_APPWRITE_ENDPOINT` : endpoint Appwrite, par ex. `https://cloud.appwrite.io/v1`
- `PUBLIC_APPWRITE_PROJECT_ID` : ID du projet
- `APPWRITE_API_KEY` : clé serveur avec les permissions nécessaires pour lire/créer/modifier les documents ciblés
- `APPWRITE_DATABASE_ID` : ID de la base
- `APPWRITE_POSTS_COLLECTION_ID` : ID de la collection `posts`

## Collection `posts`
Créer les attributs suivants dans Appwrite Database > Tables/Collections (selon l'interface Appwrite):
- `userId`: string, 36 caractères minimum
- `name`: string, 100 caractères
- `text`: string, 5000 caractères
- `mediaUrl`: string, 2048 caractères, facultatif
- `kind`: string, 20 caractères (`post`, `reel`, `wallpaper`)
- `likes`: integer, défaut 0
- `comments`: integer, défaut 0

Activer la sécurité au niveau document si disponible. Le serveur attribue des permissions de lecture publique et de modification/suppression au propriétaire. Ne donne pas de droits de lecture aux données privées comme les messages.

## Routes implémentées
- `GET /api/social/posts?limit=20` : charge les publications via Appwrite.
- `POST /api/social/posts` avec `Authorization: Bearer <Appwrite JWT>` et `{ "text": "...", "kind": "post" }` : vérifie la session Appwrite et crée une publication.
- `POST /api/social/posts/like` avec `{ "postId": "..." }` : incrémente le compteur de likes.

## Limites à connaître
Le like de cette version incrémente le compteur, mais ne garantit pas l'unicité d'un like par utilisateur. Il faut une collection dédiée `likes` et une contrainte logique unique pour une production à grande échelle. Les médias ne sont pas encore envoyés à Appwrite Storage par cette route. Les messages, appels, paiement confirmé, push, modération et applications natives doivent être implémentés/testés séparément. Ne pas activer de paiement réel tant que le webhook signé du prestataire n'est pas vérifié.
