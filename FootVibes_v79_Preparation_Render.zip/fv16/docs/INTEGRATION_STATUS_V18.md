# État d'intégration — v18

- Ajout d'une entrée Favoris à la navigation.
- Page Favoris connectée aux routes serveur authentifiées GET/DELETE.
- Retrait d'un favori depuis la page, avec rechargement de la liste.
- Affichage d'un état vide et des erreurs de configuration.
- Validation locale : `npm run check` et `npm test` (13 contrôles fumée).

Non vérifié : accès réel au projet Appwrite de l'utilisateur, droits de collection et déploiement en production.
