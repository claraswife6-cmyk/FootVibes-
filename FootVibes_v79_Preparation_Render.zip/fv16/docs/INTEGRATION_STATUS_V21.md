# État d'intégration v21

## Ajouté
- Boutons d'appel audio et vidéo dans la page Messagerie.
- Requête de jeton signée par le serveur via `/api/livekit/token` et JWT Appwrite.
- Connexion au salon LiveKit côté navigateur, activation du microphone, caméra optionnelle, rendu des pistes distantes et bouton de fin d'appel.
- Affichage des erreurs de configuration et des permissions.

## À configurer/tester
- Variables privées Appwrite et LiveKit sur l'hébergement.
- URL `PUBLIC_LIVEKIT_URL` avec WebSocket sécurisé en production.
- Test réel entre deux comptes et deux appareils.
- Signalisation des appels entrants et notifications OneSignal non incluses.
