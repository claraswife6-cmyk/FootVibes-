# Vérification du déploiement — FootVibes v10

## Avant de pousser vers GitHub
- Vérifier que `package.json` est à la racine du dépôt.
- Vérifier que `.env` n'est pas suivi par Git. Le `.gitignore` exclut `.env` et `.env.*.local`, mais un `.env` déjà commité doit être retiré de l'historique et les secrets renouvelés.
- Lancer `npm run check` puis `npm test`.

## Paramètres Render
- Runtime: Node.js
- Build: `npm install`
- Start: `npm start`
- Health check: `/api/health`
- Node: 20 ou plus récent
- Variables: configurer uniquement dans Render > Environment.

## Après déploiement
- Vérifier le statut Live dans Render et consulter les logs.
- Ouvrir `/api/health` sur le domaine HTTPS attribué.
- Vérifier la page d'accueil et les routes publiques.
- Tester une intégration à la fois; un serveur en ligne ne signifie pas que les clés, permissions ou webhooks sont valides.
- Ne jamais marquer un paiement comme réussi sans confirmation côté serveur auprès du prestataire.

## Limites connues
Le contrôle de santé et les tests fumée ne constituent pas un audit de sécurité ni une recette fonctionnelle complète. Les fonctionnalités non reliées à un backend restent à implémenter avant commercialisation.
