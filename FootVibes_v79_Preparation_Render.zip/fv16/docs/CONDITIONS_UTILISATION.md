# FootVibes — modèle de conditions d’utilisation

**Statut : modèle de travail à compléter et faire vérifier juridiquement avant diffusion publique.**

## 1. Éditeur
- Nom légal de l’éditeur : [À COMPLÉTER]
- Adresse : [À COMPLÉTER]
- Contact support : [À COMPLÉTER]
- Contact relatif à la confidentialité : [À COMPLÉTER]

## 2. Services
FootVibes vise à proposer des fonctions sociales, des publications multimédias, des Reels, des wallpapers, des informations de football, des profils et une messagerie. Les services réellement disponibles doivent être précisés dans la version publiée.

## 3. Compte et sécurité
L’utilisateur doit fournir des informations exactes, protéger ses identifiants et signaler tout accès non autorisé. Les règles d’âge minimum, le traitement des mineurs et les contrôles associés doivent être déterminés avant lancement.

## 4. Contenus interdits et modération
Sont notamment interdits les contenus illégaux, les menaces, le harcèlement, la fraude, l’usurpation d’identité, les contenus portant atteinte aux droits d’autrui et le spam abusif. Un système de signalement, de blocage, de revue et de recours doit être opérationnel. Les mesures de modération doivent être proportionnées et documentées.

## 5. Propriété intellectuelle
L’utilisateur garantit disposer des droits et autorisations nécessaires pour les contenus publiés. Une procédure de signalement de droits d’auteur et de traitement des demandes doit être ajoutée avec des coordonnées valides.

## 6. Offres Premium et Partenaire
Les prix, taxes, avantages, durée, renouvellement automatique éventuel, annulation, remboursements, conditions d’éligibilité et sanctions doivent être affichés avant paiement. Une confirmation serveur du prestataire est obligatoire avant activation. Les règles Apple App Store et Google Play doivent être vérifiées selon les produits vendus et les pays concernés.

## 7. Disponibilité et données externes
Les scores, calendriers et statistiques peuvent dépendre de fournisseurs tiers et de leurs conditions de licence. Les fonctions peuvent être indisponibles pendant une maintenance ou une panne.

## 8. Suspension et suppression
Les violations graves ou répétées peuvent entraîner une restriction après examen proportionné. Décrire les notifications, les voies de recours et la procédure de suppression du compte. Les demandes de suppression des données doivent être traitées conformément au droit applicable, sous réserve des obligations légales de conservation.

## 9. Responsabilité et droit applicable
À compléter selon le droit applicable, les obligations impératives, le lieu d’établissement de l’éditeur et les marchés visés. Faire relire par un juriste.

## 10. Mise à jour
Date d’entrée en vigueur : [À COMPLÉTER]. Version : [À COMPLÉTER].

Powered by Trehza Mendoza
