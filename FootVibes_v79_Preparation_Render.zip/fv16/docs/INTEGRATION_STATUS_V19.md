# État d'intégration — v19

- Ajout du rafraîchissement automatique de la conversation toutes les 5 secondes pendant que la page Messagerie est active.
- Affichage du sens du message, des liens média et de l'heure de synchronisation.
- Les requêtes restent authentifiées via JWT Appwrite.
- Vérification locale : `npm run check` et `npm test`.
- Les tests de fumée sont locaux; aucun compte Appwrite distant n'a été testé.
- À poursuivre : Appwrite Realtime natif, accusés de lecture complets, pièces jointes intégrées, appels LiveKit, OneSignal, webhooks YelenPay vérifiés.
