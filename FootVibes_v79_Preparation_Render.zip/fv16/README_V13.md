# FootVibes v13 — integration backend

This archive adds Appwrite-backed comment, messaging and follow routes, plus a server-side OneSignal send route. It retains Appwrite-backed posts, API-Football proxy endpoints, and LiveKit token generation.

## Deploy
- Node.js 20+
- Build: `npm install`
- Start: `npm start`
- Set `PUBLIC_APP_URL`, Appwrite project/database/collection IDs, `APPWRITE_API_KEY`, `FOOTBALL_API_KEY`, LiveKit credentials and OneSignal credentials in the hosting provider's private environment settings.
- For the new routes, set `APPWRITE_COMMENTS_COLLECTION_ID`, `APPWRITE_MESSAGES_COLLECTION_ID`, and `APPWRITE_FOLLOWS_COLLECTION_ID`.
- Create schema as described in `docs/APPWRITE_SCHEMA_V13.md`.

## Important production status
This is a deployable backend starter, not a claim that every app screen and feature is finished. API routes need to be connected to UI controls and tested against the user's actual configured Appwrite project. Media upload/storage, full realtime UI, reliable per-user like/favorite semantics, moderation, verified YelenPay webhook/entitlements and native app packaging remain unfinished. YelenPay webhook remains intentionally disabled rather than accepting unverified payment claims.

Do not commit `.env` or secret keys. API keys belong only in the host's secret environment configuration.
