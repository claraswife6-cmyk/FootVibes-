# FootVibes v17 — Likes uniques

Cette version ajoute le basculement J’aime/J’aime plus et stocke les likes par utilisateur authentifié dans une collection Appwrite dédiée. Elle conserve les médias v16, les favoris, commentaires, messagerie et les autres modules déjà présents.

## Configuration nécessaire
1. Créer une collection `likes` avec `postId` et `userId` (voir `docs/APPWRITE_SCHEMA_V17.md`).
2. Définir `APPWRITE_LIKES_COLLECTION_ID` dans les variables d’environnement privées du serveur.
3. Vérifier que les collections posts et likes sont accessibles à la clé API Appwrite côté serveur.
4. Lancer `npm run check` puis `npm test`.

Les tests locaux ne remplacent pas un test avec un projet Appwrite réel. Les secrets restent dans l’environnement serveur et ne doivent pas être partagés dans le chat ni commités.
