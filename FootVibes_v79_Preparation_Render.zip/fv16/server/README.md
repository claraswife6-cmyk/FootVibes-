# API serveur FootVibes

Serveur Node.js sans dépendance externe (Node 20+). Il sert l'interface et fournit `/api/health`, `/api/config`, `/api/football/fixtures` et `/api/payments/links`.

## Limites assumées
- API-Football est appelée côté serveur et la clé n'est jamais renvoyée au navigateur.
- Les liens YelenPay ne peuvent être remplis que par le propriétaire avec les URL réelles du compte marchand.
- Le webhook de paiement répond 501 tant que la documentation/signature officielle du prestataire n'est pas configurée. Ne pas activer Premium/Partenaire à partir d'une redirection de navigateur.
- Appwrite, OneSignal et LiveKit sont préconfigurés par variables mais l'authentification, l'émission de jetons LiveKit et l'envoi push serveur nécessitent les flux d'intégration indiqués dans docs/INTEGRATIONS_REELLES.md.
- Le serveur n'est pas une plateforme de production complète : ajouter base de données, authentification/autorisation, stockage, modération, journalisation et tests de sécurité avant ouverture publique.
