import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
loadEnv(path.join(ROOT, '.env'));
const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.mp4':'video/mp4','.txt':'text/plain; charset=utf-8','.md':'text/markdown; charset=utf-8','.ico':'image/x-icon'};
const hits = new Map();
const adminSessions = new Map();
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'payment-proofs');
const PROOFS_FILE = path.join(DATA_DIR, 'payment-proofs.json');
const VERIFY_FILE = path.join(DATA_DIR, 'verification-requests.json');
const VERIFIED_FILE = path.join(DATA_DIR, 'verified-users.json');
const ADMIN_AUDIT_FILE = path.join(DATA_DIR, 'admin-audit.json');
const ACCOUNT_STATUS_FILE = path.join(DATA_DIR, 'account-status.json');
const REPORTS_FILE = path.join(DATA_DIR, 'content-reports.json');
const GOAL_ALERTS_FILE = path.join(DATA_DIR, 'goal-alert-subscriptions.json');
const GOAL_ALERTS_STATE_FILE = path.join(DATA_DIR, 'goal-alert-state.json');
fs.mkdirSync(UPLOAD_DIR, {recursive:true});
function readProofs(){ try { return JSON.parse(fs.readFileSync(PROOFS_FILE,'utf8')); } catch { return []; } }
function saveProofs(rows){ fs.mkdirSync(DATA_DIR,{recursive:true}); fs.writeFileSync(PROOFS_FILE,JSON.stringify(rows,null,2),{mode:0o600}); }
function readRows(file){try{const rows=JSON.parse(fs.readFileSync(file,'utf8'));return Array.isArray(rows)?rows:[]}catch{return []}}
function saveRows(file,rows){fs.mkdirSync(DATA_DIR,{recursive:true});fs.writeFileSync(file,JSON.stringify(rows,null,2),{mode:0o600})}
function recordAdminAudit(action, targetId, details=''){const rows=readRows(ADMIN_AUDIT_FILE);rows.unshift({id:crypto.randomUUID(),action:String(action).slice(0,80),targetId:String(targetId||'').slice(0,120),details:String(details||'').slice(0,300),at:new Date().toISOString()});saveRows(ADMIN_AUDIT_FILE,rows.slice(0,500));}
function verifiedUserIds(){return new Set([...readRows(VERIFIED_FILE).map(x=>x.userId),...String(process.env.FOOTVIBES_VERIFIED_USER_IDS||'').split(',').map(x=>x.trim()).filter(Boolean)])}
function cookies(req){ return Object.fromEntries((req.headers.cookie||'').split(';').map(v=>v.trim()).filter(Boolean).map(v=>{const i=v.indexOf('=');return [v.slice(0,i),decodeURIComponent(v.slice(i+1))]})); }
function isAdmin(req){ const token=cookies(req).fv_admin; const row=token&&adminSessions.get(token); return Boolean(row&&row.expires>Date.now()); }
async function readJson(req,max=7*1024*1024){let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>max)throw Object.assign(new Error('Corps de requête trop volumineux'),{status:413});}try{return JSON.parse(raw||'{}')}catch{throw Object.assign(new Error('JSON invalide'),{status:400})}}
function loadEnv(file) { if (!fs.existsSync(file)) return; for (const line of fs.readFileSync(file,'utf8').split(/\r?\n/)) { const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/); if(m && process.env[m[1]]===undefined) process.env[m[1]]=m[2].replace(/^(['"])(.*)\1$/,'$2'); } }
function json(res, status, data) { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}); res.end(JSON.stringify(data,null,2)); }
function publicConfig() { return {
 appName: process.env.APP_NAME || 'FootVibes', appEnv: process.env.APP_ENV || 'development',
 appwriteEndpoint: process.env.PUBLIC_APPWRITE_ENDPOINT || '', appwriteProjectId: process.env.PUBLIC_APPWRITE_PROJECT_ID || '',
 oneSignalAppId: process.env.PUBLIC_ONESIGNAL_APP_ID || '', livekitUrl: process.env.PUBLIC_LIVEKIT_URL || '',
 supportEmail: process.env.PUBLIC_SUPPORT_EMAIL || '', supportUrl: process.env.PUBLIC_SUPPORT_URL || '',
 social: {tiktok: process.env.PUBLIC_SOCIAL_TIKTOK_URL || '', facebook: process.env.PUBLIC_SOCIAL_FACEBOOK_URL || '', instagram: process.env.PUBLIC_SOCIAL_INSTAGRAM_URL || '', whatsapp: process.env.PUBLIC_SOCIAL_WHATSAPP_URL || ''},
 payments: {premiumUrl: process.env.YELENPAY_PREMIUM_URL || '', partnerUrl: process.env.YELENPAY_PARTNER_URL || '', premiumPriceXof: 10000, premiumPeriod: 'month', partnerPriceXof: 5000, partnerPeriod: 'one-time'},
 integrations: {footballConfigured: Boolean(process.env.FOOTBALL_API_KEY), appwriteConfigured: Boolean(process.env.PUBLIC_APPWRITE_ENDPOINT && process.env.PUBLIC_APPWRITE_PROJECT_ID), livekitConfigured: Boolean(process.env.PUBLIC_LIVEKIT_URL), paymentsConfigured: Boolean(process.env.YELENPAY_PREMIUM_URL && process.env.YELENPAY_PARTNER_URL)}
 }; }
function allowedRate(req) { const ip=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim(); const now=Date.now(); const item=hits.get(ip); if(!item || now-item.start>60000) { hits.set(ip,{start:now,count:1}); return true; } item.count++; return item.count<=100; }
async function handle(req,res) {
 res.setHeader('X-Content-Type-Options','nosniff'); res.setHeader('Referrer-Policy','strict-origin-when-cross-origin'); res.setHeader('X-Frame-Options','SAMEORIGIN'); res.setHeader('Permissions-Policy','camera=(self), microphone=(self), geolocation=()');
 if (!allowedRate(req)) return json(res,429,{error:'Trop de requêtes. Réessayez plus tard.'});
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET' && url.pathname==='/api/health') return json(res,200,{status:'ok',app:'FootVibes',timestamp:new Date().toISOString(),mode:process.env.APP_ENV||'development'});
 if(req.method==='GET' && url.pathname==='/api/config') return json(res,200,publicConfig());
 // Authoritative account capabilities for profile UI. Never derive paid permissions from client-side preferences.
 if(req.method==='GET' && url.pathname==='/api/account/entitlements') {
  let user; try { user=await appwriteIdentity(req); } catch(e) { return json(res,e.status||401,{error:e.message}); }
  const partner=hasPartnerAccess(user), verified=verifiedUserIds().has(user.$id);
  return json(res,200,{userId:user.$id,displayName:String(user.name||'').slice(0,100),role:partner?'partner':'classic',verified,capabilities:{viewContent:true,interact:true,publish:partner,messaging:partner,audioCalls:partner,videoCalls:partner,professionalLive:partner&&verified},source:'server',note:'Les droits Partenaire proviennent de la liste serveur. La certification est indépendante et validée administrativement.'});
 }
 if(req.method==='GET' && url.pathname==='/api/streams') {
  let source=[]; try { source=JSON.parse(process.env.FOOTVIBES_STREAM_CATALOG_JSON||'[]'); } catch { return json(res,500,{error:'FOOTVIBES_STREAM_CATALOG_JSON doit contenir un JSON valide.'}); }
  if(!Array.isArray(source)) return json(res,500,{error:'Le catalogue de diffusion doit être une liste JSON.'});
  const allowedHosts=new Set(['fifa.com','www.fifa.com','plus.fifa.com','youtube.com','www.youtube.com','youtu.be','www.dazn.com','dazn.com']);
  const streams=source.filter(x=>x&&typeof x.title==='string'&&typeof x.url==='string'&&['free','premium'].includes(x.access)&&x.rightsConfirmed===true).filter(x=>{try{const u=new URL(x.url);return u.protocol==='https:'&&(allowedHosts.has(u.hostname)||u.hostname.endsWith('.fifa.com'));}catch{return false;}}).map(x=>({id:String(x.id||'').slice(0,80),title:x.title.slice(0,120),competition:String(x.competition||'Football').slice(0,100),access:x.access,url:x.access==='free'?x.url:'',provider:String(x.provider||'Diffuseur officiel').slice(0,100),territory:String(x.territory||'À vérifier').slice(0,100),embedUrl:typeof x.embedUrl==='string'&&/^https:\/\/www\.youtube-nocookie\.com\/embed\/[A-Za-z0-9_-]{11}(?:\?[^\s]*)?$/.test(x.embedUrl)&&x.access==='free'?x.embedUrl:''}));
  return json(res,200,{streams,configured:streams.length>0,rightsRequired:true,message:streams.length?'Catalogue filtré selon les droits confirmés.':'Aucune diffusion autorisée configurée. Les liens génériques ne sont pas présentés comme des matchs disponibles.'});
 }
 if(req.method==='POST' && url.pathname==='/api/payment-proofs') {
   let b; try{b=await readJson(req)}catch(e){return json(res,e.status||400,{error:e.message})}
   const {plan,payerName,reference,contact,fileName,mimeType,dataUrl}=b;
   if(!['premium','partner'].includes(plan)||![payerName,reference,contact].every(v=>typeof v==='string'&&v.trim().length>1)||typeof dataUrl!=='string'||!/^data:(image\/(jpeg|png)|application\/pdf);base64,/.test(dataUrl)) return json(res,400,{error:'Informations ou fichier de preuve invalides.'});
   const encoded=dataUrl.split(',')[1]||''; let bytes; try{bytes=Buffer.from(encoded,'base64')}catch{return json(res,400,{error:'Fichier illisible.'})}
   if(!bytes.length||bytes.length>5*1024*1024)return json(res,413,{error:'La preuve doit faire moins de 5 Mo.'});
   const ext=mimeType==='application/pdf'?'pdf':mimeType==='image/png'?'png':'jpg'; const id='FV-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase();
   fs.writeFileSync(path.join(UPLOAD_DIR,id+'.'+ext),bytes,{mode:0o600}); const rows=readProofs(); rows.unshift({id,plan,payerName:payerName.trim().slice(0,100),reference:reference.trim().slice(0,120),contact:contact.trim().slice(0,160),file:id+'.'+ext,originalFileName:String(fileName||'preuve').slice(0,160),createdAt:new Date().toISOString(),status:'pending'}); saveProofs(rows); return json(res,201,{id,status:'pending',message:'Preuve enregistrée en attente de vérification.'});
 }
 if(req.method==='POST' && url.pathname==='/api/admin/login') {
   if(!process.env.ADMIN_PASSWORD) return json(res,503,{error:'Configurez ADMIN_PASSWORD dans .env côté serveur puis redémarrez le serveur.'});
   let b;try{b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const email=String(b.email||'').trim().toLowerCase(), password=String(b.password||''); const good=email==='claraswife6@gmail.com'&&(!process.env.ADMIN_EMAIL||email===process.env.ADMIN_EMAIL.trim().toLowerCase())&&password.length>0&&crypto.timingSafeEqual(crypto.createHash('sha256').update(password).digest(),crypto.createHash('sha256').update(process.env.ADMIN_PASSWORD).digest());
   if(!good)return json(res,401,{error:'Identifiants administrateur incorrects.'}); const token=crypto.randomBytes(32).toString('hex');adminSessions.set(token,{expires:Date.now()+8*60*60*1000});res.setHeader('Set-Cookie',`fv_admin=${token}; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=28800${process.env.APP_ENV==='production'?'; Secure':''}`);return json(res,200,{ok:true,expiresIn:28800});
 }
 if(req.method==='POST' && url.pathname==='/api/admin/logout'){const token=cookies(req).fv_admin;if(token)adminSessions.delete(token);res.setHeader('Set-Cookie','fv_admin=; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=0');return json(res,200,{ok:true});}
 if(req.method==='POST' && url.pathname==='/api/certification/request') {
   let identity,b;try{identity=await appwriteIdentity(req);b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const reason=String(b.reason||'').trim();if(reason.length<20||reason.length>1000)return json(res,400,{error:'Explique ta demande en 20 à 1000 caractères.'});
   const rows=readRows(VERIFY_FILE);const existing=rows.find(x=>x.userId===identity.$id&&x.status==='pending');if(existing)return json(res,200,{id:existing.id,status:existing.status,message:'Une demande est déjà en attente.'});
   const row={id:crypto.randomUUID(),userId:identity.$id,displayName:String(identity.name||'').slice(0,100),reason,createdAt:new Date().toISOString(),status:'pending'};rows.unshift(row);saveRows(VERIFY_FILE,rows);return json(res,201,{id:row.id,status:row.status,message:'Demande reçue. La certification sera attribuée uniquement après vérification administrative.'});
 }
 if(req.method==='GET' && url.pathname==='/api/certification/status') {
   let identity;try{identity=await appwriteIdentity(req)}catch(e){return json(res,e.status||400,{error:e.message})}
   const request=readRows(VERIFY_FILE).find(x=>x.userId===identity.$id);return json(res,200,{verified:verifiedUserIds().has(identity.$id),request:request?{status:request.status,createdAt:request.createdAt,reviewedAt:request.reviewedAt||null,note:request.adminNote||''}:null});
 }
 if(req.method==='GET' && url.pathname==='/api/admin/certification-requests') {
  if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});
  const all=readRows(VERIFY_FILE).map(({reason,...row})=>({...row,reason}));
  const status=String(url.searchParams.get('status')||'all').toLowerCase();
  const q=String(url.searchParams.get('q')||'').trim().toLowerCase().slice(0,120);
  const limit=Math.min(100,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'50',10)||50));
  const offset=Math.max(0,Number.parseInt(url.searchParams.get('offset')||'0',10)||0);
  if(!['all','pending','approved','rejected'].includes(status))return json(res,400,{error:'Filtre de statut invalide.'});
  const filtered=all.filter(x=>(status==='all'||String(x.status||'pending')===status)&&(!q||[x.displayName,x.userId,x.reason,x.status].some(v=>String(v||'').toLowerCase().includes(q))));
  return json(res,200,{requests:filtered.slice(offset,offset+limit),total:filtered.length,limit,offset,hasMore:offset+limit<filtered.length});
 }
 if(req.method==='GET' && url.pathname==='/api/admin/audit') {if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});return json(res,200,{events:readRows(ADMIN_AUDIT_FILE).slice(0,100)});}
 if(req.method==='POST' && url.pathname.startsWith('/api/admin/users/') && url.pathname.endsWith('/status')) {
  if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});
  let b;try{b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
  const targetId=decodeURIComponent(url.pathname.split('/').slice(-2,-1)[0]).trim();
  const status=String(b.status||'').trim();const reason=String(b.reason||'').trim();
  if(!targetId||targetId.length>160||targetId==='undefined'||targetId==='null')return json(res,400,{error:'Identifiant utilisateur invalide.'});
  if(!['active','suspended'].includes(status))return json(res,400,{error:'Statut de compte invalide.'});
  if(reason.length<5||reason.length>500)return json(res,400,{error:'Un motif de 5 à 500 caractères est obligatoire.'});
  const rows=readRows(ACCOUNT_STATUS_FILE);const previous=rows.find(x=>x.userId===targetId);
  const row={userId:targetId,status,reason,updatedAt:new Date().toISOString(),updatedBy:'admin'};
  // If the server API key is configured, also change the authoritative Appwrite account status.
  // Fail closed: never claim success if Appwrite rejected the change.
  let appwriteUpdated=false;
  if(process.env.APPWRITE_API_KEY&&process.env.PUBLIC_APPWRITE_ENDPOINT&&process.env.PUBLIC_APPWRITE_PROJECT_ID){
   try { await awRequest('PUT',`/users/${encodeURIComponent(targetId)}/status`,{status:status==='active'}); appwriteUpdated=true; }
   catch(e){ return json(res,e.status||502,{error:'Appwrite n’a pas accepté le changement de statut. Aucun changement local n’a été enregistré.',detail:process.env.APP_ENV==='development'?e.message:undefined}); }
  } else {
   return json(res,503,{error:'Configurez APPWRITE_API_KEY, PUBLIC_APPWRITE_ENDPOINT et PUBLIC_APPWRITE_PROJECT_ID pour modifier réellement le statut du compte Appwrite.'});
  }
  const next=[row,...rows.filter(x=>x.userId!==targetId)];saveRows(ACCOUNT_STATUS_FILE,next.slice(0,5000));
  recordAdminAudit('account:'+status,targetId,'reason='+reason+'; appwriteUpdated='+appwriteUpdated);
  return json(res,200,{ok:true,userId:targetId,status,previousStatus:previous?.status||'active',updatedAt:row.updatedAt,appwriteUpdated,message:status==='suspended'?'Compte suspendu dans Appwrite et bloqué côté API FootVibes.':'Compte réactivé dans Appwrite et côté API FootVibes.'});
 }
 if(req.method==='GET' && url.pathname==='/api/admin/users') {
  if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});
  // Prefer the authoritative Appwrite Users API when server credentials are configured.
  if(process.env.APPWRITE_API_KEY&&process.env.PUBLIC_APPWRITE_ENDPOINT&&process.env.PUBLIC_APPWRITE_PROJECT_ID){
   try {
    const index=new Map();const add=(id,source,extra={})=>{if(!id)return;const key=String(id).slice(0,160);const old=index.get(key)||{userId:key,sources:[],verified:false,partner:false,reportCount:0,lastActivity:null};if(!old.sources.includes(source))old.sources.push(source);Object.assign(old,extra);index.set(key,old)};
    const limit=Math.min(100,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'50',10)||50));
    const offset=Math.min(5000,Math.max(0,Number.parseInt(url.searchParams.get('offset')||'0',10)||0));
    const localStatuses=readRows(ACCOUNT_STATUS_FILE);const partnerIds=new Set(String(process.env.FOOTVIBES_PARTNER_USER_IDS||'').split(',').map(v=>v.trim()).filter(Boolean));
    let directoryTotal=0;
    for(let pageOffset=0;pageOffset<5000;pageOffset+=100){
     const queries=[{method:'limit',values:[100]},{method:'offset',values:[pageOffset]}].map(q=>'queries[]='+encodeURIComponent(JSON.stringify(q))).join('&');
     const aw=await awRequest('GET','/users?'+queries);const batch=aw.users||[];directoryTotal=Number(aw.total||directoryTotal);
     for(const u of batch){const local=localStatuses.find(x=>x.userId===u.$id);add(u.$id,'appwrite',{displayName:String(u.name||'').slice(0,100),email:String(u.email||'').slice(0,200),appwriteStatus:u.status?'active':'suspended',accountStatus:local?.status||(u.status?'active':'suspended'),statusReason:local?.reason||'',statusUpdatedAt:local?.updatedAt||null,lastActivity:u.accessedAt||u.registration||null,verified:verifiedUserIds().has(u.$id),partner:partnerIds.has(u.$id)});}
     if(batch.length<100||(directoryTotal>0&&pageOffset+batch.length>=directoryTotal))break;
    }
    for(const r of readRows(VERIFY_FILE)){add(r.userId,'certification',{displayName:String(r.displayName||'').slice(0,100),verified:verifiedUserIds().has(r.userId),lastActivity:r.reviewedAt||r.createdAt||null})}
    for(const r of readRows(REPORTS_FILE)){add(r.reporterId,'reporter',{reportCount:(index.get(String(r.reporterId))?.reportCount||0)+1,lastActivity:r.createdAt||null});add(r.targetId,'reported-content')}
    for(const r of readRows(ACCOUNT_STATUS_FILE)){add(r.userId,'account-status',{accountStatus:r.status,statusReason:r.reason,statusUpdatedAt:r.updatedAt})}
    const all=[...index.values()].sort((a,b)=>String(b.lastActivity||'').localeCompare(String(a.lastActivity||'')));
    const q=String(url.searchParams.get('q')||'').trim().toLocaleLowerCase().slice(0,100);const role=String(url.searchParams.get('role')||'all');
    const filtered=all.filter(u=>(!q||[u.userId,u.displayName,u.email,...u.sources].some(v=>String(v||'').toLocaleLowerCase().includes(q)))&&(role==='all'||(role==='partner'&&u.partner)||(role==='verified'&&u.verified)||(role==='reported'&&u.reportCount>0)||(role==='classic'&&!u.partner)));
    return json(res,200,{users:filtered.slice(offset,offset+limit),total:filtered.length,limit,offset,completeDirectory:directoryTotal<=5000,source:'appwrite-users-api',note:'Annuaire Appwrite chargé côté serveur. Le statut est modifié dans Appwrite et dans FootVibes.'});
   } catch(e){return json(res,e.status||502,{error:'Impossible de charger l’annuaire Appwrite.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
  }
  const index=new Map();const add=(id,source,extra={})=>{if(!id)return;const key=String(id).slice(0,160);const old=index.get(key)||{userId:key,sources:[],verified:false,partner:false,reportCount:0,lastActivity:null};if(!old.sources.includes(source))old.sources.push(source);Object.assign(old,extra);index.set(key,old)};
  for(const r of readRows(VERIFY_FILE)){add(r.userId,'certification',{displayName:String(r.displayName||'').slice(0,100),verified:verifiedUserIds().has(r.userId),lastActivity:r.reviewedAt||r.createdAt||null})}
  for(const r of readRows(REPORTS_FILE)){add(r.reporterId,'reporter',{reportCount:(index.get(String(r.reporterId))?.reportCount||0)+1,lastActivity:r.createdAt||null});add(r.targetId,'reported-content')}
  for(const id of String(process.env.FOOTVIBES_PARTNER_USER_IDS||'').split(',').map(v=>v.trim()).filter(Boolean))add(id,'partner-list',{partner:true});
  for(const r of readRows(ACCOUNT_STATUS_FILE)){add(r.userId,'account-status',{accountStatus:r.status,statusReason:r.reason,statusUpdatedAt:r.updatedAt})}
  const allUsers=[...index.values()].sort((a,b)=>String(b.lastActivity||'').localeCompare(String(a.lastActivity||''))).slice(0,500);
  const q=String(url.searchParams.get('q')||'').trim().toLocaleLowerCase().slice(0,100);
  const role=String(url.searchParams.get('role')||'all');
  const filtered=allUsers.filter(u=>{
   const matchesText=!q||[u.userId,u.displayName,...u.sources].some(v=>String(v||'').toLocaleLowerCase().includes(q));
   const matchesRole=role==='all'||(role==='partner'&&u.partner)||(role==='verified'&&u.verified)||(role==='reported'&&u.reportCount>0)||(role==='classic'&&!u.partner);
   return matchesText&&matchesRole;
  });
  const limit=Math.min(100,Math.max(1,Number.parseInt(url.searchParams.get('limit')||'50',10)||50));
  const offset=Math.min(500,Math.max(0,Number.parseInt(url.searchParams.get('offset')||'0',10)||0));
  const users=filtered.slice(offset,offset+limit);
  return json(res,200,{users,total:filtered.length,limit,offset,completeDirectory:false,note:'Index partiel construit à partir des demandes et signalements locaux et de la liste partenaire. Ce n’est pas un annuaire complet Appwrite.'});
 }
 if(req.method==='POST' && url.pathname==='/api/reports') {
  let identity;try{identity=await appwriteIdentity(req)}catch(e){return json(res,e.status||401,{error:e.message})}
  let b;try{b=await readJson(req,12000)}catch(e){return json(res,e.status||400,{error:e.message})}
  const targetId=String(b.targetId||'').trim(),reason=String(b.reason||'').trim(),details=String(b.details||'').trim();
  if(targetId.length<1||targetId.length>160||!['spam','harassment','violence','copyright','scam','other'].includes(reason)||details.length>1000)return json(res,400,{error:'Identifiant, motif ou description invalide.'});
  const rows=readRows(REPORTS_FILE);if(rows.some(x=>x.reporterId===identity.$id&&x.targetId===targetId&&x.status==='open'))return json(res,409,{error:'Tu as déjà signalé ce contenu. Il est en cours d’examen.'});
  const row={id:crypto.randomUUID(),reporterId:identity.$id,targetId,reason,details,createdAt:new Date().toISOString(),status:'open'};rows.unshift(row);saveRows(REPORTS_FILE,rows.slice(0,5000));return json(res,201,{id:row.id,status:row.status,message:'Signalement reçu pour examen.'});
 }
 if(req.method==='GET' && url.pathname==='/api/admin/reports') {if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});return json(res,200,{reports:readRows(REPORTS_FILE).slice(0,300)});}
 if(req.method==='POST' && url.pathname.startsWith('/api/admin/reports/')) {if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});let b;try{b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}if(!['open','reviewing','resolved','dismissed'].includes(b.status))return json(res,400,{error:'Statut de signalement invalide.'});const id=decodeURIComponent(url.pathname.split('/').pop()),rows=readRows(REPORTS_FILE),row=rows.find(x=>x.id===id);if(!row)return json(res,404,{error:'Signalement introuvable.'});row.status=b.status;row.reviewedAt=new Date().toISOString();row.adminNote=String(b.note||'').slice(0,500);saveRows(REPORTS_FILE,rows);recordAdminAudit('report:'+b.status,row.id,'target='+row.targetId+'; reason='+row.reason);return json(res,200,{ok:true,status:row.status});}
 if(req.method==='GET' && url.pathname==='/api/admin/overview') {if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});const requests=readRows(VERIFY_FILE);const verified=verifiedUserIds();const partners=String(process.env.FOOTVIBES_PARTNER_USER_IDS||'').split(',').map(v=>v.trim()).filter(Boolean);return json(res,200,{certification:{pending:requests.filter(x=>x.status==='pending').length,approved:requests.filter(x=>x.status==='approved').length,rejected:requests.filter(x=>x.status==='rejected').length,verifiedUsers:verified.size},partners:{authorizedAccounts:new Set(partners).size},note:'Les chiffres reflètent les demandes stockées localement et la liste partenaire côté serveur. Ils ne remplacent pas une vérification des paiements.'});}
 if(req.method==='GET' && url.pathname==='/api/admin/readiness') {if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});const groups=[{name:'Administration',items:[['Identifiants administrateur',Boolean(process.env.ADMIN_EMAIL&&process.env.ADMIN_PASSWORD)],['HTTPS en production',process.env.APP_ENV==='production']]},{name:'Comptes et données',items:[['Appwrite endpoint',Boolean(process.env.PUBLIC_APPWRITE_ENDPOINT)],['Appwrite project ID',Boolean(process.env.PUBLIC_APPWRITE_PROJECT_ID)],['Appwrite API key serveur',Boolean(process.env.APPWRITE_API_KEY)],['Collection de messages',Boolean(process.env.APPWRITE_MESSAGES_COLLECTION_ID)],['Collection d’appels',Boolean(process.env.APPWRITE_CALLS_COLLECTION_ID)]]},{name:'Appels et notifications',items:[['LiveKit URL',Boolean(process.env.LIVEKIT_URL)],['LiveKit API key',Boolean(process.env.LIVEKIT_API_KEY)],['LiveKit API secret',Boolean(process.env.LIVEKIT_API_SECRET)],['OneSignal App ID',Boolean(process.env.ONESIGNAL_APP_ID)],['OneSignal REST API key',Boolean(process.env.ONESIGNAL_REST_API_KEY)]]},{name:'Football et paiements',items:[['API-Football',Boolean(process.env.FOOTBALL_API_KEY)],['Lien Premium configuré',Boolean(process.env.YELENPAY_PREMIUM_URL)],['Lien Partenaire configuré',Boolean(process.env.YELENPAY_PARTNER_URL)],['Webhook de paiement sécurisé',Boolean(process.env.YELENPAY_WEBHOOK_SECRET)]]}];const checks=groups.flatMap(g=>g.items.map(([label,configured])=>({group:g.name,label,configured})));return json(res,200,{checks,configured:checks.filter(x=>x.configured).length,total:checks.length,warning:'Cette liste vérifie uniquement la présence des configurations. Elle ne prouve pas que les services sont accessibles, que les paiements sont confirmés ou que les appels fonctionnent sur de vrais appareils.'});}
 if(req.method==='POST' && url.pathname.startsWith('/api/admin/certification-requests/')) {
   if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});let b;try{b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   if(!['approved','rejected','pending'].includes(b.status))return json(res,400,{error:'Statut invalide.'});const id=decodeURIComponent(url.pathname.split('/').pop());const rows=readRows(VERIFY_FILE),row=rows.find(x=>x.id===id);if(!row)return json(res,404,{error:'Demande introuvable.'});row.status=b.status;row.reviewedAt=new Date().toISOString();row.adminNote=String(b.note||'').slice(0,500);saveRows(VERIFY_FILE,rows);recordAdminAudit('certification:'+b.status,row.id,'userId='+row.userId+'; note='+String(b.note||'').slice(0,180));
   const verified=readRows(VERIFIED_FILE).filter(x=>x.userId!==row.userId);if(b.status==='approved')verified.push({userId:row.userId,verifiedAt:row.reviewedAt,requestId:row.id});saveRows(VERIFIED_FILE,verified);return json(res,200,{ok:true,status:row.status,verified:b.status==='approved',message:'Statut de certification mis à jour.'});
 }
 if(req.method==='GET' && url.pathname==='/api/admin/payment-proofs'){if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});return json(res,200,{proofs:readProofs().map(({file,...row})=>row)});}
 if(req.method==='GET' && url.pathname.startsWith('/api/admin/payment-proofs/') && url.pathname.endsWith('/file')){if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});const id=decodeURIComponent(url.pathname.split('/').slice(-2,-1)[0]);const row=readProofs().find(x=>x.id===id);if(!row)return json(res,404,{error:'Dossier introuvable.'});const file=path.join(UPLOAD_DIR,row.file);if(!fs.existsSync(file))return json(res,404,{error:'Fichier de preuve introuvable.'});const ext=path.extname(file);res.writeHead(200,{'Content-Type':ext==='.pdf'?'application/pdf':ext==='.png'?'image/png':'image/jpeg','Cache-Control':'no-store','Content-Disposition':'inline'});return fs.createReadStream(file).pipe(res); }
 if(req.method==='POST' && url.pathname.startsWith('/api/admin/payment-proofs/')){if(!isAdmin(req))return json(res,401,{error:'Connexion administrateur requise.'});let b;try{b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}const id=decodeURIComponent(url.pathname.split('/').pop());if(!['approved','rejected','pending'].includes(b.status))return json(res,400,{error:'Statut invalide.'});const rows=readProofs(),row=rows.find(x=>x.id===id);if(!row)return json(res,404,{error:'Dossier introuvable.'});row.status=b.status;row.reviewedAt=new Date().toISOString();row.adminNote=String(b.note||'').slice(0,500);saveProofs(rows);recordAdminAudit('payment-proof:'+row.status,row.id,'plan='+row.plan+'; reference='+String(row.reference||'').slice(0,80));return json(res,200,{ok:true,status:row.status,note:'Le statut du dossier est modifié. Cette action ne confirme pas automatiquement un paiement chez YelenPay.'});}

 // Appwrite-backed social API. Collection attributes must match docs/APPWRITE_SCHEMA_V12.md.
 function accountStatus(userId){return readRows(ACCOUNT_STATUS_FILE).find(x=>x.userId===userId)?.status||'active'}
 async function appwriteIdentity(req) {
   const auth=String(req.headers.authorization||''); const jwt=auth.startsWith('Bearer ')?auth.slice(7):'';
   if(!jwt || jwt.length>8192) throw Object.assign(new Error('Connexion Appwrite requise.'),{status:401});
   const endpoint=(process.env.PUBLIC_APPWRITE_ENDPOINT||'').replace(/\/$/,'');
   const project=process.env.PUBLIC_APPWRITE_PROJECT_ID||'';
   if(!endpoint||!project) throw Object.assign(new Error('Appwrite public endpoint/project non configuré.'),{status:503});
   const r=await fetch(endpoint+'/account',{headers:{'X-Appwrite-Project':project,'X-Appwrite-JWT':jwt},signal:AbortSignal.timeout(8000)});
   if(!r.ok) throw Object.assign(new Error('Session Appwrite invalide ou expirée.'),{status:401});
   const identity=await r.json();
   if(accountStatus(identity.$id)==='suspended')throw Object.assign(new Error('Ce compte est suspendu. Contactez le support FootVibes.'),{status:403,code:'ACCOUNT_SUSPENDED'});
   return identity;
 }
 // Partner access is granted only from a server-controlled allowlist. Never trust editable client prefs for paid access.
 function hasPartnerAccess(user) {
   const ids=String(process.env.FOOTVIBES_PARTNER_USER_IDS||'').split(',').map(v=>v.trim()).filter(Boolean);
   return Boolean(user?.$id && ids.includes(user.$id));
 }
 function partnerOnly(res) {
   return json(res,403,{error:'Cette fonctionnalité est réservée aux comptes Partenaire validés.',code:'PARTNER_REQUIRED'});
 }
 async function awRequest(method,route,body) {
   const endpoint=(process.env.PUBLIC_APPWRITE_ENDPOINT||'').replace(/\/$/,'');
   if(!endpoint||!process.env.APPWRITE_API_KEY) throw Object.assign(new Error('Configurez Appwrite endpoint et APPWRITE_API_KEY côté serveur.'),{status:503});
   const r=await fetch(endpoint+route,{method,headers:{'X-Appwrite-Project':process.env.PUBLIC_APPWRITE_PROJECT_ID||'', 'X-Appwrite-Key':process.env.APPWRITE_API_KEY,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(12000)});
   const text=await r.text(); let data={}; try{data=JSON.parse(text)}catch{data={message:text}}
   if(!r.ok) throw Object.assign(new Error(data.message||'Erreur Appwrite'),{status:r.status,appwriteType:data.type});
   return data;
 }
 function awDocRoute(collection,doc='') { const db=encodeURIComponent(process.env.APPWRITE_DATABASE_ID||''); return `/databases/${db}/collections/${encodeURIComponent(collection)}/documents${doc?'/'+encodeURIComponent(doc):''}`; }
 if(req.method==='POST' && url.pathname==='/api/social/media') {
   let identity,b; try{identity=await appwriteIdentity(req);b=await readJson(req,14*1024*1024)}catch(e){return json(res,e.status||400,{error:e.message})}
   if(!hasPartnerAccess(identity))return partnerOnly(res);
   const bucket=process.env.APPWRITE_MEDIA_BUCKET_ID||'';
   if(!bucket||!process.env.APPWRITE_API_KEY)return json(res,503,{error:'Configurez APPWRITE_MEDIA_BUCKET_ID et APPWRITE_API_KEY côté serveur.'});
   const match=String(b.dataUrl||'').match(/^data:(image\/(?:jpeg|png|webp|gif)|video\/mp4|video\/quicktime);base64,([A-Za-z0-9+/=]+)$/);
   if(!match)return json(res,400,{error:'Format média non accepté. Utilise une image ou une vidéo MP4/MOV.'});
   const bytes=Buffer.from(match[2],'base64'); if(!bytes.length||bytes.length>10*1024*1024)return json(res,413,{error:'Le média doit faire 10 Mo maximum.'});
   const ext=({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','video/mp4':'mp4','video/quicktime':'mov'})[match[1]];
   const filename=(crypto.randomUUID()+'.'+ext); const form=new FormData();form.append('file',new Blob([bytes],{type:match[1]}),filename);form.append('fileId',crypto.randomUUID());
   const endpoint=(process.env.PUBLIC_APPWRITE_ENDPOINT||'').replace(/\/$/,'');
   try { const up=await fetch(endpoint+'/storage/buckets/'+encodeURIComponent(bucket)+'/files',{method:'POST',headers:{'X-Appwrite-Project':process.env.PUBLIC_APPWRITE_PROJECT_ID||'','X-Appwrite-Key':process.env.APPWRITE_API_KEY},body:form,signal:AbortSignal.timeout(30000)}); const d=await up.json().catch(()=>({}));if(!up.ok)throw Object.assign(new Error(d.message||'Échec du stockage Appwrite'),{status:up.status});
     const mediaUrl=endpoint+'/storage/buckets/'+encodeURIComponent(bucket)+'/files/'+encodeURIComponent(d.$id)+'/view?project='+encodeURIComponent(process.env.PUBLIC_APPWRITE_PROJECT_ID||'');
     return json(res,201,{fileId:d.$id,mediaUrl,mimeType:match[1],size:bytes.length,userId:identity.$id});
   }catch(e){return json(res,e.status||502,{error:'Impossible d’envoyer le média à Appwrite Storage.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 if(req.method==='GET' && url.pathname==='/api/social/posts') {
   if(!process.env.APPWRITE_DATABASE_ID||!process.env.APPWRITE_POSTS_COLLECTION_ID) return json(res,503,{error:'Configurez APPWRITE_DATABASE_ID et APPWRITE_POSTS_COLLECTION_ID côté serveur.'});
   try { const limit=Math.min(50,Math.max(1,Number(url.searchParams.get('limit')||20))); const data=await awRequest('GET',awDocRoute(process.env.APPWRITE_POSTS_COLLECTION_ID)+`?queries[]=${encodeURIComponent(JSON.stringify({method:'limit',values:[limit]}))}&queries[]=${encodeURIComponent(JSON.stringify({method:'orderDesc',attribute:'$createdAt'}))}`); return json(res,200,{posts:(data.documents||[]).map(d=>({id:d.$id,userId:d.userId,name:d.name||'Utilisateur FootVibes',text:d.text||'',mediaUrl:d.mediaUrl||'',kind:d.kind||'post',createdAt:d.$createdAt,likes:Number(d.likes||0),comments:Number(d.comments||0)}))}); }
   catch(e){return json(res,e.status||502,{error:'Impossible de charger les publications Appwrite.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 if(req.method==='POST' && url.pathname==='/api/social/posts') {
   if(!process.env.APPWRITE_DATABASE_ID||!process.env.APPWRITE_POSTS_COLLECTION_ID) return json(res,503,{error:'Configurez APPWRITE_DATABASE_ID et APPWRITE_POSTS_COLLECTION_ID côté serveur.'});
   let identity,b; try{identity=await appwriteIdentity(req);b=await readJson(req,20000)}catch(e){return json(res,e.status||400,{error:e.message})}
   if(!hasPartnerAccess(identity))return partnerOnly(res);
   const text=String(b.text||'').trim(),kind=String(b.kind||'post');
   if(!text||text.length>5000)return json(res,400,{error:'Le texte est obligatoire et limité à 5000 caractères.'});
   if(!['post','reel','wallpaper'].includes(kind))return json(res,400,{error:'Type de publication invalide.'});
   try { const doc=await awRequest('POST',awDocRoute(process.env.APPWRITE_POSTS_COLLECTION_ID),{documentId:crypto.randomUUID(),data:{userId:identity.$id,name:String(identity.name||identity.email||'Utilisateur').slice(0,100),text,mediaUrl:String(b.mediaUrl||''),kind,likes:0,comments:0},permissions:[`read("any")`,`update("user:${identity.$id}")`,`delete("user:${identity.$id}")`]}); return json(res,201,{post:{id:doc.$id,userId:identity.$id,name:doc.name,text:doc.text,kind:doc.kind,createdAt:doc.$createdAt,likes:0,comments:0}}); }
   catch(e){return json(res,e.status||502,{error:'Échec de création de publication Appwrite.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 if((req.method==='POST' || req.method==='GET') && url.pathname==='/api/social/posts/like') {
   if(!process.env.APPWRITE_DATABASE_ID||!process.env.APPWRITE_POSTS_COLLECTION_ID)return json(res,503,{error:'Collection de publications non configurée.'});
   const likesCollection=process.env.APPWRITE_LIKES_COLLECTION_ID;
   if(!likesCollection)return json(res,503,{error:'Configurez APPWRITE_LIKES_COLLECTION_ID et la collection likes décrite dans docs/APPWRITE_SCHEMA_V17.md.'});
   let identity,b={};try{identity=await appwriteIdentity(req);if(req.method==='POST')b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const id=String(req.method==='GET'?url.searchParams.get('postId')||'':b.postId||'');if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(id))return json(res,400,{error:'Identifiant de publication invalide.'});
   try {
     await awRequest('GET',awDocRoute(process.env.APPWRITE_POSTS_COLLECTION_ID,id));
     const qPost=encodeURIComponent(JSON.stringify({method:'equal',attribute:'postId',values:[id]}));
     const qUser=encodeURIComponent(JSON.stringify({method:'equal',attribute:'userId',values:[identity.$id]}));
     const lim=encodeURIComponent(JSON.stringify({method:'limit',values:[100]}));
     const found=await awRequest('GET',awDocRoute(likesCollection)+`?queries[]=${qPost}&queries[]=${qUser}&queries[]=${lim}`);
     const existing=(found.documents||[])[0];
     if(req.method==='GET')return json(res,200,{postId:id,liked:Boolean(existing),likes:(found.documents||[]).length});
     let liked;
     if(existing){await awRequest('DELETE',awDocRoute(likesCollection,existing.$id));liked=false;}
     else {await awRequest('POST',awDocRoute(likesCollection),{documentId:crypto.randomUUID(),data:{postId:id,userId:identity.$id},permissions:[`read("any")`,`delete("user:${identity.$id}")`]});liked=true;}
     const all=await awRequest('GET',awDocRoute(likesCollection)+`?queries[]=${qPost}&queries[]=${lim}`);
     const likes=(all.documents||[]).length;
     await awRequest('PUT',awDocRoute(process.env.APPWRITE_POSTS_COLLECTION_ID,id),{data:{likes}});
     return json(res,200,{ok:true,liked,likes,postId:id,userId:identity.$id});
   }catch(e){return json(res,e.status||502,{error:'Impossible de modifier le like.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 // Comments: persisted in Appwrite and bound to the authenticated author.
 if (url.pathname==='/api/social/comments' && req.method==='GET') {
   const collection=process.env.APPWRITE_COMMENTS_COLLECTION_ID;
   const postId=String(url.searchParams.get('postId')||'');
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_COMMENTS_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(postId))return json(res,400,{error:'postId invalide.'});
   try { const q=encodeURIComponent(JSON.stringify({method:'equal',attribute:'postId',values:[postId]})); const lim=encodeURIComponent(JSON.stringify({method:'limit',values:[100]})); const data=await awRequest('GET',awDocRoute(collection)+`?queries[]=${q}&queries[]=${lim}`); return json(res,200,{comments:(data.documents||[]).map(d=>({id:d.$id,postId:d.postId,userId:d.userId,name:d.name,text:d.text,createdAt:d.$createdAt}))}); }
   catch(e){return json(res,e.status||502,{error:'Impossible de charger les commentaires.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 if(url.pathname==='/api/social/comments' && req.method==='POST') {
   const collection=process.env.APPWRITE_COMMENTS_COLLECTION_ID;
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_COMMENTS_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   let user,b;try{user=await appwriteIdentity(req);b=await readJson(req,12000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const postId=String(b.postId||''),text=String(b.text||'').trim();
   if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(postId)||!text||text.length>2000)return json(res,400,{error:'Publication ou texte de commentaire invalide.'});
   try { const doc=await awRequest('POST',awDocRoute(collection),{documentId:crypto.randomUUID(),data:{postId,userId:user.$id,name:String(user.name||user.email||'Utilisateur').slice(0,100),text},permissions:[`read("any")`,`update("user:${user.$id}")`,`delete("user:${user.$id}")`]}); return json(res,201,{comment:{id:doc.$id,postId,userId:user.$id,name:doc.name,text:doc.text,createdAt:doc.$createdAt}}); }
   catch(e){return json(res,e.status||502,{error:'Impossible d’enregistrer le commentaire.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 // Unread-message count for the authenticated user. Appwrite's list limit is capped to keep this endpoint inexpensive.
 if(url.pathname==='/api/social/messages/unread-count' && req.method==='GET') {
   const collection=process.env.APPWRITE_MESSAGES_COLLECTION_ID;
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_MESSAGES_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   let user;try{user=await appwriteIdentity(req)}catch(e){return json(res,e.status||401,{error:e.message})}
   if(!hasPartnerAccess(user))return partnerOnly(res);
   try {
     const q1=encodeURIComponent(JSON.stringify({method:'equal',attribute:'recipientId',values:[user.$id]}));
     const q2=encodeURIComponent(JSON.stringify({method:'equal',attribute:'read',values:[false]}));
     const q3=encodeURIComponent(JSON.stringify({method:'limit',values:[100]}));
     const result=await awRequest('GET',awDocRoute(collection)+`?queries[]=${q1}&queries[]=${q2}&queries[]=${q3}`);
     const unread=(result.documents||[]).length;
     return json(res,200,{unreadCount:unread,possiblyTruncated:unread===100});
   } catch(e) { return json(res,e.status||502,{error:'Impossible de compter les messages non lus.',detail:process.env.APP_ENV==='development'?e.message:undefined}); }
 }
 // Call invitation signaling. Configure a dedicated Appwrite collection with callerId, recipientId,
 // roomName, callType, status, expiresAt attributes. This is signaling only; push/ringing is separate.
 if(url.pathname==='/api/social/calls' && ['POST','GET'].includes(req.method)) {
   const collection=process.env.APPWRITE_CALLS_COLLECTION_ID;
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_CALLS_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   let user,b={};try{user=await appwriteIdentity(req);if(req.method==='POST')b=await readJson(req,5000)}catch(e){return json(res,e.status||401,{error:e.message})}
   if(!hasPartnerAccess(user))return partnerOnly(res);
   try {
     if(req.method==='POST') {
       const recipientId=String(b.recipientId||''),callType=String(b.callType||'audio');
       if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(recipientId)||recipientId===user.$id||!['audio','video'].includes(callType))return json(res,400,{error:'Destinataire ou type d’appel invalide.'});
       const callId=crypto.randomUUID(),roomName='fv-'+callId.replaceAll('-','').slice(0,24),expiresAt=new Date(Date.now()+90*1000).toISOString();
       const doc=await awRequest('POST',awDocRoute(collection),{documentId:callId,data:{callerId:user.$id,recipientId,roomName,callType,status:'ringing',expiresAt},permissions:[`read("user:${user.$id}")`,`read("user:${recipientId}")`,`update("user:${user.$id}")`,`update("user:${recipientId}")`]});
       // Push is triggered only by this authenticated call-creation flow. The recipient is
       // taken from the persisted invitation, never from a generic client notification request.
       let pushNotification={sent:false,reason:'OneSignal non configuré'};
       if(process.env.PUBLIC_ONESIGNAL_APP_ID&&process.env.ONESIGNAL_REST_API_KEY) {
         try {
           const push=await fetch('https://api.onesignal.com/notifications',{method:'POST',headers:{Authorization:`Key ${process.env.ONESIGNAL_REST_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({app_id:process.env.PUBLIC_ONESIGNAL_APP_ID,include_aliases:{external_id:[doc.recipientId]},target_channel:'push',headings:{en:'Incoming FootVibes call',fr:'Appel entrant FootVibes'},contents:{en:`${String(user.name||'Un utilisateur').slice(0,70)} is calling you (${callType}).`,fr:`${String(user.name||'Un utilisateur').slice(0,70)} vous appelle (${callType==='video'?'vidéo':'audio'}).`},data:{type:'incoming_call',callId:doc.$id,callerId:user.$id,callType}}),signal:AbortSignal.timeout(8000)});
           const pushData=await push.json().catch(()=>({}));
           pushNotification=push.ok?{sent:true,id:pushData.id||null}:{sent:false,reason:'OneSignal a refusé la notification'};
         } catch { pushNotification={sent:false,reason:'Service push temporairement indisponible'}; }
       }
       return json(res,201,{call:{id:doc.$id,callerId:user.$id,recipientId:doc.recipientId,roomName,callType,status:'ringing',expiresAt},signalingOnly:true,pushNotification});
     }
     const recipientQ=encodeURIComponent(JSON.stringify({method:'equal',attribute:'recipientId',values:[user.$id]}));
     const statusQ=encodeURIComponent(JSON.stringify({method:'equal',attribute:'status',values:['ringing']}));
     const limitQ=encodeURIComponent(JSON.stringify({method:'limit',values:[20]}));
     const result=await awRequest('GET',awDocRoute(collection)+`?queries[]=${recipientQ}&queries[]=${statusQ}&queries[]=${limitQ}`);
     const now=Date.now(),calls=(result.documents||[]).filter(d=>Date.parse(d.expiresAt)>now).map(d=>({id:d.$id,callerId:d.callerId,recipientId:d.recipientId,roomName:d.roomName,callType:d.callType,status:d.status,expiresAt:d.expiresAt}));
     return json(res,200,{calls,signalingOnly:true});
   } catch(e) { return json(res,e.status||502,{error:'Impossible de gérer les invitations d’appel.',detail:process.env.APP_ENV==='development'?e.message:undefined}); }
 }
 if(url.pathname.startsWith('/api/social/calls/') && ['GET','PATCH'].includes(req.method)) {
   const collection=process.env.APPWRITE_CALLS_COLLECTION_ID;
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_CALLS_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   let user,b={};try{user=await appwriteIdentity(req);if(req.method==='PATCH')b=await readJson(req,3000)}catch(e){return json(res,e.status||401,{error:e.message})}
   if(!hasPartnerAccess(user))return partnerOnly(res);
   const callId=decodeURIComponent(url.pathname.split('/').pop()),status=String(b.status||'');
   if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$/.test(callId))return json(res,400,{error:'Identifiant d’appel invalide.'});
   if(req.method==='PATCH'&&!['accepted','rejected','ended','missed'].includes(status))return json(res,400,{error:'Statut d’appel invalide.'});
   try { const doc=await awRequest('GET',awDocRoute(collection,callId));if(doc.callerId!==user.$id&&doc.recipientId!==user.$id)return json(res,403,{error:'Cet appel ne vous appartient pas.'});if(req.method==='GET')return json(res,200,{call:{id:doc.$id,callerId:doc.callerId,recipientId:doc.recipientId,roomName:doc.roomName,callType:doc.callType,status:Date.parse(doc.expiresAt)<Date.now()&&doc.status==='ringing'?'missed':doc.status,expiresAt:doc.expiresAt}});
     if(['accepted','rejected'].includes(status)&&doc.recipientId!==user.$id)return json(res,403,{error:'Seul le destinataire peut accepter ou refuser cet appel.'});
     if(status==='missed')return json(res,400,{error:'Le statut manqué est calculé automatiquement.'});
     if(doc.status!=='ringing'&&!(status==='ended'&&doc.status==='accepted'))return json(res,409,{error:'Cet appel n’est plus dans un état permettant cette action.'});
     if(status==='accepted'&&Date.parse(doc.expiresAt)<=Date.now())return json(res,409,{error:'Cette invitation a expiré.'});
     const updated=await awRequest('PATCH',awDocRoute(collection,callId),{data:{status}});return json(res,200,{ok:true,call:{id:updated.$id,status:updated.status}}); }
   catch(e){return json(res,e.status||502,{error:'Impossible de mettre à jour l’appel.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 // Messages: real persisted messages; a polling client can refresh the conversation.
 if(url.pathname==='/api/social/messages/read' && req.method==='POST') {
   const collection=process.env.APPWRITE_MESSAGES_COLLECTION_ID;
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_MESSAGES_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   let user,b;try{user=await appwriteIdentity(req);b=await readJson(req,5000)}catch(e){return json(res,e.status||400,{error:e.message})}
   if(!hasPartnerAccess(user))return partnerOnly(res);
   const other=String(b.with||'');
   if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(other)||other===user.$id)return json(res,400,{error:'Identifiant de conversation invalide.'});
   try {
     const q1=encodeURIComponent(JSON.stringify({method:'equal',attribute:'senderId',values:[other]}));
     const q2=encodeURIComponent(JSON.stringify({method:'equal',attribute:'recipientId',values:[user.$id]}));
     const q3=encodeURIComponent(JSON.stringify({method:'equal',attribute:'read',values:[false]}));
     const q4=encodeURIComponent(JSON.stringify({method:'limit',values:[100]}));
     const result=await awRequest('GET',awDocRoute(collection)+`?queries[]=${q1}&queries[]=${q2}&queries[]=${q3}&queries[]=${q4}`);
     let updated=0;
     for(const doc of (result.documents||[])) {
       try { await awRequest('PATCH',awDocRoute(collection,doc.$id),{data:{read:true}}); updated++; }
       catch(e) { if(e.status!==401&&e.status!==403&&e.status!==404) throw e; }
     }
     return json(res,200,{ok:true,updated});
   } catch(e) { return json(res,e.status||502,{error:'Impossible de mettre à jour les accusés de lecture.',detail:process.env.APP_ENV==='development'?e.message:undefined}); }
 }
 if(url.pathname==='/api/social/messages' && (req.method==='GET'||req.method==='POST')) {
   const collection=process.env.APPWRITE_MESSAGES_COLLECTION_ID;
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_MESSAGES_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   let user,b={};try{user=await appwriteIdentity(req);if(req.method==='POST')b=await readJson(req,20000)}catch(e){return json(res,e.status||400,{error:e.message})}
   if(!hasPartnerAccess(user))return partnerOnly(res);
   if(req.method==='POST') {
     const recipientId=String(b.recipientId||''),text=String(b.text||'').trim(),mediaUrl=String(b.mediaUrl||'');
     if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(recipientId)||recipientId===user.$id||(!text&&!mediaUrl)||text.length>4000||mediaUrl.length>2000)return json(res,400,{error:'Destinataire ou contenu du message invalide.'});
     try { const doc=await awRequest('POST',awDocRoute(collection),{documentId:crypto.randomUUID(),data:{senderId:user.$id,recipientId,text,mediaUrl,read:false},permissions:[`read("user:${user.$id}")`,`read("user:${recipientId}")`,`update("user:${recipientId}")`,`delete("user:${user.$id}")`]}); return json(res,201,{message:{id:doc.$id,senderId:user.$id,recipientId,text,mediaUrl,createdAt:doc.$createdAt,read:false}}); }
     catch(e){return json(res,e.status||502,{error:'Impossible d’enregistrer le message.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
   }
   const other=String(url.searchParams.get('with')||'');if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(other))return json(res,400,{error:'Le paramètre with (identifiant utilisateur) est obligatoire.'});
   try { const q1=encodeURIComponent(JSON.stringify({method:'equal',attribute:'senderId',values:[user.$id]})); const q2=encodeURIComponent(JSON.stringify({method:'equal',attribute:'recipientId',values:[other]})); const q3=encodeURIComponent(JSON.stringify({method:'limit',values:[100]})); const data=await awRequest('GET',awDocRoute(collection)+`?queries[]=${q1}&queries[]=${q2}&queries[]=${q3}`); const q4=encodeURIComponent(JSON.stringify({method:'equal',attribute:'senderId',values:[other]})); const q5=encodeURIComponent(JSON.stringify({method:'equal',attribute:'recipientId',values:[user.$id]})); const back=await awRequest('GET',awDocRoute(collection)+`?queries[]=${q4}&queries[]=${q5}&queries[]=${q3}`); const messages=[...(data.documents||[]),...(back.documents||[])].sort((a,b)=>a.$createdAt.localeCompare(b.$createdAt)).map(d=>({id:d.$id,senderId:d.senderId,recipientId:d.recipientId,text:d.text||'',mediaUrl:d.mediaUrl||'',createdAt:d.$createdAt,read:Boolean(d.read)}));return json(res,200,{messages}); }
   catch(e){return json(res,e.status||502,{error:'Impossible de charger la conversation.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 // Persistent favorites. Collection attributes: userId, itemId, itemType, itemName, itemUrl.
 if(url.pathname==='/api/social/favorites' && ['GET','POST','DELETE'].includes(req.method)) {
   const collection=process.env.APPWRITE_FAVORITES_COLLECTION_ID;
   if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_FAVORITES_COLLECTION_ID et APPWRITE_DATABASE_ID côté serveur.'});
   let user,b={};try{user=await appwriteIdentity(req);if(req.method!=='GET')b=await readJson(req,12000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const itemId=String(req.method==='GET'?url.searchParams.get('itemId')||'':b.itemId||'').slice(0,100);
   if(req.method!=='GET'&&(!itemId||!/^[A-Za-z0-9._:-]{1,100}$/.test(itemId)))return json(res,400,{error:'Identifiant du contenu invalide.'});
   try {
     const qUser=encodeURIComponent(JSON.stringify({method:'equal',attribute:'userId',values:[user.$id]}));
     const queries=[`queries[]=${qUser}`,`queries[]=${encodeURIComponent(JSON.stringify({method:'limit',values:[100]}))}`];
     if(itemId)queries.push(`queries[]=${encodeURIComponent(JSON.stringify({method:'equal',attribute:'itemId',values:[itemId]}))}`);
     const found=await awRequest('GET',awDocRoute(collection)+'?'+queries.join('&'));
     if(req.method==='GET')return json(res,200,{favorites:(found.documents||[]).map(d=>({id:d.$id,itemId:d.itemId,itemType:d.itemType||'post',itemName:d.itemName||'',itemUrl:d.itemUrl||'',createdAt:d.$createdAt}))});
     const existing=(found.documents||[]).find(d=>d.itemId===itemId);
     if(req.method==='DELETE'){if(existing)await awRequest('DELETE',awDocRoute(collection,existing.$id));return json(res,200,{saved:false,itemId});}
     if(existing){await awRequest('DELETE',awDocRoute(collection,existing.$id));return json(res,200,{saved:false,itemId});}
     const itemType=String(b.itemType||'post').slice(0,30),itemName=String(b.itemName||'').slice(0,160),itemUrl=String(b.itemUrl||'').slice(0,1500);
     const doc=await awRequest('POST',awDocRoute(collection),{documentId:crypto.randomUUID(),data:{userId:user.$id,itemId,itemType,itemName,itemUrl},permissions:[`read("user:${user.$id}")`,`delete("user:${user.$id}")`]});
     return json(res,201,{saved:true,favorite:{id:doc.$id,itemId,itemType,itemName,itemUrl}});
   }catch(e){return json(res,e.status||502,{error:'Impossible de modifier les favoris.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 // Following relationships are persisted. Set APPWRITE_FOLLOWS_COLLECTION_ID and create attributes followerId/followedId.
 if(url.pathname==='/api/social/follow' && req.method==='POST') {
   const collection=process.env.APPWRITE_FOLLOWS_COLLECTION_ID;if(!collection||!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_FOLLOWS_COLLECTION_ID et APPWRITE_DATABASE_ID.'});
   let user,b;try{user=await appwriteIdentity(req);b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const followedId=String(b.userId||'');if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,35}$/.test(followedId)||followedId===user.$id)return json(res,400,{error:'Utilisateur à suivre invalide.'});
   try { const q=encodeURIComponent(JSON.stringify({method:'equal',attribute:'followerId',values:[user.$id]}));const q2=encodeURIComponent(JSON.stringify({method:'equal',attribute:'followedId',values:[followedId]}));const found=await awRequest('GET',awDocRoute(collection)+`?queries[]=${q}&queries[]=${q2}&queries[]=${encodeURIComponent(JSON.stringify({method:'limit',values:[1]}))}`);if(found.documents?.length){await awRequest('DELETE',awDocRoute(collection,found.documents[0].$id));return json(res,200,{following:false,userId:followedId});}const doc=await awRequest('POST',awDocRoute(collection),{documentId:crypto.randomUUID(),data:{followerId:user.$id,followedId},permissions:[`read("user:${user.$id}")`,`read("user:${followedId}")`,`delete("user:${user.$id}")`]});return json(res,201,{following:true,id:doc.$id,userId:followedId}); }
   catch(e){return json(res,e.status||502,{error:'Impossible de modifier l’abonnement.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 // Server-side goal alert subscriptions. Pushes can be delivered while the user is away,
 // as long as this Node service stays running and OneSignal is configured.
 function readGoalAlerts(){try{return JSON.parse(fs.readFileSync(GOAL_ALERTS_FILE,'utf8'))}catch{return []}}
 function saveGoalAlerts(rows){fs.mkdirSync(DATA_DIR,{recursive:true});fs.writeFileSync(GOAL_ALERTS_FILE,JSON.stringify(rows,null,2),{mode:0o600})}
 async function listGoalAlerts(){
   const collection=process.env.APPWRITE_GOAL_ALERTS_COLLECTION_ID;
   if(!collection)return readGoalAlerts();
   if(!process.env.APPWRITE_DATABASE_ID)throw Object.assign(new Error('Configurez APPWRITE_DATABASE_ID.'),{status:503});
   const found=await awRequest('GET',awDocRoute(collection)+`?queries[]=${encodeURIComponent(JSON.stringify({method:'limit',values:[500]}))}`);
   return (found.documents||[]).map(d=>({docId:d.$id,userId:d.userId,fixtureId:Number(d.fixtureId),createdAt:d.createdAt||d.$createdAt}));
 }
 async function listUserGoalAlerts(userId){return (await listGoalAlerts()).filter(x=>x.userId===userId)}
 function readGoalState(){try{return JSON.parse(fs.readFileSync(GOAL_ALERTS_STATE_FILE,'utf8'))}catch{return {scores:{},sent:{}}}}
 function saveGoalState(state){fs.mkdirSync(DATA_DIR,{recursive:true});fs.writeFileSync(GOAL_ALERTS_STATE_FILE,JSON.stringify(state,null,2),{mode:0o600})}
 // Shared state prevents each application server from independently detecting and sending the same goal.
 async function loadGoalState(){
   const collection=process.env.APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID;
   if(!collection)return readGoalState();
   if(!process.env.APPWRITE_DATABASE_ID)throw Object.assign(new Error('Configurez APPWRITE_DATABASE_ID.'),{status:503});
   try{const doc=await awRequest('GET',awDocRoute(collection,'goal-alert-state'));return {scores:doc.scores||{},sent:doc.sent||{}};}
   catch(e){if(e.status!==404)throw e;return {scores:{},sent:{}};}
 }
 async function persistGoalState(state){
   const collection=process.env.APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID;
   if(!collection){saveGoalState(state);return 'local-file';}
   if(!process.env.APPWRITE_DATABASE_ID)throw Object.assign(new Error('Configurez APPWRITE_DATABASE_ID.'),{status:503});
   const data={scores:state.scores||{},sent:state.sent||{},updatedAt:new Date().toISOString()};
   try{await awRequest('PATCH',awDocRoute(collection,'goal-alert-state'),{data});}
   catch(e){if(e.status!==404)throw e;await awRequest('POST',awDocRoute(collection),{documentId:'goal-alert-state',data});}
   return 'appwrite';
 }
 if(req.method==='POST' && url.pathname==='/api/football/alerts/subscribe') {
   let user,b;try{user=await appwriteIdentity(req);b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const fixtureId=Number(b.fixtureId);if(!Number.isSafeInteger(fixtureId)||fixtureId<1)return json(res,400,{error:'Identifiant de match invalide.'});
   try {
     const collection=process.env.APPWRITE_GOAL_ALERTS_COLLECTION_ID;
     if(collection){if(!process.env.APPWRITE_DATABASE_ID)return json(res,503,{error:'Configurez APPWRITE_DATABASE_ID.'});const rows=await listUserGoalAlerts(user.$id);if(rows.some(x=>x.fixtureId===fixtureId))return json(res,200,{ok:true,fixtureId,storage:'appwrite',message:'Alerte déjà activée.'});const docId=crypto.randomUUID();await awRequest('POST',awDocRoute(collection),{documentId:docId,data:{userId:user.$id,fixtureId,createdAt:new Date().toISOString()},permissions:[`read("user:${user.$id}")`,`delete("user:${user.$id}")`]});return json(res,200,{ok:true,fixtureId,storage:'appwrite',message:'Alerte enregistrée dans Appwrite.'});}
     const rows=readGoalAlerts().filter(x=>!(x.userId===user.$id&&x.fixtureId===fixtureId));rows.push({userId:user.$id,fixtureId,createdAt:new Date().toISOString()});saveGoalAlerts(rows);return json(res,200,{ok:true,fixtureId,storage:'local-file',message:'Configurez APPWRITE_GOAL_ALERTS_COLLECTION_ID pour un stockage partagé.'});
   }catch(e){return json(res,e.status||502,{error:'Impossible d’enregistrer l’alerte.',detail:process.env.APP_ENV==='development'?e.message:undefined})}
 }
 if(req.method==='POST' && url.pathname==='/api/football/alerts/unsubscribe') {
   let user,b;try{user=await appwriteIdentity(req);b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const fixtureId=Number(b.fixtureId);if(!Number.isSafeInteger(fixtureId)||fixtureId<1)return json(res,400,{error:'Identifiant de match invalide.'});
   try{const collection=process.env.APPWRITE_GOAL_ALERTS_COLLECTION_ID;if(collection){const rows=await listUserGoalAlerts(user.$id);for(const row of rows.filter(x=>x.fixtureId===fixtureId&&x.docId))await awRequest('DELETE',awDocRoute(collection,row.docId));return json(res,200,{ok:true,fixtureId,subscribed:false,storage:'appwrite'});}const rows=readGoalAlerts().filter(x=>!(x.userId===user.$id&&x.fixtureId===fixtureId));saveGoalAlerts(rows);return json(res,200,{ok:true,fixtureId,subscribed:false,storage:'local-file'});}catch(e){return json(res,e.status||502,{error:'Impossible de désactiver l’alerte.',detail:process.env.APP_ENV==='development'?e.message:undefined})}
 }
 if(req.method==='GET' && url.pathname==='/api/football/alerts/subscriptions') {
   let user;try{user=await appwriteIdentity(req)}catch(e){return json(res,e.status||400,{error:e.message})}try{return json(res,200,{fixtureIds:(await listUserGoalAlerts(user.$id)).map(x=>x.fixtureId)});}catch(e){return json(res,e.status||502,{error:'Impossible de charger les alertes.',detail:process.env.APP_ENV==='development'?e.message:undefined})}
 }
 // OneSignal push notification: server key never leaves this endpoint; caller must be signed in.
 if(url.pathname==='/api/notifications/send' && req.method==='POST') {
   if(!process.env.PUBLIC_ONESIGNAL_APP_ID||!process.env.ONESIGNAL_REST_API_KEY)return json(res,503,{error:'OneSignal n’est pas configuré côté serveur.'});
   let user,b;try{user=await appwriteIdentity(req);b=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const title=String(b.title||'FootVibes').trim().slice(0,80),message=String(b.message||'').trim().slice(0,240),target=String(b.targetUserId||'');
   if(!message||!target||target!==user.$id)return json(res,400,{error:'Le compte destinataire doit correspondre à l’utilisateur connecté. Les notifications à autrui nécessitent une autorisation serveur dédiée.'});
   try {const r=await fetch('https://api.onesignal.com/notifications',{method:'POST',headers:{Authorization:`Key ${process.env.ONESIGNAL_REST_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({app_id:process.env.PUBLIC_ONESIGNAL_APP_ID,include_aliases:{external_id:[target]},target_channel:'push',headings:{en:title,fr:title},contents:{en:message,fr:message}}),signal:AbortSignal.timeout(12000)});const data=await r.json().catch(()=>({}));if(!r.ok)return json(res,r.status,{error:'OneSignal a refusé la notification.',detail:process.env.APP_ENV==='development'?data:undefined});return json(res,200,{ok:true,id:data.id||null,recipients:data.recipients||0});}
   catch(e){return json(res,502,{error:'Impossible de joindre OneSignal.',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }

 if(req.method==='GET' && url.pathname==='/api/football/status') return json(res,200,{configured:Boolean(process.env.FOOTBALL_API_KEY),message:process.env.FOOTBALL_API_KEY?'API key présente côté serveur.':'FOOTBALL_API_KEY manque dans .env.'});
 if(req.method==='GET' && url.pathname==='/api/integrations/status') {
   const missing=[];
   if(!process.env.PUBLIC_APPWRITE_ENDPOINT||!process.env.PUBLIC_APPWRITE_PROJECT_ID)missing.push('Appwrite public endpoint/project');
   if(!process.env.APPWRITE_API_KEY)missing.push('APPWRITE_API_KEY');
   if(!process.env.FOOTBALL_API_KEY)missing.push('FOOTBALL_API_KEY');
   if(!process.env.LIVEKIT_API_KEY||!process.env.LIVEKIT_API_SECRET||!process.env.PUBLIC_LIVEKIT_URL)missing.push('LiveKit credentials/URL');
   if(!process.env.ONESIGNAL_REST_API_KEY||!process.env.PUBLIC_ONESIGNAL_APP_ID)missing.push('OneSignal credentials');
   if(!process.env.YELENPAY_PREMIUM_URL||!process.env.YELENPAY_PARTNER_URL)missing.push('YelenPay checkout URLs');
   return json(res,200,{app:'FootVibes',environment:process.env.APP_ENV||'development',integrations:{appwrite:Boolean(process.env.PUBLIC_APPWRITE_ENDPOINT&&process.env.PUBLIC_APPWRITE_PROJECT_ID&&process.env.APPWRITE_API_KEY),football:Boolean(process.env.FOOTBALL_API_KEY),livekit:Boolean(process.env.PUBLIC_LIVEKIT_URL&&process.env.LIVEKIT_API_KEY&&process.env.LIVEKIT_API_SECRET),onesignal:Boolean(process.env.PUBLIC_ONESIGNAL_APP_ID&&process.env.ONESIGNAL_REST_API_KEY),yelenpayCheckout:Boolean(process.env.YELENPAY_PREMIUM_URL&&process.env.YELENPAY_PARTNER_URL),yelenpayVerifiedWebhook:false},missing});
 }
 if(req.method==='GET' && url.pathname==='/api/football/fixtures') {
   if(!process.env.FOOTBALL_API_KEY) return json(res,503,{error:'API-Football non configurée',hint:'Renseignez FOOTBALL_API_KEY dans .env côté serveur.'});
   const params=new URLSearchParams(); for(const k of ['date','league','season','team','live','timezone','next','last']) if(url.searchParams.has(k)) params.set(k,url.searchParams.get(k));
   try { const upstream=await fetch(`https://v3.football.api-sports.io/fixtures?${params}`,{headers:{'x-apisports-key':process.env.FOOTBALL_API_KEY},signal:AbortSignal.timeout(12000)}); const body=await upstream.text(); res.writeHead(upstream.status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=30','X-Content-Type-Options':'nosniff'}); return res.end(body); }
   catch(e) { return json(res,502,{error:'Impossible de joindre API-Football',detail:process.env.APP_ENV==='development'?e.message:undefined}); }
 }
 if(req.method==='GET' && url.pathname.startsWith('/api/football/')) {
   if(!process.env.FOOTBALL_API_KEY) return json(res,503,{error:'API-Football non configurée',hint:'Renseignez FOOTBALL_API_KEY dans les variables privées du serveur.'});
   const routes={standings:'/standings',teams:'/teams',leagues:'/leagues',players:'/players',fixture:'/fixtures',events:'/fixtures/events',statistics:'/fixtures/statistics',lineups:'/fixtures/lineups'};
   const route=url.pathname.slice('/api/football/'.length);
   if(!Object.hasOwn(routes,route)) return json(res,404,{error:'Route football inconnue'});
   const params=new URLSearchParams();
   const permitted=['date','league','season','team','live','timezone','next','last','id','fixture','type','player','search','country','page','venue'];
   for(const k of permitted) if(url.searchParams.has(k)) params.set(k,url.searchParams.get(k));
   if(['events','statistics','lineups'].includes(route)&&!params.has('fixture')) return json(res,400,{error:'Le paramètre fixture est obligatoire.'});
   try { const upstream=await fetch(`https://v3.football.api-sports.io${routes[route]}?${params}`,{headers:{'x-apisports-key':process.env.FOOTBALL_API_KEY},signal:AbortSignal.timeout(12000)}); const body=await upstream.text();res.writeHead(upstream.status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=30','X-Content-Type-Options':'nosniff'});return res.end(body); }
   catch(e){return json(res,502,{error:'Impossible de joindre API-Football',detail:process.env.APP_ENV==='development'?e.message:undefined});}
 }
 if(req.method==='POST' && url.pathname==='/api/livekit/token') {
   if(!process.env.PUBLIC_APPWRITE_ENDPOINT||!process.env.PUBLIC_APPWRITE_PROJECT_ID||!process.env.LIVEKIT_API_KEY||!process.env.LIVEKIT_API_SECRET||!process.env.PUBLIC_LIVEKIT_URL) return json(res,503,{error:'LiveKit ou Appwrite non configuré côté serveur.'});
   const auth=String(req.headers.authorization||''); const jwt=auth.startsWith('Bearer ')?auth.slice(7):'';
   if(!jwt||jwt.length>8192) return json(res,401,{error:'Connexion Appwrite requise.'});
   let user;
   try { const verify=await fetch(`${process.env.PUBLIC_APPWRITE_ENDPOINT.replace(/\/$/,'')}/account`,{headers:{'X-Appwrite-Project':process.env.PUBLIC_APPWRITE_PROJECT_ID,'X-Appwrite-JWT':jwt},signal:AbortSignal.timeout(8000)}); if(!verify.ok)return json(res,401,{error:'Session Appwrite invalide ou expirée.'});user=await verify.json(); }
   catch { return json(res,502,{error:'Impossible de vérifier la session Appwrite.'}); }
   // LiveKit tokens grant media publishing; enforce the same server-side Partner policy as call signaling.
   if(!hasPartnerAccess(user))return partnerOnly(res);
   let body;try{body=await readJson(req,10000)}catch(e){return json(res,e.status||400,{error:e.message})}
   const room=String(body.room||'').trim(); if(!/^[A-Za-z0-9_-]{3,80}$/.test(room))return json(res,400,{error:'Nom de salon invalide.'});
   const now=Math.floor(Date.now()/1000), b64=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
   const header=b64({alg:'HS256',typ:'JWT'}); const payload=b64({iss:process.env.LIVEKIT_API_KEY,sub:String(user.$id),name:String(user.name||user.email||'FootVibes user').slice(0,100),nbf:now-5,iat:now,exp:now+3600,video:{roomJoin:true,room,canPublish:true,canSubscribe:true,canPublishData:true}});
   const unsigned=header+'.'+payload; const signature=crypto.createHmac('sha256',process.env.LIVEKIT_API_SECRET).update(unsigned).digest('base64url');
   return json(res,200,{url:process.env.PUBLIC_LIVEKIT_URL,token:unsigned+'.'+signature,room,expiresAt:new Date((now+3600)*1000).toISOString()});
 }
 if(req.method==='GET' && url.pathname==='/api/payments/links') { const c=publicConfig().payments; return json(res,200,{premium:{url:c.premiumUrl,priceXof:c.premiumPriceXof,period:c.premiumPeriod},partner:{url:c.partnerUrl,priceXof:c.partnerPriceXof,period:c.partnerPeriod},note:'Les liens ouvrent le prestataire. Aucun accès payant ne doit être activé sans confirmation serveur vérifiée.'}); }
 if(req.method==='POST' && url.pathname==='/api/payments/webhook') return json(res,503,{error:'Webhook non activé',message:'La spécification officielle et le mécanisme de signature YelenPay doivent être fournis avant toute activation automatique. Ne validez jamais un paiement sur la seule base d’une redirection navigateur.'});
 if(req.method!=='GET' && req.method!=='HEAD') return json(res,405,{error:'Méthode non autorisée'});
 let rel=decodeURIComponent(url.pathname); if(rel==='/' || rel==='') rel='/index.html'; if(rel==='/.env'||rel==='/ .env.example'||rel==='/package.json'||rel==='/server/server.js'||rel.startsWith('/data/')||rel.startsWith('/assets/reference/')||rel.startsWith('/docs/')||rel.startsWith('/tests/')||['/README.md','/README_FINALISATION.md','/PROJECT_STATUS.md','/DEPLOYMENT.md','/Dockerfile','/docker-compose.yml','/.env.example'].includes(rel)) return json(res,403,{error:'Accès interdit'}); const file=path.resolve(ROOT,'.'+rel);
 if(!file.startsWith(ROOT+path.sep) && file!==ROOT) return json(res,403,{error:'Accès interdit'});
 try { const stat=fs.statSync(file); if(!stat.isFile()) throw new Error('not file'); const ext=path.extname(file).toLowerCase(); res.writeHead(200,{'Content-Type':MIME[ext]||'application/octet-stream','Content-Length':stat.size,'Cache-Control':ext.match(/\.(png|jpe?g|mp4)$/)?'public, max-age=86400':'no-cache'}); if(req.method==='HEAD') return res.end(); fs.createReadStream(file).pipe(res); }
 catch { json(res,404,{error:'Introuvable'}); }
}
async function pollServerGoalAlertsUnlocked(){
 if(!process.env.FOOTBALL_API_KEY||!process.env.PUBLIC_ONESIGNAL_APP_ID||!process.env.ONESIGNAL_REST_API_KEY)return;
 const subs=await listGoalAlerts();if(!subs.length)return;
 try{
  const r=await fetch('https://v3.football.api-sports.io/fixtures?live=all',{headers:{'x-apisports-key':process.env.FOOTBALL_API_KEY},signal:AbortSignal.timeout(12000)});if(!r.ok)return;const payload=await r.json();if(!Array.isArray(payload.response))return;
  const state=await loadGoalState();let changed=false;
  for(const f of payload.response){const id=Number(f.fixture?.id);if(!id)continue;const home=Number(f.goals?.home||0),away=Number(f.goals?.away||0),old=state.scores[String(id)];state.scores[String(id)]={home,away,homeName:String(f.teams?.home?.name||'Domicile'),awayName:String(f.teams?.away?.name||'Extérieur'),updatedAt:Date.now()};
   if(old&&(home>old.home||away>old.away)){
    const scoreKey=`${id}:${home}-${away}`;if(state.sent[scoreKey])continue;
    const targets=[...new Set(subs.filter(x=>x.fixtureId===id).map(x=>x.userId))];if(!targets.length)continue;
    const title='⚽ But en direct — FootVibes',message=`${state.scores[String(id)].homeName} ${home} – ${away} ${state.scores[String(id)].awayName}`;
    try{const sent=await fetch('https://api.onesignal.com/notifications',{method:'POST',headers:{Authorization:`Key ${process.env.ONESIGNAL_REST_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({app_id:process.env.PUBLIC_ONESIGNAL_APP_ID,include_aliases:{external_id:targets},target_channel:'push',headings:{fr:title,en:'Live goal — FootVibes'},contents:{fr:message,en:message}}),signal:AbortSignal.timeout(12000)});if(sent.ok){state.sent[scoreKey]=Date.now();changed=true;}}
    catch{}
   }
  }
  // Keep the state file bounded and persist current scores between process restarts.
  const cutoff=Date.now()-7*24*60*60*1000;for(const [k,v] of Object.entries(state.sent))if(v<cutoff)delete state.sent[k];
  const active=new Set(payload.response.map(f=>String(f.fixture?.id)));for(const k of Object.keys(state.scores))if(!active.has(k)&&state.scores[k].updatedAt<cutoff)delete state.scores[k];
  await persistGoalState(state);
 }catch(err){if(process.env.APP_ENV==='development')console.error('Goal-alert poll failed:',err.message)}
}
// Best-effort distributed lease: prevents multiple Node instances from polling simultaneously.
// Uses the private Appwrite goal-alert state collection; local-file mode remains single-instance only.
async function acquireGoalAlertLease(){
 const collection=process.env.APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID;
 if(!collection||!process.env.APPWRITE_DATABASE_ID)return {acquired:true,local:true,ownerId:null};
 const ownerId=crypto.randomUUID(), now=Date.now(), leaseMs=150000;
 const route=awDocRoute(collection,'goal-alert-worker-lock');
 try{
  const existing=await awRequest('GET',route);
  if(Number(existing.expiresAt||0)>now)return {acquired:false};
  try{await awRequest('DELETE',route)}catch(e){if(e.status!==404)throw e;}
 }catch(e){if(e.status!==404)throw e;}
 try{
  await awRequest('POST',awDocRoute(collection),{documentId:'goal-alert-worker-lock',data:{ownerId,expiresAt:now+leaseMs,updatedAt:new Date().toISOString()}});
  return {acquired:true,local:false,ownerId};
 }catch(e){if(e.status===409)return {acquired:false};throw e;}
}
async function releaseGoalAlertLease(lease){
 if(!lease||lease.local||!lease.ownerId)return;
 const collection=process.env.APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID;
 if(!collection)return;
 const route=awDocRoute(collection,'goal-alert-worker-lock');
 try{const current=await awRequest('GET',route);if(current.ownerId===lease.ownerId)await awRequest('DELETE',route);}catch{}
}
async function pollServerGoalAlerts(){
 let lease;
 try{
  lease=await acquireGoalAlertLease();
  if(!lease.acquired)return;
  await pollServerGoalAlertsUnlocked();
 }catch(err){if(process.env.APP_ENV==='development')console.error('Goal-alert lease failed:',err.message)}
 finally{await releaseGoalAlertLease(lease);}
}
setInterval(()=>{pollServerGoalAlerts().catch(()=>{});},60000).unref();
http.createServer((req,res)=>handle(req,res).catch(err=>{console.error(err); if(!res.headersSent) json(res,500,{error:'Erreur interne'}); else res.end();})).listen(PORT,HOST,()=>console.log(`FootVibes prêt sur http://${HOST}:${PORT}`));
