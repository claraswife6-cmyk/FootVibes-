Aucune vidéo d'exemple n'est publiée ou affichée par défaut.
Ajoute ici uniquement les deux vidéos de bienvenue réellement sélectionnées par le propriétaire (15 secondes chacune), puis configure explicitement leur affichage avant déploiement.
