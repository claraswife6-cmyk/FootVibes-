# FootVibes v65 — Journal des actions administratives

## Nouveauté
- Endpoint `GET /api/admin/audit`, réservé à une session administrateur.
- Enregistre les décisions de certification et les changements d’état des dossiers de preuve de paiement.
- Conserve localement au maximum 500 entrées et affiche les 100 plus récentes dans la boîte administrative.
- Les valeurs affichées dans le journal sont échappées avant insertion dans l’interface.

## Limites et sécurité
- Le journal est stocké dans `data/admin-audit.json` sur le serveur; ce n’est pas un journal centralisé inviolable. Pour la production, utiliser un stockage durable, des sauvegardes et des permissions restreintes.
- Le statut d’une preuve de paiement ne confirme pas un paiement auprès de YelenPay et n’active pas automatiquement un abonnement.
- Les services externes doivent être configurés et testés séparément.

## Vérification
- `node --check server/server.js`
- `node --check app.js`
- `npm test`
