# FootVibes v46 — Signalisation des appels améliorée

Cette version corrige le flux d’appel sortant : l’appelant crée une invitation, attend la réponse du destinataire via un endpoint authentifié, et rejoint le salon LiveKit après acceptation. Le destinataire marque l’invitation comme acceptée avant de rejoindre le salon. Le statut d’une invitation peut être consulté avec `GET /api/social/calls/:id`, uniquement par l’appelant ou le destinataire.

## Configuration nécessaire

Configurer sur le serveur les variables Appwrite et LiveKit décrites dans `.env.example`, dont `APPWRITE_CALLS_COLLECTION_ID` et `APPWRITE_DATABASE_ID`. La collection Appwrite doit posséder les attributs utilisés par le serveur (`callerId`, `recipientId`, `roomName`, `callType`, `status`, `expiresAt`) et les permissions nécessaires. Les deux utilisateurs doivent être authentifiés et autorisés à accéder à cette collection.

## Vérification locale

```bash
npm run check
npm test
npm run release:audit
```

Ces commandes vérifient le code et la structure locale. Elles ne remplacent pas un test d’intégration avec deux comptes, deux appareils et une instance LiveKit réelle. Les notifications push et la sonnerie native en arrière-plan ne sont pas fournies par cette signalisation seule.
