# FootVibes v24 — Fil social relié

## Changements
- Le fil social affiche désormais un bouton « Enregistrer » sur chaque publication et utilise la route de favoris Appwrite déjà présente.
- Après l’enregistrement d’un commentaire, le compteur de commentaires de la carte est mis à jour immédiatement.
- Le flux conserve les actions de like, commentaire et partage, avec les données venant de l’API serveur.

## Configuration nécessaire
Les collections Appwrite doivent être créées et leurs identifiants renseignés dans l’environnement serveur. Consulte `docs/APPWRITE_SCHEMA_V17.md` et les autres fichiers de schéma.

## État honnête
Les tests locaux valident la syntaxe et les contrôles fumée, pas l’accès à un projet Appwrite externe. La production reste conditionnée à la configuration des services, aux tests avec plusieurs vrais comptes, à la vérification sécurité et au déploiement HTTPS. Les paiements YelenPay ne doivent pas activer automatiquement les avantages sans confirmation serveur vérifiée.
