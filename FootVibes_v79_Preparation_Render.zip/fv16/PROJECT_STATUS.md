# État du projet FootVibes — révision v7

## Changements de cette révision
- Ajout d’une page Compte avec création de compte et connexion via le SDK officiel Appwrite chargé depuis CDN, uniquement si `PUBLIC_APPWRITE_ENDPOINT` et `PUBLIC_APPWRITE_PROJECT_ID` sont configurés côté serveur. Aucun compte local fictif n’est créé.
- Acceptation des conditions demandée seulement lors de la création du compte; les documents sont accessibles volontairement depuis Paramètres. Le consentement est inscrit dans les préférences du compte Appwrite lorsque la mise à jour est acceptée par le service.
- Les références visuelles restent dans `assets/reference/` dans le ZIP, mais le serveur interdit leur accès HTTP. La page qui exposait les maquettes a été supprimée.
- Le logo reste utilisable comme identité publique de l’application.
- Le serveur interdit aussi l’accès HTTP direct aux documents internes, au code serveur, aux tests et aux fichiers de configuration.
- Les interactions qui ne sont pas reliées à un backend ne doivent pas afficher de succès fictif.

## Fonctionnalités intégrées
- Serveur Node.js, santé et configuration publique, protection contre l’exposition des secrets.
- Proxy API-Football côté serveur, avec état explicite quand la clé manque.
- Liens YelenPay configurables côté serveur; webhook désactivé tant que la vérification de signature officielle n’est pas implémentée.
- Page de création de compte/connexion Appwrite utilisant le SDK client et les paramètres publics.
- Formulaire de dépôt de preuve de paiement et tableau admin protégé pour le traitement manuel des preuves.
- Pages distinctes pour accueil, compte, Reels, publication, football, wallpapers, profil, messagerie, Premium/Partenaire, paramètres, preuves de paiement, administration et documents légaux.

## Intégrations qui demandent encore le travail côté code et la configuration propriétaire
- Appwrite : renseigner le projet, autoriser le domaine dans Platforms, activer l’authentification e-mail/mot de passe, puis créer base/collections/bucket et leurs permissions. L’authentification est câblée; les opérations sociales et médias ne sont pas encore entièrement reliées à la base.
- API-Football : définir `FOOTBALL_API_KEY` côté serveur.
- YelenPay : renseigner les URLs et intégrer le mécanisme officiel de vérification/signature avant de valider automatiquement un abonnement.
- OneSignal : intégrer l’envoi serveur et configurer APNs/FCM sur les applications mobiles.
- LiveKit : intégrer le SDK d’appel et une route serveur de génération de jetons signés.
- Modération, likes/commentaires persistants, uploads, messagerie temps réel, gestion complète du compte, suppression de compte et administration générale restent à implémenter.

## Vérifications
`npm run check` valide la syntaxe JavaScript. `npm test` vérifie le démarrage, les routes principales, la configuration sans secrets, le comportement des API non configurées, le blocage des références/documents privés et l’accès au logo. Les tests ne prouvent pas la validité d’une clé externe ni le fonctionnement des comptes externes.

## Note de production
Ce paquet est une base de projet plus avancée et préparée à la configuration, mais ne doit pas être présenté comme une application entièrement finalisée tant que les intégrations restantes ne sont pas développées et testées. Les clés secrètes restent uniquement dans l’environnement du serveur.
