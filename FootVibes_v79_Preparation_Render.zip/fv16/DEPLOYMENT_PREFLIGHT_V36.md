# FootVibes v36 — contrôle avant déploiement

Cette version ajoute un contrôle local de configuration : `npm run preflight`. Il liste les variables manquantes par intégration sans afficher leurs valeurs. Un résultat positif signifie uniquement que les variables existent, pas que les identifiants fonctionnent.

## Ordre conseillé

1. Utiliser Node.js 20 ou supérieur et installer le projet.
2. Définir les variables dans le gestionnaire de secrets de l’hébergeur (ne pas les committer dans Git).
3. Exécuter `npm run check`, `npm test`, puis `npm run preflight`.
4. Vérifier `/api/health` et `/api/integrations/status` après déploiement.
5. Tester avec deux comptes réels : inscription, profil, publication, message, appel, abonnement aux alertes, réception OneSignal.
6. Tester l’API-Football avec une clé valide et confirmer les quotas disponibles.
7. Ne pas activer les droits Premium automatiquement tant qu’un webhook YelenPay officiel et vérifié n’est pas implémenté.
8. Ne publier aucun match vidéo sans preuve de droits territoriaux et autorisation d’intégration.

## Conditions encore non garanties

- Les tests automatisés ne prouvent pas que les services externes sont configurés.
- Le verrou de worker doit être testé sous concurrence et panne ; il ne remplace pas une file de tâches avec livraison idempotente.
- Le stockage local est réservé au développement mono-instance. En production, configurer les collections Appwrite documentées et vérifier leurs attributs/permissions.
- Les appels entrants, les push sur appareil réel, les paiements vérifiés, le catalogue de diffusion autorisé et les builds mobiles nécessitent des essais distincts.
