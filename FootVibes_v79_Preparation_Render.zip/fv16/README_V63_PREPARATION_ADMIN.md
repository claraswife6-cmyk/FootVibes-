# FootVibes v63 — Préparation de la boîte administrative

## Ajouts
- Nouvelle route `GET /api/admin/readiness`, accessible uniquement après connexion administrateur.
- Tableau de bord listant la présence des variables nécessaires pour l'administration, Appwrite, LiveKit, OneSignal, API-Football et les paiements.
- Aucun secret ni aucune valeur de variable n'est retourné : uniquement des booléens de présence.
- Avertissement explicite : la présence d'une variable ne confirme pas que l'intégration fonctionne réellement.

## Vérifications à terminer avant lancement
1. Configurer les variables privées dans l'environnement d'hébergement.
2. Tester l'authentification et les opérations Appwrite avec des comptes de test.
3. Tester les appels sur deux appareils et vérifier l'isolation des salons.
4. Vérifier les paiements dans le tableau officiel du prestataire et mettre en place une confirmation serveur signée avant d'activer une offre.
5. Vérifier les notifications en arrière-plan sur iOS et Android.
6. Réaliser un test de déploiement dans un environnement de préproduction.

La checklist est un contrôle de configuration, pas une certification de sécurité ni un test de disponibilité des services.
