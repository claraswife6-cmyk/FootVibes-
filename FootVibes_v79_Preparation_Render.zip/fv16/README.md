# FootVibes — kit de préparation au déploiement

Application web responsive de démonstration et serveur Node.js pour préparer FootVibes au déploiement.

## Prérequis
- Node.js 20+
- Accès aux consoles des services externes utilisés

## Démarrer localement

```sh
cp .env.example .env
# Remplir uniquement les variables correspondant aux services déjà configurés
npm start
```

Ouvrir `http://localhost:8080`.

## Vérifier le paquet

```sh
npm run check
npm test
```

## Important — avant production

Ce ZIP ne contient pas et ne doit pas contenir de clés privées. La navigation et plusieurs écrans sont encore des maquettes/démonstrations. Les intégrations réelles nécessitent des identifiants de services et des étapes supplémentaires : Appwrite (authentification, base, stockage et permissions), API-Football (scores), YelenPay (paiement et confirmation webhook signée), OneSignal/APNs/FCM (push), LiveKit (appels). Consultez `docs/VERIFICATION_DEPLOIEMENT.md`, `docs/INTEGRATIONS_REELLES.md` et `DEPLOYMENT.md`.

Les preuves de paiement manuelles ne sont pas une confirmation de paiement. Le webhook renvoie volontairement HTTP 503 tant que la vérification officielle YelenPay n'est pas implémentée.

Prix configurés dans l'interface : Premium 10 000 FCFA/mois ; Partenaire 5 000 FCFA en paiement unique, sous réserve du respect des règles de la plateforme.

**Ne présentez pas ce paquet comme une version production entièrement fonctionnelle avant la validation de chaque intégration réelle.**

Powered by Trehza Mendoza
