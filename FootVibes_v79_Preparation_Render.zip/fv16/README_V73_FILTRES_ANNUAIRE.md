# FootVibes v73 — Filtres de l’annuaire administrateur

## Nouveautés
- Recherche administrateur par identifiant, nom ou e-mail (l’e-mail est disponible lorsque la source Appwrite le fournit).
- Filtrage des comptes : tous, classiques, Partenaires, certifiés ou signalés.
- Les changements de statut continuent d’exiger un motif et restent envoyés au serveur protégé; le serveur doit confirmer la réussite Appwrite avant d’afficher le succès.

## Vérification
Exécuter `npm run check` puis `npm test` avec Node.js 20 ou plus récent.

## Limites
Cette archive n’a pas été testée avec les identifiants d’un vrai projet Appwrite. Configurez les variables privées côté serveur et effectuez les essais sur un projet de test avant déploiement. L’annuaire est limité à 5 000 utilisateurs par requête de collecte et peut être incomplet au-delà.
