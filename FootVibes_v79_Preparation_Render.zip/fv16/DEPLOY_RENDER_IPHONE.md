# Déployer FootVibes v9 sur Render depuis un iPhone

## Importer sur GitHub
1. Décompresser ce ZIP dans Fichiers sur iPhone.
2. Créer un dépôt GitHub **privé**.
3. Téléverser le CONTENU de ce dossier à la racine du dépôt (le fichier `package.json` doit être à la racine).
4. Ne jamais téléverser `.env` ou des clés API. Le `.gitignore` exclut `.env`.

## Render
1. Render → New + → Blueprint si l’option est proposée et sélectionner le dépôt; le fichier `render.yaml` configure un Web Service Node.
2. Si création manuelle: New + → Web Service; Runtime Node; Build Command `npm install`; Start Command `npm start`; Health Check Path `/api/health`; Root Directory vide si `package.json` est à la racine.
3. Une fois le service créé, ouvrir Environment et ajouter les variables nécessaires depuis `.env.example` une par une. Ne pas coller de secrets dans GitHub ni dans le chat.
4. Copier l’URL publique Render dans `PUBLIC_APP_URL` puis redéployer. Ajouter le domaine Render dans Appwrite → Project → Platforms → Web.
5. Vérifier `/api/health` et les logs Render.

## Limites fonctionnelles importantes
Ce paquet est un starter déployable, pas une application mondiale complète finalisée. L’authentification Appwrite et le proxy API-Football sont préparés; le reste des intégrations dépend de la configuration et/ou de code supplémentaire. YelenPay ne doit jamais activer Premium/Partenaire sans vérification serveur de paiement officielle. La messagerie temps réel, LiveKit, OneSignal, stockage social complet, modération et administration avancée ne sont pas intégralement implémentés.

## Avant publication publique
- Exécuter `npm run check` et `npm test` (Node.js 20+).
- Configurer les secrets exclusivement dans Render Environment.
- Tester les parcours avec de vrais comptes de test et confirmer les permissions Appwrite.
- Ajouter les intégrations restantes et tester les paiements/webhooks avant de vendre des abonnements.
- La publication sur App Store et Google Play est une procédure distincte; ce serveur web ne crée pas automatiquement des applications mobiles natives.
