# Déploiement indépendant de Lovable

## Option A — Node.js
Prérequis : Node.js 20 ou supérieur.

```sh
cp .env.example .env
# Modifier .env sur le serveur, sans partager les secrets
npm start
```
Le serveur sert le site et les routes API sur le port défini par `PORT` (8080 par défaut). Pour un déploiement public, placez-le derrière un reverse proxy HTTPS (Nginx/Caddy) et configurez sauvegardes et supervision.

## Option B — Docker
Prérequis : Docker avec Compose.

```sh
cp .env.example .env
# Remplir .env
 docker compose up --build -d
```

## Option C — hébergement statique
Le prototype seul (HTML/CSS/JS et assets) peut être copié sur un hébergement statique. Dans ce mode, les routes `/api/*` ne fonctionnent pas et aucune clé secrète ne doit être ajoutée au JavaScript. Pour les scores réels, paiements, notifications et jetons d'appels, déployez également le serveur Node.js ou un backend équivalent.

## Vérification locale
- `npm run check`
- `curl http://localhost:8080/api/health`
- `curl http://localhost:8080/api/config`
- `curl http://localhost:8080/api/football/status`

Ce kit n'est pas encore une version production complète : voir `docs/INTEGRATIONS_REELLES.md` et `PROJECT_STATUS.md`.

## Configuration de la création de compte Appwrite
1. Dans Appwrite, autorise le domaine public du site dans **Project → Platforms → Web**.
2. Active l'authentification e-mail/mot de passe dans les méthodes d'authentification.
3. Configure uniquement `PUBLIC_APPWRITE_ENDPOINT` et `PUBLIC_APPWRITE_PROJECT_ID` dans l'environnement du serveur; ces deux valeurs sont publiques. Ne place jamais une API key Appwrite dans le navigateur.
4. Redémarre le serveur et ouvre **Compte → Créer un compte**. Si les variables sont absentes, l'écran explique que le service n'est pas configuré et aucun compte fictif n'est créé.
5. Les autres opérations (publication, réactions, médias, messagerie et suppression de compte) doivent être reliées à leurs collections, permissions et routes dédiées avant d'être utilisées en production.

## Confidentialité des maquettes
Les fichiers `assets/reference/` sont conservés dans le ZIP pour le propriétaire et ne sont pas servis par le serveur web (réponse 403). Ne déplace pas ce dossier dans un répertoire public d'hébergement statique. Le logo officiel est servi pour l'identité visuelle de l'application. Les fichiers `docs/`, tests, configuration et code serveur ne sont pas accessibles directement par HTTP.
