# FootVibes v68 — Recherche administrative

L’endpoint protégé `GET /api/admin/users` prend maintenant en charge :
- `q` : recherche insensible à la casse dans l’identifiant, le nom affiché et les sources ;
- `role=all|partner|verified|reported|classic` : filtre de statut ;
- `limit` : 1 à 100 (défaut 50) ;
- `offset` : pagination, bornée à 500.

Exemple : `/api/admin/users?q=abc&role=partner&limit=25&offset=0`.

**Limite importante :** la liste reste un index partiel dérivé des données locales et de la liste Partenaire configurée. Ce n’est pas encore un annuaire complet Appwrite et cette version n’ajoute pas la suspension/réactivation réelle des comptes.
