# FootVibes v34 — état partagé des alertes

Cette version ajoute le stockage Appwrite partagé de l’état des scores observés et des notifications déjà envoyées. Cela évite de dépendre uniquement du fichier local lorsque le serveur redémarre ou que plusieurs instances utilisent la même collection.

## Configuration

1. Dans la base `APPWRITE_DATABASE_ID`, créez une collection dédiée à l’état du poller.
2. Renseignez son identifiant dans `APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID`.
3. Le serveur utilise un document fixe nommé `goal-alert-state`; autorisez la clé API serveur à lire et modifier cette collection. Ne rendez pas ce document lisible au public.
4. Gardez `APPWRITE_API_KEY`, `FOOTBALL_API_KEY` et `ONESIGNAL_REST_API_KEY` uniquement dans les variables privées de l’hébergeur.

Le document stocke `scores`, `sent` et `updatedAt`. Les données sont écrites par le serveur via l’API Appwrite. Si la variable de collection n’est pas renseignée, le mode de développement retombe sur `data/goal-alert-state.json`.

## Limites à ne pas confondre avec une validation de production

- Aucun projet Appwrite ou appareil OneSignal réel n’est connecté dans cet environnement; l’intégration doit être testée avec les identifiants de déploiement.
- Le serveur Node doit rester actif pour interroger API-Football.
- L’état partagé réduit les différences entre instances, mais ne constitue pas à lui seul un verrou distribué transactionnel. Pour une livraison garantie sans doublons en environnement multi-instance, utiliser un verrou/une file de tâches distribuée et des clés d’idempotence côté notification.
- Les limites de taille des documents Appwrite doivent être surveillées; un stockage dédié par match/jour sera préférable à très grande échelle.
