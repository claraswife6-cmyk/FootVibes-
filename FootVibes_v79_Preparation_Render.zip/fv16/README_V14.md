# FootVibes v14 — intégration interface ↔ serveur

Cette version poursuit le raccordement de l'interface aux routes serveur existantes.

## Connecté dans cette version
- Le fil d'accueil demande les publications à `GET /api/social/posts` et affiche les réponses du serveur.
- Les actions J'aime et Commenter utilisent les routes Appwrite du serveur, avec un JWT Appwrite créé après authentification.
- La page Messagerie permet de saisir l'identifiant Appwrite d'un destinataire, de charger une conversation et d'envoyer un message persistant via `/api/social/messages`.
- Le partage utilise l'API de partage du navigateur quand elle est disponible.
- Les scores continuent d'utiliser les routes serveur API-Football existantes, jamais des scores fictifs.

## À configurer
Copie les variables nécessaires de `.env.example` dans l'environnement privé du serveur (Render, Replit ou autre). Crée les collections Appwrite avec les attributs décrits dans `docs/APPWRITE_SCHEMA_V13.md`, puis ajoute leurs identifiants aux variables. N'ajoute jamais `.env` ou les clés dans GitHub.

## Limites à ne pas masquer
Cette version ne termine pas encore tous les éléments du cahier des charges. L'upload média vers Appwrite Storage et son association aux publications, les likes uniques et anti-abus, les favoris persistants, les appels audio/vidéo côté interface, la synchronisation temps réel, la gestion complète de profil, les workflows de modération, l'enregistrement des appareils OneSignal, le webhook de paiement YelenPay vérifié et les applications natives iOS/Android restent à développer et tester. Le changement d'état d'une preuve de paiement ne valide pas le paiement du prestataire.

## Vérifications
`npm run check` vérifie la syntaxe JavaScript; `npm test` exécute les tests de fumée du serveur. Ces tests ne remplacent pas les essais avec les comptes et clés réels du propriétaire.
