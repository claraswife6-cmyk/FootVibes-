/* CONFIGURATION CLIENT — valeurs publiques uniquement.
 * Ne place JAMAIS de clé secrète, mot de passe administrateur ou clé privée ici.
 * Les secrets doivent rester côté serveur (API/backend/functions).
 * Copier les valeurs nécessaires depuis .env.example dans la configuration du serveur.
 */
window.FOOTVIBES_CONFIG = {
  APP_NAME: 'FootVibes',
  APP_ENV: 'demo',
  API_BASE_URL: '',
  APPWRITE_ENDPOINT: '',
  APPWRITE_PROJECT_ID: '',
  FOOTBALL_API_PROXY_URL: '',
  ONESIGNAL_APP_ID: '',
  LIVEKIT_URL: '',
  PAYMENT_STATUS_API_URL: '',
  SUPPORT_EMAIL: '',
  SOCIAL_TIKTOK_URL: '',
  SOCIAL_INSTAGRAM_URL: '',
  SOCIAL_WHATSAPP_URL: ''
};
