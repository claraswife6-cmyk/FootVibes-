# FootVibes v41 — Statut de lecture visible

## Changement
La liste de conversation affiche maintenant un état différent pour les messages sortants : `Envoyé ✓` quand le destinataire ne les a pas encore marqués comme lus, puis `Lu ✓✓` après mise à jour de l’attribut `read` dans Appwrite. Les messages entrants restent indiqués comme reçus.

## Limites importantes
- L’état `Lu` dépend de la configuration correcte de la collection Appwrite et des permissions.
- Le statut se met à jour lors du prochain rafraîchissement de la conversation (environ 5 secondes), pas par abonnement temps réel.
- Cette version ne réalise pas encore la sonnerie des appels entrants. LiveKit permet toujours de rejoindre le même salon, mais le signalement/acceptation des appels et les notifications d’appel restent à construire et tester.

## Vérification locale
Depuis le dossier du projet :

```bash
npm run check
npm test
npm run release:audit
```

Ces contrôles ne remplacent pas un test avec deux comptes Appwrite réels ou un appareil iOS/Android.
