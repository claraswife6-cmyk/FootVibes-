# FootVibes v22

Ajout de l’intégration OneSignal Web Push dans l’interface : activation des notifications, association de l’utilisateur connecté avec son identifiant Appwrite et retrait de l’association à la déconnexion.

Avant les tests : renseigne `PUBLIC_ONESIGNAL_APP_ID` et `ONESIGNAL_REST_API_KEY` dans l’environnement privé du serveur, déploie `OneSignalSDKWorker.js` à la racine du domaine HTTPS et configure les plateformes OneSignal. Les clés privées ne doivent jamais être ajoutées à `config/env.js`, au navigateur ou à GitHub.

Voir `docs/INTEGRATION_STATUS_V22.md` pour les limites et les étapes de validation. Les notifications natives iOS/Android, l’alerte d’appel entrant et les tests réels restent à réaliser.
