# FootVibes v69 — Filtres administratifs de certification

- `GET /api/admin/certification-requests` reste protégé par une session administrateur.
- Paramètres facultatifs : `status=all|pending|approved|rejected`, `q=...`, `limit=1..100`, `offset=0..`.
- La réponse conserve le champ `requests` pour compatibilité avec l'interface actuelle et ajoute `total`, `limit`, `offset` et `hasMore`.
- Les filtres portent sur les demandes stockées localement par le serveur ; ils ne constituent pas un annuaire Appwrite complet.
- L'approbation de certification demeure une décision manuelle. Les intégrations externes et le déploiement doivent être testés séparément.
