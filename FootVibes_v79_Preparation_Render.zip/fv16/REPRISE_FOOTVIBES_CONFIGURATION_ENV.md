# FootVibes — dossier de reprise de configuration

## Objectif
Préparer la configuration complète des services sans exposer de secrets dans les conversations ou dans une archive partagée. Ce document permet de reprendre le travail plus tard.

## État connu
- Endpoint Appwrite : `https://fra.cloud.appwrite.io/v1`
- Identifiant public du projet Appwrite : `6ad4e92a0021cc34d98c`
- Base de données Appwrite : l’utilisateur indique qu’elle existe déjà.
- Messagerie : l’utilisateur indique qu’elle existe déjà.
- Hébergeur : pas encore choisi.
- Les clés API privées, secrets LiveKit, clés OneSignal, secrets de paiement et identifiants d’administration ne sont pas fournis dans le ZIP.

## Procédure privée
1. Copier `.env.example` en `.env` dans un environnement local privé ou dans les variables d’environnement de l’hébergeur.
2. Depuis la console Appwrite, relever les identifiants existants de la base, des collections et du bucket. Ne pas recréer les ressources déjà existantes.
3. Ajouter les identifiants de ressources et les clés secrètes uniquement dans l’environnement privé qui exécute le serveur.
4. Ne jamais committer ni envoyer le fichier `.env`; ne pas le joindre à un ZIP partagé.
5. Choisir un hébergeur prenant en charge Node.js et les variables d’environnement. Configurer la commande de démarrage, le port et l’URL publique.
6. Lancer les contrôles du projet (`npm run check`, `npm test`, puis `npm run preflight`) et résoudre les variables manquantes avant déploiement.
7. Tester avec des comptes de test : connexion, lecture/écriture Appwrite, envoi/réception de messages, permissions et appels si LiveKit est configuré.

## Variables
Le fichier `.env.example` contient la liste des variables prévues. Les valeurs vides sont des emplacements à remplir dans un environnement privé. Les identifiants publics Appwrite peuvent être configurés dans le projet; les clés API et secrets restent côté serveur.

## Renouvellement des clés plus tard
C’est possible, mais il faut mettre à jour la variable privée correspondante et redémarrer/redéployer le service. Si une clé a été exposée, la révoquer chez le fournisseur et la remplacer. Ne jamais partager les clés dans la conversation.

## Limites connues
Ce dossier de configuration ne prouve pas que les services distants sont connectés. Le déploiement réel et les tests d’intégration nécessitent l’accès privé au compte Appwrite et aux comptes des fournisseurs. Les clés ne sont volontairement pas intégrées à cette archive.

## Message pour reprendre dans une nouvelle conversation
« Reprenons FootVibes à partir du ZIP de configuration. Appwrite et la messagerie existent déjà, l’hébergeur reste à choisir. Utilise `REPRISE_FOOTVIBES_CONFIGURATION_ENV.md` et `.env.example`, garde les secrets hors du chat et ne recrée pas les ressources Appwrite existantes. Étape suivante : choisir l’hébergeur Node.js, comparer les options gratuites actuelles, puis préparer le déploiement et les tests d’intégration. »
