import { readFileSync } from 'node:fs';
const stylesSource = readFileSync(new URL('../styles.css', import.meta.url), 'utf8');
import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import assert from 'node:assert/strict';
import net from 'node:net';
import fs from 'node:fs';

async function freePort(){return await new Promise((resolve,reject)=>{const s=net.createServer();s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});s.on('error',reject);});}
const port=await freePort();
const child=spawn(process.execPath,['server/server.js'],{cwd:process.cwd(),env:{...process.env,PORT:String(port),HOST:'127.0.0.1',APP_ENV:'test',ADMIN_PASSWORD:'footvibes-test-admin-password',ADMIN_EMAIL:'claraswife6@gmail.com',FOOTBALL_API_KEY:'',YELENPAY_PREMIUM_URL:'',YELENPAY_PARTNER_URL:'',FOOTVIBES_STREAM_CATALOG_JSON:JSON.stringify([{id:'test-free',title:'Test free',access:'free',url:'https://www.fifa.com/fifaplus',rightsConfirmed:true,embedUrl:'https://www.youtube-nocookie.com/embed/M7lc1UVf-VE'},{id:'test-premium',title:'Test premium',access:'premium',url:'https://www.dazn.com/',rightsConfirmed:true,embedUrl:'https://www.youtube-nocookie.com/embed/M7lc1UVf-VE'}])},stdio:'ignore'});
const base=`http://127.0.0.1:${port}`;
const appSource=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8');
assert.match(appSource,/function bindProfileEditor\(\)/,'profile editor must be bound');
assert.match(appSource,/account\.updateName\(name\)/,'profile name must save through Appwrite');
assert.match(appSource,/account\.updatePrefs\(/,'profile preferences must save through Appwrite');
assert.match(appSource,/profileUsernameInput/,'profile username field must exist');
assert.match(appSource,/profileBioInput/,'profile bio field must exist');
const preflightSource=fs.readFileSync(new URL('../scripts/preflight.mjs',import.meta.url),'utf8');
assert.match(preflightSource,/process\.env/,'preflight checks environment variables');
assert.match(preflightSource,/aucune valeur secrète n’est affichée/,'preflight does not print secret values');
const serverSource=fs.readFileSync(new URL('../server/server.js',import.meta.url),'utf8');
assert.match(serverSource,/APPWRITE_GOAL_ALERT_STATE_COLLECTION_ID/,'goal alert state can use shared Appwrite storage');
assert.match(serverSource,/async function loadGoalState\(\)/,'goal alert state loader exists');
assert.match(serverSource,/async function persistGoalState\(state\)/,'goal alert state persistence exists');
assert.match(serverSource,/api\/social\/messages\/read/,'read receipt endpoint exists');
assert.match(serverSource,/api\/social\/messages\/unread-count/,'unread message count endpoint exists');
assert.match(serverSource,/api\/social\/calls/,'call signaling endpoints exist');
assert.match(serverSource,/FOOTVIBES_PARTNER_USER_IDS/,'partner entitlement is controlled by server environment');
assert.match(serverSource,/function hasPartnerAccess\(user\)/,'partner-only authorization helper exists');
assert.match(serverSource,/api\/account\/entitlements/,'authenticated account entitlement endpoint exists');
assert.match(serverSource,/LiveKit tokens grant media publishing[\s\S]*?if\(!hasPartnerAccess\(user\)\)return partnerOnly\(res\)/,'LiveKit media tokens require server-authorized Partner access');
assert.match(serverSource,/publish:partner,messaging:partner,audioCalls:partner,videoCalls:partner/,'partner capabilities are server-derived');
assert.match(serverSource,/professionalLive:partner&&verified/,'professional live capability requires partner and certification');
assert.match(serverSource,/api\/certification\/request/,'users can submit certification requests');
assert.match(serverSource,/api\/admin\/certification-requests/,'admins can review certification requests');
assert.match(serverSource,/verifiedUserIds\(\)/,'verified status is checked server-side');
assert.match(serverSource,/verification-requests\.json/,'certification requests persist on server');
assert.match(serverSource,/if\(!hasPartnerAccess\(identity\)\)return partnerOnly\(res\)/,'publishing and media upload require partner access');
assert.match(serverSource,/code:'PARTNER_REQUIRED'/,'non-partners receive a clear authorization error');
assert.match(serverSource,/APPWRITE_CALLS_COLLECTION_ID/,'call signaling requires a dedicated collection');
assert.match(serverSource, /\['GET','PATCH'\]\.includes\(req\.method\)/, 'call status polling supports GET');
assert.match(appSource, /en attente de réponse/, 'caller waits for the recipient instead of joining early');
assert.match(appSource, /status:'accepted'/, 'recipient acceptance updates call status');
assert.match(serverSource,/expiresAt/,'incoming call invitations have an expiry');
assert.match(serverSource,/Seul le destinataire peut accepter ou refuser/, 'only the recipient may accept or reject a call');
assert.match(serverSource,/Cette invitation a expiré/, 'expired invitations cannot be accepted');
assert.match(serverSource,/Le statut manqué est calculé automatiquement/, 'clients cannot forge missed-call status');
assert.match(appSource,/api\/social\/messages\/read/,'conversation marks incoming messages as read');
try {
 let ready=false;
 for(let i=0;i<50;i++){try{const r=await fetch(`${base}/api/health`);if(r.ok){ready=true;break;}}catch{} await delay(100);}
 assert.equal(ready,true,'server should start');
 let r=await fetch(`${base}/api/health`);let d=await r.json();assert.equal(r.status,200);assert.equal(d.status,'ok');
 r=await fetch(`${base}/api/config`);d=await r.json();assert.equal(r.status,200);assert.equal(d.appName,'FootVibes');assert.equal('FOOTBALL_API_KEY' in d,false,'secret key must not be exposed');
 r=await fetch(`${base}/api/admin/users/test-user/status`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({status:'suspended',reason:'test reason'})});d=await r.json();assert.equal(r.status,401,'account status changes require an admin session');
 r=await fetch(`${base}/api/admin/login`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:'claraswife6@gmail.com',password:'footvibes-test-admin-password'})});d=await r.json();assert.equal(r.status,200,'test admin can authenticate');const adminCookie=(r.headers.get('set-cookie')||'').split(';')[0];assert.ok(adminCookie.startsWith('fv_admin='),'admin session cookie is issued');
 r=await fetch(`${base}/api/admin/users/test-user/status`,{method:'POST',headers:{'content-type':'application/json','cookie':adminCookie},body:JSON.stringify({status:'suspended',reason:'bad'})});d=await r.json();assert.equal(r.status,400,'short account decision reasons are rejected');
 r=await fetch(`${base}/api/admin/users/test-user/status`,{method:'POST',headers:{'content-type':'application/json','cookie':adminCookie},body:JSON.stringify({status:'suspended',reason:'Suspension de test'})});d=await r.json();assert.equal(r.status,503,'real account changes fail closed without Appwrite credentials');assert.match(d.error,/APPWRITE_API_KEY/);
 r=await fetch(`${base}/api/football/status`);d=await r.json();assert.equal(r.status,200);assert.equal(d.configured,false);
 r=await fetch(`${base}/api/streams`);d=await r.json();assert.equal(r.status,200);assert.equal(d.streams.length,2);assert.equal(d.streams.find(x=>x.id==='test-premium').url,'','premium stream URL must never be exposed publicly');assert.equal(d.streams.find(x=>x.id==='test-premium').embedUrl,'','premium embed must never be exposed');assert.equal(d.streams.find(x=>x.id==='test-free').embedUrl,'https://www.youtube-nocookie.com/embed/M7lc1UVf-VE');
 r=await fetch(`${base}/api/integrations/status`);d=await r.json();assert.equal(r.status,200);assert.equal(d.integrations.football,false);assert.equal(d.integrations.yelenpayVerifiedWebhook,false);assert.equal(JSON.stringify(d).includes('FOOTBALL_API_KEY_VALUE'),false);
 r=await fetch(`${base}/api/livekit/token`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({room:'test-room'})});d=await r.json();assert.equal(r.status,503);assert.match(d.error,/LiveKit ou Appwrite/);
 r=await fetch(`${base}/api/football/fixtures`);d=await r.json();assert.equal(r.status,503);assert.equal(d.error,'API-Football non configurée');
 r=await fetch(`${base}/api/payments/links`);d=await r.json();assert.equal(r.status,200);assert.equal(d.premium.priceXof,10000);assert.equal(d.partner.priceXof,5000);assert.equal(d.premium.url,'');
 r=await fetch(`${base}/api/payments/webhook`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});d=await r.json();assert.equal(r.status,503);assert.equal(d.error,'Webhook non activé');
 r=await fetch(`${base}/`);assert.equal(r.status,200);assert.match(await r.text(),/FootVibes/);
 r=await fetch(`${base}/.env`);assert.equal(r.status,403);
 r=await fetch(`${base}/assets/reference/maquette-sociale.jpeg`);assert.equal(r.status,403,'reference images must not be publicly served');
 r=await fetch(`${base}/docs/CONDITIONS_UTILISATION.md`);assert.equal(r.status,403,'internal documents must not be publicly served as raw files');
 r=await fetch(`${base}/assets/logo-footvibes.jpeg`);assert.equal(r.status,200,'the official logo is allowed in the public interface');
 assert.match(appSource, /async function initOneSignal\(\)/, 'OneSignal initialization must remain present');
assert.match(appSource, /O\.Notifications\.requestPermission\(\)/, 'Push permission must be explicitly requested by the user');
assert.match(appSource, /O\.User\.PushSubscription\.optedIn/, 'UI must verify that the push subscription opted in');
assert.match(serverSource, /ONESIGNAL_REST_API_KEY/, 'OneSignal REST secret must remain server-side');
assert.match(serverSource, /api\/notifications\/send/, 'Server-side notification endpoint must exist');

// LiveKit authorization regression checks: credentials are never issued before server-side session and Partner checks.
assert.match(serverSource, /api\/livekit\/token/, 'LiveKit token route must exist');
assert.match(serverSource, /Connexion Appwrite requise\./, 'LiveKit route rejects missing sessions');
assert.match(serverSource, /Session Appwrite invalide ou expirée\./, 'LiveKit route rejects invalid sessions');
assert.match(serverSource, /if\(!hasPartnerAccess\(user\)\)return partnerOnly\(res\)/, 'LiveKit route enforces Partner access server-side');
assert.match(serverSource, /Nom de salon invalide\./, 'LiveKit room name is validated');
assert.match(serverSource, /LIVEKIT_API_SECRET/, 'LiveKit signing secret is read server-side');

console.log('OK — contrôles fumée réussis, dont 6 vérifications de sécurité LiveKit.');
} finally {child.kill('SIGTERM');}

assert.match(appSource,/unreadMessageBadge/,'messaging page contains unread badge');
assert.match(appSource,/refreshUnreadCount/,'unread count refresh is wired');

assert.match(stylesSource,/--fv-black:#101114/i,'palette noir officiel');
assert.match(stylesSource,/--fv-white:#ffffff/i,'palette blanc officiel');
assert.match(stylesSource,/--fv-green:#39ff14/i,'palette vert néon officiel');
assert.match(stylesSource,/--fv-yellow:#ffd60a/i,'palette jaune officiel');
assert.match(stylesSource,/--fv-red:#ff3030/i,'palette rouge officiel');
assert.match(stylesSource,/--fv-blue:#1877f2/i,'palette bleu certification');
assert.match(stylesSource,/\.verified-badge/i,'style du badge bleu de certification');
assert.match(stylesSource,/\.pill\.badge-partner/,'badge partenaire distinct');
assert.match(stylesSource,/\.pill\.badge-verified/,'badge certifié distinct');
assert.match(appSource,/certificationRequestForm/,'profile has a certification request form');
assert.match(appSource,/api\/certification\/status/,'profile loads certification status');
assert.match(appSource,/api\/certification\/request/,'profile submits certification requests');
assert.match(appSource,/profileVerifiedBadge/,'profile displays the verified badge from server status');

assert.match(serverSource,/api\/admin\/overview/,'admin overview endpoint exists');
assert.match(serverSource,/authorizedAccounts:new Set\(partners\)\.size/,'admin overview reports server-controlled partner count');
assert.match(serverSource,/pending:requests\.filter\(x=>x\.status==='pending'\)\.length/,'admin overview reports certification request counts');

assert.match(appSource,/adminOverviewCards/,'admin dashboard contains visual overview cards');
assert.match(appSource,/refreshAdminOverview/,'admin overview refresh control is wired');
assert.match(appSource,/api\/admin\/overview/,'admin dashboard loads protected overview endpoint');

assert.match(serverSource,/api\/admin\/users/,'admin user index endpoint exists');
assert.match(appSource,/id=\"adminUsersRole\"/,'admin directory has account category filter');
assert.ok(appSource.includes("'&role='+encodeURIComponent(role)"),'admin directory sends selected category filter');
assert.match(appSource,/u\.email\?`<p class=/,'admin directory shows available account email');
assert.match(serverSource,/completeDirectory:false/,'admin user index clearly states it is partial');

assert.match(serverSource,/ACCOUNT_STATUS_FILE/,'account status persistence exists');
assert.ok(serverSource.includes("url.pathname.startsWith('/api/admin/users/') && url.pathname.endsWith('/status')"),'admin account status route exists');
assert.match(serverSource,/reason\.length<5\|\|reason\.length>500/,'account decision requires a reason');
assert.match(serverSource,/ACCOUNT_SUSPENDED/,'suspended accounts are blocked by server identity checks');
assert.match(serverSource,/recordAdminAudit\('account:'\+status/,'account status decisions are audited');
