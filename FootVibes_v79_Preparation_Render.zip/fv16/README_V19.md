# FootVibes v19 — Synchronisation automatique de la messagerie

Cette version poursuit la messagerie existante : lorsque la page Messagerie reste ouverte, elle recharge la conversation toutes les 5 secondes, affiche les messages reçus/envoyés, les médias attachés sous forme de lien, et un état de dernière synchronisation. Le polling s'arrête quand l'utilisateur quitte la page.

## Configuration requise
- `APPWRITE_ENDPOINT`/`PUBLIC_APPWRITE_ENDPOINT` et `PUBLIC_APPWRITE_PROJECT_ID` configurés selon `.env.example`.
- `APPWRITE_API_KEY`, `APPWRITE_DATABASE_ID` et `APPWRITE_MESSAGES_COLLECTION_ID` configurés côté serveur.
- Collection Messages avec les attributs `senderId`, `recipientId`, `text`, `mediaUrl`, `read`.
- Utilisateur connecté; l'ID Appwrite du destinataire doit être saisi.

## Limites connues
Ce n'est pas encore le canal Appwrite Realtime natif : la conversation utilise le polling HTTP toutes les 5 secondes. Les appels audio/vidéo LiveKit, les notifications push OneSignal et la confirmation réelle des paiements YelenPay restent à intégrer/configurer. Les tests locaux ne prouvent pas la connexion à un projet Appwrite distant.
